import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

// BASE_PATH se fija a "/<nombre-del-repo>/" durante el build en GitHub Actions
// (ver .github/workflows/deploy.yml) para que los assets resuelvan bien
// cuando la web vive en https://usuario.github.io/nombre-del-repo/
const basePath = process.env.BASE_PATH || "/";

export default defineConfig({
  base: basePath,
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
    },
    dedupe: ["react", "react-dom"],
  },
  build: {
    outDir: path.resolve(import.meta.dirname, "dist"),
    emptyOutDir: true,
  },
  server: {
    port: Number(process.env.PORT) || 5173,
    host: "0.0.0.0",
  },
  preview: {
    port: Number(process.env.PORT) || 4173,
    host: "0.0.0.0",
  },
});
