// ─── Core entities ────────────────────────────────────────────────────────────

export type Nation = {
  id: number;
  name: string;
  color: string;
};

export type City = {
  id: number;
  name: string;
  nationId: number;
  latitude: number;
  longitude: number;
  infrastructureLevel: number;  // no fixed maximum
  developmentPoints: number;
  militaryPower: number;
};

// ─── Events ───────────────────────────────────────────────────────────────────

export type EventType =
  | 'nationFounded'
  | 'increaseMilitaryPower'
  | 'developInfrastructure'
  | 'attack';

export type AtlasEvent = {
  id: number;             // auto-incremental
  type: EventType;
  date: string;           // world date (YYYY-MM-DD)
  nation: number;         // id of the acting nation
  city: City;             // snapshot of acting city AFTER the event
  targetNation?: number;  // id of defending nation (attack only)
  targetCity?: City;      // snapshot of defending city AFTER the event (attack only)
};

// ─── Event inputs (what the UI passes to the hook) ───────────────────────────

export type NationFoundedInput = {
  type: 'nationFounded';
  nationName: string;
  color: string;
  capitalName: string;
  latitude: number;
  longitude: number;
};

export type IncreaseMilitaryPowerInput = {
  type: 'increaseMilitaryPower';
  cityId: number;
};

export type DevelopInfrastructureInput = {
  type: 'developInfrastructure';
  cityId: number;
};

export type AttackInput = {
  type: 'attack';
  attackerCityId: number;
};

export type EventInput =
  | NationFoundedInput
  | IncreaseMilitaryPowerInput
  | DevelopInfrastructureInput
  | AttackInput;

// ─── Persistence root ─────────────────────────────────────────────────────────

export type AtlasData = {
  nations: Nation[];
  cities: City[];
  events: AtlasEvent[];
  currentDate: string;
};
