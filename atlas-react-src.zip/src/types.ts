export type Nation = {
  id: string;
  name: string;
  color: string;
  createdAt: string;
};

export type City = {
  id: string;
  name: string;
  nationId: string;
  latitude: number;
  longitude: number;
  nivelInfraestructura: number;
  puntosDesarrollo: number;
  poderMilitar: number;
  createdAt: string;
  joinedNationAt: string; // when this city joined its current nation (conquest or founding)
};

export type TipoEvento =
  | 'nueva_nacion'
  | 'generacion_poder_militar'
  | 'mejora_infraestructura'
  | 'ataque'
  | 'conquista'
  | 'derrota_nacion';

export type GameEvent = {
  id: string;
  tipo: TipoEvento;
  fecha: string;
  descripcion: string;
  resultado?: string;
  createdAt: string;
};

export type NuevaLNacionInput = {
  tipo: 'nueva_nacion';
  fecha: string;
  nombreNacion: string;
  color: string;
  nombreCapital: string;
  latitude: number;
  longitude: number;
};

export type GeneracionInput = {
  tipo: 'generacion_poder_militar';
  fecha: string;
  cityId: string;
};

export type MejoraInput = {
  tipo: 'mejora_infraestructura';
  fecha: string;
  cityId: string;
};

export type AtaqueInput = {
  tipo: 'ataque';
  fecha: string;
  attackerCityId: string;
};

export type EventInput =
  | NuevaLNacionInput
  | GeneracionInput
  | MejoraInput
  | AtaqueInput;

export type AtlasData = {
  nations: Nation[];
  cities: City[];
  events: GameEvent[];
};
