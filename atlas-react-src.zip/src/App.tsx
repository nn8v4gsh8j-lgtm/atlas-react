import { useState, useCallback } from 'react';
import { Map, Flag, Calendar, Download, Upload } from 'lucide-react';
import { useAtlasData } from './hooks/useAtlasData';
import { City, Nation, AtlasData } from './types';
import { NacionesTab }  from './components/NacionesTab';
import { CiudadesTab }  from './components/CiudadesTab';
import { MapaTab }      from './components/MapaTab';
import { EventosTab }   from './components/EventosTab';
import { NationSheet }  from './components/NationSheet';
import { CitySheet }    from './components/CitySheet';
import { EventSheet }   from './components/EventSheet';

type Tab = 'naciones' | 'ciudades' | 'mapa' | 'eventos';

export default function App() {
  const {
    nations, cities, events,
    currentDate, setCurrentDate,
    addNation, updateNation, deleteNation,
    addCity, updateCity, deleteCity,
    addEvent, deleteEvent,
    replaceData,
  } = useAtlasData();

  const [activeTab, setActiveTab] = useState<Tab>('naciones');

  // Sheets
  const [nationSheetOpen, setNationSheetOpen] = useState(false);
  const [editingNation,   setEditingNation]   = useState<Nation | null>(null);
  const [citySheetOpen,   setCitySheetOpen]   = useState(false);
  const [editingCity,     setEditingCity]     = useState<City | null>(null);
  const [eventSheetOpen,  setEventSheetOpen]  = useState(false);

  // Map city-draft (for "pick on map" flow)
  const [draftCity,            setDraftCity]            = useState<Partial<City> | null>(null);
  const [isSelectingLocation,  setIsSelectingLocation]  = useState(false);

  // ── Tab navigation ───────────────────────────────────────────────────────────
  const goToTab = useCallback((tab: Tab) => setActiveTab(tab), []);

  // ── FAB action ───────────────────────────────────────────────────────────────
  const handleFabClick = () => {
    if (activeTab === 'naciones') { setEditingNation(null); setNationSheetOpen(true); }
    if (activeTab === 'ciudades') { setEditingCity(null); setDraftCity(null); setCitySheetOpen(true); }
    if (activeTab === 'eventos')  { setEventSheetOpen(true); }
  };

  // ── Nation sheet handlers ────────────────────────────────────────────────────
  const handleNationSave = (data: Omit<Nation, 'id'>) => {
    if (editingNation) updateNation(editingNation.id, data);
    else addNation(data);
  };

  // ── City sheet handlers ──────────────────────────────────────────────────────
  const handleCitySave = (data: Omit<City, 'id'>) => {
    if (editingCity) updateCity(editingCity.id, data);
    else addCity(data);
  };

  const handleRequestMapSelection = (draft: Partial<City>) => {
    setDraftCity(draft);
    setCitySheetOpen(false);
    setIsSelectingLocation(true);
    setActiveTab('mapa');
  };

  const handleLocationSelect = (lat: number, lng: number) => {
    setDraftCity(prev => ({ ...prev, latitude: lat, longitude: lng }));
    setIsSelectingLocation(false);
    setCitySheetOpen(true);
  };

  const handleCancelLocationSelect = () => {
    setIsSelectingLocation(false);
    setCitySheetOpen(true);
    setActiveTab('ciudades');
  };

  // ── Export / Import ──────────────────────────────────────────────────────────
  const handleExport = () => {
    const data: AtlasData = { nations, cities, events, currentDate };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = Object.assign(document.createElement('a'), { href: url, download: `atlas-${currentDate}.json` });
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string) as Partial<AtlasData>;
        if (!Array.isArray(data.nations) || !Array.isArray(data.cities)) throw new Error('formato inválido');
        if (!window.confirm('Esto reemplazará todos los datos actuales. ¿Continuar?')) return;
        replaceData(data);
      } catch {
        alert('No se pudo leer el archivo. Asegúrate de que es un export válido de Atlas.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const showFab = activeTab !== 'mapa';

  const TAB_CONFIG: { id: Tab; label: string; Icon: React.FC<{ size?: number; className?: string }> }[] = [
    { id: 'naciones', label: 'Naciones', Icon: Flag    },
    { id: 'ciudades', label: 'Ciudades', Icon: ({ size, className }) => (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
          <path d="M4 21V8l6-3v16"/><path d="M10 21V11l6-2v12"/><path d="M16 21V9l4-1v13"/><path d="M2 21h20"/>
        </svg>
    )},
    { id: 'mapa',     label: 'Mapa',    Icon: Map     },
    { id: 'eventos',  label: 'Eventos', Icon: Calendar },
  ];

  return (
    <div className="flex flex-col h-screen bg-[#0e1720] text-[#ece7d9] overflow-hidden" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      {/* Header */}
      <header className="flex-shrink-0 flex items-center justify-between px-4 py-3 bg-[#16212b] border-b border-[#2a3a47] z-50">
        <div className="flex items-baseline gap-2">
          <span className="text-[#c9a24c] text-lg">✦</span>
          <h1 className="font-serif text-xl font-bold tracking-widest text-[#ece7d9]">ATLAS</h1>
          <span className="font-mono text-[9px] tracking-wider" style={{ color: '#3d5263' }}>v1.0.2</span>
          <span className="font-mono text-[9px] text-foreground/30 uppercase tracking-widest hidden sm:inline">Naciones · Ciudades</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExport} title="Exportar datos"
            className="w-9 h-9 rounded-lg border border-[#2a3a47] bg-[#1c2a36] text-foreground/50 flex items-center justify-center active:bg-[#2a3a47] transition-colors">
            <Download size={16} />
          </button>
          <label className="w-9 h-9 rounded-lg border border-[#2a3a47] bg-[#1c2a36] text-foreground/50 flex items-center justify-center active:bg-[#2a3a47] transition-colors cursor-pointer">
            <Upload size={16} />
            <input type="file" accept="application/json" onChange={handleImport} className="hidden" />
          </label>
        </div>
      </header>

      {/* World date bar */}
      <div className="flex-shrink-0 flex items-center justify-between gap-3 px-4 py-2 bg-[#16212b] border-b border-[#2a3a47] z-40">
        <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/40">Fecha del mundo</span>
        <input type="date" value={currentDate} onChange={e => e.target.value && setCurrentDate(e.target.value)}
          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-2 py-1 text-[#c9a24c] font-mono text-sm focus:outline-none focus:border-[#c9a24c]" />
      </div>

      {/* Panels */}
      <main className="flex-1 overflow-hidden relative">
        {(['naciones','ciudades','mapa','eventos'] as Tab[]).map(tab => (
          <div key={tab} className={`absolute inset-0 overflow-y-auto -webkit-overflow-scrolling-touch ${activeTab === tab ? 'block' : 'hidden'}`}>
            {tab === 'naciones' && (
              <NacionesTab nations={nations} cities={cities} events={events}
                onEdit={n => { setEditingNation(n); setNationSheetOpen(true); }}
                onDelete={deleteNation} onAdd={handleFabClick} />
            )}
            {tab === 'ciudades' && (
              <CiudadesTab nations={nations} cities={cities}
                onEdit={c => { setEditingCity(c); setDraftCity(null); setCitySheetOpen(true); }}
                onDelete={deleteCity} onAdd={handleFabClick}
                onGoToNaciones={() => goToTab('naciones')} />
            )}
            {tab === 'mapa' && (
              <MapaTab nations={nations} cities={cities} isActive={activeTab === 'mapa'}
                isSelectingLocation={isSelectingLocation}
                draftCityName={draftCity?.name}
                onLocationSelect={handleLocationSelect}
                onCancelSelection={handleCancelLocationSelect} />
            )}
            {tab === 'eventos' && (
              <EventosTab events={events} nations={nations} cities={cities}
                onAdd={handleFabClick} onDelete={deleteEvent} />
            )}
          </div>
        ))}
      </main>

      {/* FAB */}
      {showFab && (
        <button onClick={handleFabClick}
          className="fixed right-5 bottom-[calc(env(safe-area-inset-bottom)+72px)] z-40 w-14 h-14 rounded-full bg-[#c9a24c] text-[#0e1720] text-3xl font-light flex items-center justify-center shadow-xl active:bg-[#a8863c] transition-colors">
          +
        </button>
      )}

      {/* Bottom tab bar */}
      <nav className="flex-shrink-0 flex border-t border-[#2a3a47] bg-[#16212b] z-50"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)', height: `calc(62px + env(safe-area-inset-bottom))` }}>
        {TAB_CONFIG.map(({ id, label, Icon }) => (
          <button key={id} onClick={() => goToTab(id)}
            className={`flex-1 flex flex-col items-center justify-center gap-1 text-[11px] font-sans transition-colors ${activeTab === id ? 'text-[#c9a24c]' : 'text-foreground/40'}`}>
            <Icon size={20} className={activeTab === id ? 'text-[#c9a24c]' : 'text-foreground/40'} />
            {label}
          </button>
        ))}
      </nav>

      {/* Sheets */}
      <NationSheet open={nationSheetOpen} onOpenChange={setNationSheetOpen}
        nation={editingNation} onSave={handleNationSave} />

      <CitySheet open={citySheetOpen} onOpenChange={setCitySheetOpen}
        city={editingCity} nations={nations} draftData={draftCity ?? undefined}
        onSave={handleCitySave} onRequestMapSelection={handleRequestMapSelection} />

      <EventSheet open={eventSheetOpen} onOpenChange={setEventSheetOpen}
        nations={nations} cities={cities} currentDate={currentDate}
        onSave={addEvent} />
    </div>
  );
}
