import React, { useState, useRef } from 'react';
import { Download, Upload, Plus, Map, Flag, Castle, ScrollText } from 'lucide-react';
import { useAtlasData } from './hooks/useAtlasData';
import { NacionesTab } from './components/NacionesTab';
import { CiudadesTab } from './components/CiudadesTab';
import { MapaTab } from './components/MapaTab';
import { EventosTab } from './components/EventosTab';
import { NationSheet } from './components/NationSheet';
import { CitySheet } from './components/CitySheet';
import { EventSheet } from './components/EventSheet';
import { Nation, City, EventInput } from './types';

type Tab = 'naciones' | 'ciudades' | 'mapa' | 'eventos';

export default function App() {
  const {
    nations, cities, events,
    currentDate, setCurrentDate,
    addNation, updateNation, deleteNation,
    addCity, updateCity, deleteCity,
    addEvent, deleteEvent,
    replaceData,
  } = useAtlasData();

  const [activeTab, setActiveTab] = useState<Tab>('naciones');

  const [nationSheetOpen, setNationSheetOpen] = useState(false);
  const [editingNation, setEditingNation] = useState<Nation | null>(null);

  const [citySheetOpen, setCitySheetOpen] = useState(false);
  const [editingCity, setEditingCity] = useState<City | null>(null);
  const [cityDraft, setCityDraft] = useState<Partial<City> | undefined>();

  const [eventSheetOpen, setEventSheetOpen] = useState(false);

  const [isMapClickMode, setIsMapClickMode] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const data = { nations, cities, events, currentDate, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'atlas-export.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = event => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (window.confirm('¿Reemplazar todos los datos con el archivo importado? Esta acción no se puede deshacer.')) {
          replaceData(data);
        }
      } catch {
        alert('Error al leer el archivo JSON.');
      }
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  const handleFabClick = () => {
    if (activeTab === 'naciones') {
      setEditingNation(null);
      setNationSheetOpen(true);
    } else if (activeTab === 'ciudades') {
      if (nations.length === 0) { alert('Crea una nación primero.'); return; }
      setEditingCity(null);
      setCityDraft(undefined);
      setCitySheetOpen(true);
    } else if (activeTab === 'eventos') {
      setEventSheetOpen(true);
    }
  };

  const requestMapSelection = (draft: Partial<City>) => {
    setCityDraft(draft);
    setCitySheetOpen(false);
    setActiveTab('mapa');
    setIsMapClickMode(true);
  };

  const handleMapLocationSelect = (lat: number, lng: number) => {
    setIsMapClickMode(false);
    setCityDraft(prev => ({ ...prev, latitude: lat, longitude: lng }));
    setActiveTab('ciudades');
    setCitySheetOpen(true);
  };

  const cancelMapSelection = () => {
    setIsMapClickMode(false);
    setActiveTab('ciudades');
    setCitySheetOpen(true);
  };

  const handleEventSave = (input: EventInput) => {
    addEvent(input);
  };

  const showFab = activeTab !== 'mapa';

  return (
    <div className="h-full flex flex-col bg-[#0e1720] text-[#ece7d9] font-sans overflow-hidden">

      {/* Header */}
      <header
        className="flex-shrink-0 flex items-center justify-between px-4 border-b border-[#2a3a47] bg-[#0e1720] z-50"
        style={{ paddingTop: 'calc(env(safe-area-inset-top) + 0.75rem)', paddingBottom: '0.75rem' }}
      >
        <h1 className="font-serif text-2xl tracking-wide flex items-center gap-2 text-[#ece7d9]">
          <span className="text-[#c9a24c] text-sm">✦</span> ATLAS
        </h1>
        <div className="flex gap-3">
          <input type="file" accept=".json" className="hidden" ref={fileInputRef} onChange={handleImport} />
          <button
            data-testid="button-import"
            onClick={() => fileInputRef.current?.click()}
            className="text-[#c9a24c] p-2 rounded-full active:bg-[#16212b] transition-colors"
          >
            <Upload size={20} />
          </button>
          <button
            data-testid="button-export"
            onClick={handleExport}
            className="text-[#c9a24c] p-2 rounded-full active:bg-[#16212b] transition-colors"
          >
            <Download size={20} />
          </button>
        </div>
      </header>

      {/* Global world date bar */}
      <div className="flex-shrink-0 flex items-center justify-between gap-3 px-4 py-2 bg-[#16212b] border-b border-[#2a3a47] z-40">
        <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/40">Fecha del mundo</span>
        <input
          type="date"
          value={currentDate}
          onChange={e => e.target.value && setCurrentDate(e.target.value)}
          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-2 py-1 text-[#c9a24c] font-mono text-sm focus:outline-none focus:border-[#c9a24c]"
        />
      </div>

      {/* Main content — all tabs always mounted, shown/hidden via CSS */}
      <main className="flex-1 min-h-0 relative">
        <div className={`absolute inset-0 overflow-y-auto ${activeTab === 'naciones' ? '' : 'hidden'}`}>
          <NacionesTab
            nations={nations} cities={cities} events={events}
            onEdit={n => { setEditingNation(n); setNationSheetOpen(true); }}
            onDelete={deleteNation}
            onAdd={handleFabClick}
          />
        </div>

        <div className={`absolute inset-0 overflow-y-auto ${activeTab === 'ciudades' ? '' : 'hidden'}`}>
          <CiudadesTab
            nations={nations} cities={cities}
            onEdit={c => { setEditingCity(c); setCityDraft(undefined); setCitySheetOpen(true); }}
            onDelete={deleteCity}
            onAdd={handleFabClick}
            onGoToNaciones={() => setActiveTab('naciones')}
          />
        </div>

        <div className={`absolute inset-0 ${activeTab === 'mapa' ? '' : 'hidden'}`}>
          <MapaTab
            nations={nations} cities={cities}
            isActive={activeTab === 'mapa'}
            isSelectingLocation={isMapClickMode}
            draftCityName={cityDraft?.name}
            onLocationSelect={handleMapLocationSelect}
            onCancelSelection={cancelMapSelection}
          />
        </div>

        <div className={`absolute inset-0 overflow-y-auto ${activeTab === 'eventos' ? '' : 'hidden'}`}>
          <EventosTab
            events={events}
            onAdd={handleFabClick}
            onDelete={deleteEvent}
          />
        </div>
      </main>

      {/* FAB */}
      {showFab && (
        <button
          data-testid="button-fab"
          onClick={handleFabClick}
          className="fixed right-5 w-14 h-14 bg-[#c9a24c] rounded-full flex items-center justify-center shadow-xl active:scale-95 transition-transform z-40 text-[#0e1720]"
          style={{ bottom: 'calc(env(safe-area-inset-bottom) + 4.75rem)' }}
        >
          <Plus size={28} strokeWidth={2.5} />
        </button>
      )}

      {/* Bottom Tab Bar */}
      <nav
        className="flex-shrink-0 bg-[#16212b] border-t border-[#2a3a47] z-50"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className="flex h-14">
          {(
            [
              { id: 'naciones', label: 'Naciones', Icon: Flag },
              { id: 'ciudades', label: 'Ciudades', Icon: Castle },
              { id: 'mapa',     label: 'Mapa',     Icon: Map },
              { id: 'eventos',  label: 'Eventos',  Icon: ScrollText },
            ] as { id: Tab; label: string; Icon: React.FC<{ size?: number }> }[]
          ).map(({ id, label, Icon }) => (
            <button
              key={id}
              data-testid={`tab-${id}`}
              onClick={() => setActiveTab(id)}
              className={`flex-1 flex flex-col items-center justify-center gap-0.5 transition-colors ${
                activeTab === id ? 'text-[#c9a24c]' : 'text-[#ece7d9]/35'
              }`}
            >
              <Icon size={19} />
              <span className="text-[9px] font-sans font-medium uppercase tracking-wider">{label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Sheets */}
      <NationSheet
        open={nationSheetOpen}
        onOpenChange={setNationSheetOpen}
        nation={editingNation}
        onSave={n => editingNation ? updateNation(editingNation.id, n) : addNation(n as Omit<Nation, 'id' | 'createdAt'>)}
      />
      <CitySheet
        open={citySheetOpen}
        onOpenChange={setCitySheetOpen}
        city={editingCity}
        nations={nations}
        draftData={cityDraft}
        onRequestMapSelection={requestMapSelection}
        onSave={c => editingCity ? updateCity(editingCity.id, c) : addCity(c as Omit<City, 'id' | 'createdAt'>)}
      />
      <EventSheet
        open={eventSheetOpen}
        onOpenChange={setEventSheetOpen}
        nations={nations}
        cities={cities}
        currentDate={currentDate}
        onSave={handleEventSave}
      />
    </div>
  );
}
