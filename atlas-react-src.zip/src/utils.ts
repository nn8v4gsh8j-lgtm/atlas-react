import { AtlasEvent, Nation, EventType } from './types';

// ─── Human-readable event description (generated, never stored) ──────────────

export function describeEvent(event: AtlasEvent, nations: Nation[]): string {
  const acting = nations.find(n => n.id === event.nation);
  const target = event.targetNation !== undefined ? nations.find(n => n.id === event.targetNation) : undefined;

  switch (event.type) {
    case 'nationFounded':
      return `Se funda con capital ${event.city.name}`;

    case 'increaseMilitaryPower':
      return `${event.city.name} genera poder militar`;

    case 'developInfrastructure':
      return `${event.city.name} mejora su infraestructura`;

    case 'attack': {
      if (!event.targetCity) {
        return `${event.city.name} no encontró objetivos válidos`;
      }
      // Format: [attacking nation] ataca [defending city] ([defending nation]) desde [attacking city]
      return `${acting?.name ?? '?'} ataca ${event.targetCity.name} (${target?.name ?? '?'}) desde ${event.city.name}`;
    }
  }
}

export function describeResult(event: AtlasEvent, nations: Nation[]): string | undefined {
  switch (event.type) {
    case 'nationFounded':
      return `Capital en (${event.city.latitude.toFixed(2)}, ${event.city.longitude.toFixed(2)}) · Infra: 1 · PM: 0`;

    case 'increaseMilitaryPower': {
      // Increment = infrastructureLevel at time of event (it's in the snapshot)
      const gain = event.city.infrastructureLevel;
      const total = event.city.militaryPower;
      return `PM +${gain} → PM total: ${total}`;
    }

    case 'developInfrastructure':
      return event.city.developmentPoints === 0
        ? `Sube a nivel de infraestructura ${event.city.infrastructureLevel}`
        : `Progreso: ${event.city.developmentPoints}/${event.city.infrastructureLevel} pts para nivel ${event.city.infrastructureLevel + 1}`;

    case 'attack':
      return undefined; // battle detail shown in the card preview
  }
}

// ─── Derived battle state ─────────────────────────────────────────────────────

export function wasVictory(event: AtlasEvent): boolean {
  return event.type === 'attack' && event.city.militaryPower >= 1;
}

export function wasConquest(event: AtlasEvent): boolean {
  return wasVictory(event) &&
    event.targetCity !== undefined &&
    event.targetCity.nationId !== event.targetNation;
}

export function wasNationDefeated(event: AtlasEvent, cities: { nationId: number }[]): boolean {
  if (!wasConquest(event) || event.targetNation === undefined) return false;
  return !cities.some(c => c.nationId === event.targetNation);
}

export function wasRepelled(event: AtlasEvent): boolean {
  // Defender wins (attacker PM went to 0) and city was NOT conquered
  return event.type === 'attack' &&
    event.targetCity !== undefined &&
    event.city.militaryPower === 0 &&
    event.targetCity.nationId === event.targetNation;
}

// True only for the single attack event that actually eliminated a nation
// (its last remaining city being conquered) — as opposed to wasNationDefeated,
// which is true for any conquest event against a nation that currently has 0
// cities, even earlier ones that didn't finish the job.
export function causesNationDefeat(
  event: AtlasEvent,
  allEvents: AtlasEvent[],
  cities: { id: number; nationId: number }[],
): boolean {
  if (!wasNationDefeated(event, cities) || event.targetNation === undefined) return false;
  const lastConquest = [...allEvents]
    .filter(e => e.type === 'attack' && e.targetNation === event.targetNation && wasConquest(e))
    .sort((a, b) => b.id - a.id)[0];
  return lastConquest?.id === event.id;
}

// ─── Spreadsheet export (tab-separated row, one event per row) ────────────────
//
// Columns C, E and G describe "how likely/which option" this event was among
// the possibilities available at the time (mirroring what the random event
// generator would have rolled), even for manually-created events. To compute
// them we replay every earlier event (by id, which is always creation order)
// to reconstruct: which nations were active, which cities belonged to the
// acting nation, and since which event each of those cities had belonged to
// it — all as the world stood immediately BEFORE this event happened.

function formatDateDMY(iso: string): string {
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

interface WorldStateBefore {
  cityState: Map<number, { id: number; name: string; nationId: number; infrastructureLevel: number; developmentPoints: number; militaryPower: number }>;
  ownerSince: Map<number, number>; // cityId -> id of the event that most recently assigned it to its current nation
}

function computeStateBeforeEvent(targetEvent: AtlasEvent, allEvents: AtlasEvent[]): WorldStateBefore {
  const sorted = [...allEvents].sort((a, b) => a.id - b.id);
  const cityState: WorldStateBefore['cityState'] = new Map();
  const ownerSince: WorldStateBefore['ownerSince'] = new Map();

  for (const e of sorted) {
    if (e.id >= targetEvent.id) break;
    cityState.set(e.city.id, e.city);
    if (e.type === 'nationFounded') ownerSince.set(e.city.id, e.id);
    if (e.targetCity) {
      cityState.set(e.targetCity.id, e.targetCity);
      if (wasConquest(e)) ownerSince.set(e.targetCity.id, e.id);
    }
  }
  return { cityState, ownerSince };
}

// Position of `nationId` (1-indexed) among the nations that had ≥1 city right
// before this event, sorted by id (creation order) — plus the total count.
function nationPositionBefore(nationId: number, state: WorldStateBefore): { x: number; y: number } {
  const activeIds = [...new Set([...state.cityState.values()].map(c => c.nationId))].sort((a, b) => a - b);
  const y = activeIds.length;
  const x = activeIds.indexOf(nationId) + 1; // 0 if not found (shouldn't happen for non-founding events)
  return { x, y };
}

// Position of `cityId` (1-indexed, oldest tenure first) among the cities that
// belonged to `nationId` right before this event — plus the total count.
function cityPositionBefore(cityId: number, nationId: number, state: WorldStateBefore): { x: number; y: number } {
  const nationCities = [...state.cityState.values()].filter(c => c.nationId === nationId);
  const sorted = nationCities.sort((a, b) => (state.ownerSince.get(a.id) ?? 0) - (state.ownerSince.get(b.id) ?? 0));
  const y = sorted.length;
  const x = sorted.findIndex(c => c.id === cityId) + 1;
  return { x, y };
}

export function buildEventExportRow(event: AtlasEvent, allEvents: AtlasEvent[], nations: Nation[], cities: { id: number; nationId: number }[]): string {
  const nationName = (id: number | undefined) => (id !== undefined ? nations.find(n => n.id === id)?.name ?? '?' : '?');
  const state = computeStateBeforeEvent(event, allEvents);

  const colA = formatDateDMY(event.date);
  let colB = '';
  let colC = '';
  let colD = '';
  let colE = '';
  let colF = '';
  let colG = '';
  let colH = '';
  let colI = '';
  let colJ = '';
  let colK = '';

  if (event.type === 'nationFounded') {
    const { y } = nationPositionBefore(event.nation, state); // nation doesn't exist yet — position is always n+1
    colB = 'N';
    colC = `${y + 1}/${y}`;
    colD = `${nationName(event.nation)} (${event.nation})`;
    colF = `${event.city.name} (${event.city.id})`;
    colH = `Se funda ${nationName(event.nation)} (${event.nation}), con capital en ${event.city.name} (${event.city.id})`;
  } else {
    const { x: nx, y: ny } = nationPositionBefore(event.nation, state);
    colC = `${nx}/${ny}`;
    const { x: cx, y: cy } = cityPositionBefore(event.city.id, event.nation, state);
    colE = `${cx}/${cy}`;
    const beforeCity = state.cityState.get(event.city.id);

    if (event.type === 'increaseMilitaryPower') {
      colD = `${nationName(event.nation)} (${event.nation})`;
      colF = `${event.city.name} (${event.city.id})`;
      const canAttackBefore = !!beforeCity && beforeCity.militaryPower > 0 && beforeCity.infrastructureLevel > 1 &&
        [...state.cityState.values()].some(c => c.nationId !== event.nation && c.infrastructureLevel > 1);
      colG = `1/${canAttackBefore ? 3 : 2}`;
      colH = 'Produce poder';
      const before = beforeCity?.militaryPower ?? 0;
      colI = `+${event.city.militaryPower - before}`;
      colJ = `${before} -> ${event.city.militaryPower}`;
    }

    if (event.type === 'developInfrastructure') {
      colD = `${nationName(event.nation)} (${event.nation})`;
      colF = `${event.city.name} (${event.city.id})`;
      const canAttackBefore = !!beforeCity && beforeCity.militaryPower > 0 && beforeCity.infrastructureLevel > 1 &&
        [...state.cityState.values()].some(c => c.nationId !== event.nation && c.infrastructureLevel > 1);
      colG = `2/${canAttackBefore ? 3 : 2}`;
      colH = 'Mejora infraestructura';
      colI = '+1';
      const Z = beforeCity?.infrastructureLevel ?? event.city.infrastructureLevel;
      const devBefore = beforeCity?.developmentPoints ?? 0;
      const leveled = event.city.infrastructureLevel > Z;
      const devAfter = leveled ? Z : event.city.developmentPoints;
      colJ = `${devBefore}/${Z} -> ${devAfter}/${Z}`;
      if (leveled) colK = `Sube a nivel ${event.city.infrastructureLevel}`;
    }

    if (event.type === 'attack') {
      const attackerName = nationName(event.nation);
      const defenderName = event.targetNation !== undefined ? nationName(event.targetNation) : undefined;
      colD = defenderName !== undefined
        ? `${attackerName} (${event.nation}) -> ${defenderName} (${event.targetNation})`
        : `${attackerName} (${event.nation})`;
      colF = event.targetCity
        ? `${event.city.name} (${event.city.id}) -> ${event.targetCity.name} (${event.targetCity.id})`
        : `${event.city.name} (${event.city.id})`;
      colG = '3/3'; // this event happening at all proves attack was one of the (3) available options

      if (!event.targetCity) {
        colH = `${attackerName} ataca desde ${event.city.name} (${event.city.id}) pero no encuentra objetivos válidos`;
      } else {
        colH = `${attackerName} ataca ${event.targetCity.name} (${event.targetCity.id}) desde ${event.city.name} (${event.city.id})`;
        colI = `${event.attackerInitialPM ?? '?'} vs ${event.defenderInitialPM ?? '?'}`;
        colJ = `${event.attackerInitialPM ?? '?'} -> ${event.city.militaryPower} / ${event.defenderInitialPM ?? '?'} -> ${event.targetCity.militaryPower}`;

        if (wasConquest(event)) {
          const ndAfter = event.targetCity.infrastructureLevel;
          colK = `${attackerName} conquista ${event.targetCity.name}. ${event.targetCity.name} pierde 1 nivel (${ndAfter + 1} -> ${ndAfter})`;
          if (causesNationDefeat(event, allEvents, cities) && defenderName !== undefined) {
            colK += `. ${defenderName} es derrotada`;
            colB = 'D';
          }
        }
      }
    }
  }

  // Google Sheets auto-detects "X/Y"-shaped text as a date and "+X" as a
  // formula/number, mangling these columns on paste. A leading apostrophe
  // forces Sheets to store the value as literal text instead.
  const asText = (v: string) => (v === '' ? '' : `'${v}`);

  return [colA, colB, asText(colC), colD, asText(colE), colF, asText(colG), colH, asText(colI), colJ, colK].join('\t');
}

// ─── Display helpers ──────────────────────────────────────────────────────────

export const EVENT_META: Record<EventType, { label: string; color: string }> = {
  nationFounded:         { label: 'Fundación',       color: '#c9a24c' },
  increaseMilitaryPower: { label: 'Gen. Militar',    color: '#c47c3a' },
  developInfrastructure: { label: 'Mejora de Infra', color: '#4f9c8c' },
  attack:                { label: 'Ataque',           color: '#b5524a' },
};

export const MONTH_NAMES = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
export function formatDate(date: string): string {
  try {
    const [y, m, d] = date.split('-');
    return `${parseInt(d)} ${MONTH_NAMES[parseInt(m) - 1] ?? m} ${y}`;
  } catch { return date; }
}

// ─── Haversine ────────────────────────────────────────────────────────────────

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
