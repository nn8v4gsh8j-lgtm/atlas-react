import { AtlasEvent, Nation, EventType } from './types';

// ─── Human-readable event description (generated, never stored) ──────────────

export function describeEvent(event: AtlasEvent, nations: Nation[]): string {
  const acting = nations.find(n => n.id === event.nation);
  const target = event.targetNation !== undefined ? nations.find(n => n.id === event.targetNation) : undefined;

  switch (event.type) {
    case 'nationFounded':
      return `Se funda con capital ${event.city.name}`;

    case 'increaseMilitaryPower':
      return `${event.city.name} genera poder militar`;

    case 'developInfrastructure':
      return `${event.city.name} mejora su infraestructura`;

    case 'attack': {
      if (!event.targetCity) {
        return `${event.city.name} no encontró objetivos válidos`;
      }
      // Format: [attacking nation] ataca [defending city] ([defending nation]) desde [attacking city]
      return `${acting?.name ?? '?'} ataca ${event.targetCity.name} (${target?.name ?? '?'}) desde ${event.city.name}`;
    }
  }
}

export function describeResult(event: AtlasEvent, nations: Nation[]): string | undefined {
  switch (event.type) {
    case 'nationFounded':
      return `Capital en (${event.city.latitude.toFixed(2)}, ${event.city.longitude.toFixed(2)}) · Infra: 1 · PM: 0`;

    case 'increaseMilitaryPower': {
      // Increment = infrastructureLevel at time of event (it's in the snapshot)
      const gain = event.city.infrastructureLevel;
      const total = event.city.militaryPower;
      return `PM +${gain} → PM total: ${total}`;
    }

    case 'developInfrastructure':
      return event.city.developmentPoints === 0
        ? `Sube a nivel de infraestructura ${event.city.infrastructureLevel}`
        : `Progreso: ${event.city.developmentPoints}/${event.city.infrastructureLevel} pts para nivel ${event.city.infrastructureLevel + 1}`;

    case 'attack': {
      if (!event.targetCity) return undefined;
      const won       = event.city.militaryPower >= 1;
      const conquered = won && event.targetCity.nationId !== event.targetNation;

      const hasInitial = event.attackerInitialPM !== undefined && event.defenderInitialPM !== undefined;
      const initialLine = hasInitial
        ? `Fuerzas: ⚔ ${event.attackerInitialPM} PM vs 🛡 ${event.defenderInitialPM} PM`
        : undefined;

      if (won) {
        const resultLine = `Resultado: ⚔ ${event.city.militaryPower} PM restantes · 🛡 PM 0 · Infra ${event.targetCity.infrastructureLevel}${conquered ? ' · Conquistada' : ''}`;
        return [initialLine, resultLine].filter(Boolean).join('\n');
      }
      const resultLine = `Resultado: ⚔ PM 0 · 🛡 ${event.targetCity.militaryPower} PM restantes`;
      return [initialLine, resultLine].filter(Boolean).join('\n');
    }
  }
}

// ─── Derived battle state ─────────────────────────────────────────────────────

export function wasVictory(event: AtlasEvent): boolean {
  return event.type === 'attack' && event.city.militaryPower >= 1;
}

export function wasConquest(event: AtlasEvent): boolean {
  return wasVictory(event) &&
    event.targetCity !== undefined &&
    event.targetCity.nationId !== event.targetNation;
}

export function wasNationDefeated(event: AtlasEvent, cities: { nationId: number }[]): boolean {
  if (!wasConquest(event) || event.targetNation === undefined) return false;
  return !cities.some(c => c.nationId === event.targetNation);
}

export function wasRepelled(event: AtlasEvent): boolean {
  // Defender wins (attacker PM went to 0) and city was NOT conquered
  return event.type === 'attack' &&
    event.targetCity !== undefined &&
    event.city.militaryPower === 0 &&
    event.targetCity.nationId === event.targetNation;
}

// ─── Display helpers ──────────────────────────────────────────────────────────

export const EVENT_META: Record<EventType, { label: string; color: string }> = {
  nationFounded:         { label: 'Fundación',       color: '#c9a24c' },
  increaseMilitaryPower: { label: 'Gen. Militar',    color: '#c47c3a' },
  developInfrastructure: { label: 'Mejora de Infra', color: '#4f9c8c' },
  attack:                { label: 'Ataque',           color: '#b5524a' },
};

export const MONTH_NAMES = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
export function formatDate(date: string): string {
  try {
    const [y, m, d] = date.split('-');
    return `${parseInt(d)} ${MONTH_NAMES[parseInt(m) - 1] ?? m} ${y}`;
  } catch { return date; }
}

// ─── Haversine ────────────────────────────────────────────────────────────────

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
