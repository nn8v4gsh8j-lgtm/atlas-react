import { AtlasEvent, Nation, EventType } from './types';

// ─── Human-readable event description (generated, never stored) ──────────────

export function describeEvent(event: AtlasEvent, nations: Nation[]): string {
  const acting  = nations.find(n => n.id === event.nation);
  const target  = event.targetNation !== undefined ? nations.find(n => n.id === event.targetNation) : undefined;

  switch (event.type) {
    case 'nationFounded':
      return `${acting?.name ?? '?'} se funda con capital ${event.city.name}`;

    case 'increaseMilitaryPower':
      return `${event.city.name} genera poder militar · ${acting?.name ?? '?'}`;

    case 'developInfrastructure':
      return `${event.city.name} mejora su infraestructura · ${acting?.name ?? '?'}`;

    case 'attack': {
      if (!event.targetCity) {
        return `${event.city.name} (${acting?.name ?? '?'}) no encontró objetivos válidos`;
      }
      const won       = event.city.militaryPower >= 1;
      const conquered = won && event.targetCity.nationId !== event.targetNation;
      if (conquered)  return `${event.city.name} (${acting?.name ?? '?'}) conquista ${event.targetCity.name} (${target?.name ?? '?'})`;
      if (won)        return `${event.city.name} (${acting?.name ?? '?'}) derrota a ${event.targetCity.name} (${target?.name ?? '?'})`;
                      return `${event.city.name} (${acting?.name ?? '?'}) ataca ${event.targetCity.name} (${target?.name ?? '?'}) y es repelido`;
    }
  }
}

export function describeResult(event: AtlasEvent, nations: Nation[]): string | undefined {
  const acting = nations.find(n => n.id === event.nation);

  switch (event.type) {
    case 'nationFounded':
      return `Capital en (${event.city.latitude.toFixed(2)}, ${event.city.longitude.toFixed(2)}) · Infra: 1 · PM: 0`;

    case 'increaseMilitaryPower':
      return `PM total: ${event.city.militaryPower}`;

    case 'developInfrastructure':
      return event.city.developmentPoints === 0
        ? `Sube a nivel de infraestructura ${event.city.infrastructureLevel}`
        : `Progreso: ${event.city.developmentPoints}/${event.city.infrastructureLevel} pts para nivel ${event.city.infrastructureLevel + 1}`;

    case 'attack': {
      if (!event.targetCity) return undefined;
      const won       = event.city.militaryPower >= 1;
      const conquered = won && event.targetCity.nationId !== event.targetNation;
      if (won) {
        const parts = [
          'Victoria',
          `${event.city.name}: ${event.city.militaryPower} PM restantes`,
          `${event.targetCity.name}: PM 0 · Infra ${event.targetCity.infrastructureLevel}`,
        ];
        if (conquered) parts.push(`→ ${acting?.name ?? '?'}`);
        return parts.join(' · ');
      }
      return `Derrota · ${event.city.name}: PM 0 · ${event.targetCity.name}: ${event.targetCity.militaryPower} PM restantes`;
    }
  }
}

// ─── Derived battle state ─────────────────────────────────────────────────────

export function wasVictory(event: AtlasEvent): boolean {
  return event.type === 'attack' && event.city.militaryPower >= 1;
}

export function wasConquest(event: AtlasEvent): boolean {
  return wasVictory(event) &&
    event.targetCity !== undefined &&
    event.targetCity.nationId !== event.targetNation;
}

export function wasNationDefeated(event: AtlasEvent, cities: { nationId: number }[]): boolean {
  if (!wasConquest(event) || event.targetNation === undefined) return false;
  return !cities.some(c => c.nationId === event.targetNation);
}

// ─── Display helpers ──────────────────────────────────────────────────────────

export const EVENT_META: Record<EventType, { label: string; color: string }> = {
  nationFounded:         { label: 'Fundación',       color: '#c9a24c' },
  increaseMilitaryPower: { label: 'Gen. Militar',    color: '#b5524a' },
  developInfrastructure: { label: 'Mejora de Infra', color: '#4f9c8c' },
  attack:                { label: 'Ataque',           color: '#c47c3a' },
};

export const MONTH_NAMES = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
export function formatDate(date: string): string {
  try {
    const [y, m, d] = date.split('-');
    return `${parseInt(d)} ${MONTH_NAMES[parseInt(m) - 1] ?? m} ${y}`;
  } catch { return date; }
}

// ─── Haversine ────────────────────────────────────────────────────────────────

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
