import { useState, useEffect } from 'react';
import { Nation, City, GameEvent, EventInput, AtlasData } from '../types';

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function migrateCity(raw: Record<string, unknown>): City {
  const createdAt = (raw.createdAt as string) ?? new Date().toISOString();
  return {
    id: raw.id as string,
    name: raw.name as string,
    nationId: raw.nationId as string,
    latitude: raw.latitude as number,
    longitude: raw.longitude as number,
    nivelInfraestructura:
      (raw.nivelInfraestructura as number) ?? (raw.desarrolloNivel as number) ?? 1,
    puntosDesarrollo: (raw.puntosDesarrollo as number) ?? 0,
    poderMilitar: (raw.poderMilitar as number) ?? 0,
    createdAt,
    joinedNationAt: (raw.joinedNationAt as string) ?? createdAt,
  };
}

export function useAtlasData() {
  const [nations, setNations] = useState<Nation[]>(() => {
    try {
      const saved = localStorage.getItem('atlas_nations');
      if (!saved) return [];
      const raw = JSON.parse(saved) as Nation[];
      return raw.map(({ id, name, color, createdAt }) => ({ id, name, color, createdAt }));
    } catch { return []; }
  });

  const [cities, setCities] = useState<City[]>(() => {
    try {
      const saved = localStorage.getItem('atlas_cities');
      if (!saved) return [];
      return (JSON.parse(saved) as Record<string, unknown>[]).map(migrateCity);
    } catch { return []; }
  });

  const [events, setEvents] = useState<GameEvent[]>(() => {
    try {
      const saved = localStorage.getItem('atlas_events');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });

  const [currentDate, setCurrentDate] = useState<string>(() => {
    return localStorage.getItem('atlas_current_date') ?? '2026-01-10';
  });

  useEffect(() => { localStorage.setItem('atlas_nations',      JSON.stringify(nations)); }, [nations]);
  useEffect(() => { localStorage.setItem('atlas_cities',       JSON.stringify(cities));  }, [cities]);
  useEffect(() => { localStorage.setItem('atlas_events',       JSON.stringify(events));  }, [events]);
  useEffect(() => { localStorage.setItem('atlas_current_date', currentDate);             }, [currentDate]);

  // --- Nation CRUD ---
  const addNation = (n: Omit<Nation, 'id' | 'createdAt'>) =>
    setNations(prev => [...prev, { ...n, id: crypto.randomUUID(), createdAt: new Date().toISOString() }]);

  const updateNation = (id: string, n: Partial<Nation>) =>
    setNations(prev => prev.map(x => x.id === id ? { ...x, ...n } : x));

  const deleteNation = (id: string) => {
    setNations(prev => prev.filter(x => x.id !== id));
    setCities(prev => prev.filter(x => x.nationId !== id));
  };

  // --- City CRUD ---
  const addCity = (c: Omit<City, 'id' | 'createdAt' | 'joinedNationAt'>) => {
    const now = new Date().toISOString();
    setCities(prev => [...prev, { ...c, id: crypto.randomUUID(), createdAt: now, joinedNationAt: now }]);
  };

  const updateCity = (id: string, c: Partial<City>) =>
    setCities(prev => prev.map(x => x.id === id ? { ...x, ...c } : x));

  const deleteCity = (id: string) =>
    setCities(prev => prev.filter(x => x.id !== id));

  // --- Computed nation stats ---
  const getNationStats = (nationId: string) => {
    const nc = cities.filter(c => c.nationId === nationId);
    return {
      totalInfra: nc.reduce((s, c) => s + c.nivelInfraestructura, 0),
      totalMil:   nc.reduce((s, c) => s + c.poderMilitar, 0),
      cityCount:  nc.length,
    };
  };

  // --- Event mechanics ---
  const addEvent = (input: EventInput) => {
    const now = new Date().toISOString();
    let descripcion = '';
    let resultado: string | undefined;
    const extraFields: Partial<Pick<GameEvent, 'conquistaCity' | 'conquistaFromNation' | 'derrotaNacion'>> = {};

    switch (input.tipo) {
      case 'nueva_nacion': {
        const nationId = crypto.randomUUID();
        setNations(prev => [
          ...prev,
          { id: nationId, name: input.nombreNacion, color: input.color, createdAt: now },
        ]);
        setCities(prev => [
          ...prev,
          {
            id: crypto.randomUUID(),
            name: input.nombreCapital,
            nationId,
            latitude: input.latitude,
            longitude: input.longitude,
            nivelInfraestructura: 1,
            puntosDesarrollo: 0,
            poderMilitar: 0,
            createdAt: now,
            joinedNationAt: now,
          },
        ]);
        descripcion = `La nación "${input.nombreNacion}" se funda con capital "${input.nombreCapital}"`;
        resultado = `Capital en (${input.latitude.toFixed(2)}, ${input.longitude.toFixed(2)}) · Infra: 1 · Poder militar: 0`;
        break;
      }

      case 'generacion_poder_militar': {
        const city   = cities.find(c => c.id === input.cityId);
        if (!city) break;
        const nation = nations.find(n => n.id === city.nationId);
        const gained = city.nivelInfraestructura;
        setCities(prev => prev.map(c =>
          c.id === input.cityId ? { ...c, poderMilitar: c.poderMilitar + gained } : c,
        ));
        descripcion = `${city.name} (${nation?.name ?? '?'}) genera ${gained} pts de poder militar`;
        resultado   = `Poder militar total: ${city.poderMilitar + gained}`;
        break;
      }

      case 'mejora_infraestructura': {
        const city   = cities.find(c => c.id === input.cityId);
        if (!city) break;
        const nation = nations.find(n => n.id === city.nationId);
        const newPts = city.puntosDesarrollo + 1;
        const leveled = newPts >= city.nivelInfraestructura;
        const newInfra = leveled ? city.nivelInfraestructura + 1 : city.nivelInfraestructura;
        setCities(prev => prev.map(c =>
          c.id === input.cityId
            ? { ...c, puntosDesarrollo: leveled ? 0 : newPts, nivelInfraestructura: newInfra }
            : c,
        ));
        if (leveled) {
          descripcion = `${city.name} (${nation?.name ?? '?'}) avanza al nivel de infraestructura ${newInfra}`;
          resultado   = `Puntos de desarrollo reiniciados · Nivel anterior: ${city.nivelInfraestructura}`;
        } else {
          descripcion = `${city.name} (${nation?.name ?? '?'}) acumula puntos de desarrollo`;
          resultado   = `Progreso: ${newPts}/${city.nivelInfraestructura} para nivel ${city.nivelInfraestructura + 1}`;
        }
        break;
      }

      case 'ataque': {
        const attacker = cities.find(c => c.id === input.attackerCityId);
        if (!attacker) break;
        const attackerNation = nations.find(n => n.id === attacker.nationId);

        const eligible = cities.filter(
          c => c.nationId !== attacker.nationId && c.nivelInfraestructura > 1,
        );

        if (eligible.length === 0) {
          descripcion = `${attacker.name} no encontró objetivos válidos`;
          resultado   = 'No hay ciudades enemigas con infra > 1';
          break;
        }

        // Nearest by haversine
        const defender = eligible.reduce((best, t) =>
          haversineKm(attacker.latitude, attacker.longitude, t.latitude, t.longitude) <
          haversineKm(attacker.latitude, attacker.longitude, best.latitude, best.longitude)
            ? t : best,
        );
        const defenderNation = nations.find(n => n.id === defender.nationId);
        const dist = Math.round(haversineKm(attacker.latitude, attacker.longitude, defender.latitude, defender.longitude));

        const attackerPM = attacker.poderMilitar;
        const defenderPM = defender.poderMilitar;
        const attackerWins = attackerPM > defenderPM;

        if (attackerWins) {
          // Count remaining defender cities before conquest (excluding the one being conquered)
          const remainingDefenderCities = cities.filter(
            c => c.nationId === defender.nationId && c.id !== defender.id
          ).length;

          setCities(prev => prev.map(c => {
            if (c.id === attacker.id) {
              return { ...c, poderMilitar: Math.max(0, c.poderMilitar - defenderPM) };
            }
            if (c.id === defender.id) {
              return {
                ...c,
                poderMilitar: 0,
                nivelInfraestructura: Math.max(1, c.nivelInfraestructura - 1),
                nationId: attacker.nationId,
                joinedNationAt: now,
              };
            }
            return c;
          }));

          descripcion = `${attacker.name} (${attackerNation?.name ?? '?'}) conquista ${defender.name} (${defenderNation?.name ?? '?'})`;
          resultado   = `Victoria · ${attacker.name} pierde ${defenderPM} PM · ${defender.name} queda con PM 0, pierde 1 nivel de infra y pasa a ${attackerNation?.name ?? '?'} · Dist: ${dist} km`;

          // Inline conquest/defeat fields — no separate events needed
          extraFields.conquistaCity      = defender.name;
          extraFields.conquistaFromNation = defenderNation?.name ?? '?';
          if (remainingDefenderCities === 0) {
            extraFields.derrotaNacion = defenderNation?.name ?? '?';
          }
        } else {
          setCities(prev => prev.map(c => {
            if (c.id === attacker.id) return { ...c, poderMilitar: 0 };
            if (c.id === defender.id) return { ...c, poderMilitar: Math.max(0, c.poderMilitar - attackerPM) };
            return c;
          }));
          descripcion = `${attacker.name} (${attackerNation?.name ?? '?'}) ataca ${defender.name} (${defenderNation?.name ?? '?'}) y es repelido`;
          resultado   = `Derrota · ${attacker.name} pierde todo su PM · ${defender.name} conserva ${Math.max(0, defenderPM - attackerPM)} PM · Dist: ${dist} km`;
        }
        break;
      }
    }

    setEvents(prev => [
      ...prev,
      { id: crypto.randomUUID(), tipo: input.tipo, fecha: input.fecha, descripcion, resultado, createdAt: now, ...extraFields },
    ]);
  };

  const deleteEvent = (id: string) =>
    setEvents(prev => prev.filter(e => e.id !== id));

  const replaceData = (data: Partial<AtlasData> & { currentDate?: string }) => {
    if (data.nations) setNations(data.nations.map(({ id, name, color, createdAt }) => ({ id, name, color, createdAt })));
    if (data.cities)  setCities(data.cities.map(c => migrateCity(c as Record<string, unknown>)));
    if (data.events)  setEvents(data.events);
    if (data.currentDate) setCurrentDate(data.currentDate);
  };

  return {
    nations, cities, events,
    currentDate, setCurrentDate,
    addNation, updateNation, deleteNation,
    addCity, updateCity, deleteCity,
    addEvent, deleteEvent,
    getNationStats,
    replaceData,
  };
}
