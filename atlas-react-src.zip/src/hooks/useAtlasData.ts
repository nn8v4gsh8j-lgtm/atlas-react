import { useState, useEffect } from 'react';
import { Nation, City, AtlasEvent, EventInput, AtlasData, EventType } from '../types';
import { haversineKm } from '../utils';

// ─── Storage keys ─────────────────────────────────────────────────────────────
const K = {
  nations:     'atlas_v2_nations',
  cities:      'atlas_v2_cities',
  events:      'atlas_v2_events',
  currentDate: 'atlas_current_date',
};

// ─── ID helpers ───────────────────────────────────────────────────────────────
const nextId = (items: { id: number }[]): number =>
  items.length === 0 ? 1 : Math.max(...items.map(x => x.id)) + 1;

// ─── V1 → V2 migration ───────────────────────────────────────────────────────
/* eslint-disable @typescript-eslint/no-explicit-any */
function migrateFromV1(): Pick<AtlasData, 'nations' | 'cities' | 'events'> | null {
  try {
    const raw = localStorage.getItem('atlas_nations');
    if (!raw) return null;

    const oldNations: any[] = JSON.parse(raw);
    const oldCities:  any[] = JSON.parse(localStorage.getItem('atlas_cities')  ?? '[]');
    const oldEvents:  any[] = JSON.parse(localStorage.getItem('atlas_events')  ?? '[]');

    // Sort by createdAt for stable ID assignment
    oldNations.sort((a, b) => (a.createdAt ?? '').localeCompare(b.createdAt ?? ''));
    oldCities .sort((a, b) => (a.createdAt ?? '').localeCompare(b.createdAt ?? ''));
    oldEvents .sort((a, b) => (a.createdAt ?? '').localeCompare(b.createdAt ?? ''));

    // Build string→number ID maps
    const nationMap = new Map<string, number>();
    const cityMap   = new Map<string, number>();

    const nations: Nation[] = oldNations.map((n, i) => {
      const id = i + 1;
      nationMap.set(n.id, id);
      return { id, name: n.name, color: n.color };
    });

    const cities: City[] = oldCities.map((c, i) => {
      const id = i + 1;
      cityMap.set(c.id, id);
      return {
        id,
        name: c.name,
        nationId: nationMap.get(c.nationId) ?? 0,
        latitude:  c.latitude,
        longitude: c.longitude,
        infrastructureLevel: c.nivelInfraestructura ?? c.desarrolloNivel ?? 1,
        developmentPoints:   c.puntosDesarrollo ?? 0,
        militaryPower:       c.poderMilitar ?? 0,
      };
    });

    // Helper: find city by name in migrated list
    const findCity  = (name: string)       => cities.find(c => c.name === name);
    const findNation = (name: string)      => nations.find(n => n.name === name);

    const typeMap: Record<string, EventType | null> = {
      nueva_nacion:             'nationFounded',
      generacion_poder_militar: 'increaseMilitaryPower',
      mejora_infraestructura:   'developInfrastructure',
      ataque:                   'attack',
      conquista:                null,  // was auto-generated, now inline
      derrota_nacion:           null,  // was auto-generated, now inline
    };

    let evId = 1;
    const events: AtlasEvent[] = [];

    for (const old of oldEvents) {
      const newType = typeMap[old.tipo as string];
      if (!newType) continue;

      const desc: string = old.descripcion ?? '';
      let actingCity: City | undefined;
      let actingNationId = 0;
      let targetCity: City | undefined;
      let targetNationId: number | undefined;

      switch (newType) {
        case 'nationFounded': {
          // "La nación "X" se funda con capital "Y""
          const m = desc.match(/naci[oó]n "(.+?)" se funda con capital "(.+?)"/i);
          if (m) {
            const nation = findNation(m[1]);
            const city   = findCity(m[2]);
            if (nation) actingNationId = nation.id;
            if (city)   actingCity     = city;
          }
          break;
        }
        case 'increaseMilitaryPower':
        case 'developInfrastructure': {
          // "CityName (NationName) …"
          const m = desc.match(/^(.+?) \((.+?)\)/);
          if (m) {
            const nation = findNation(m[2]);
            const city   = findCity(m[1]);
            if (nation) actingNationId = nation.id;
            if (city)   actingCity     = city;
          }
          break;
        }
        case 'attack': {
          // "A (NA) conquista B (NB)" | "A (NA) ataca B (NB) y es repelido" | "A (NA) no encontró…"
          const mCon = desc.match(/^(.+?) \((.+?)\) conquista (.+?) \((.+?)\)/);
          const mAtk = desc.match(/^(.+?) \((.+?)\) ataca (.+?) \((.+?)\)/);
          const mNot = desc.match(/^(.+?) \((.+?)\) no encontr/);
          const m = mCon ?? mAtk;
          if (m) {
            const aN = findNation(m[2]);  const aC = findCity(m[1]);
            const dN = findNation(m[4]);  const dC = findCity(m[3]);
            if (aN) actingNationId = aN.id;
            if (dN) targetNationId = dN.id;
            if (aC) actingCity  = aC;
            if (dC) targetCity  = dC;
          } else if (mNot) {
            const aN = findNation(mNot[2]); const aC = findCity(mNot[1]);
            if (aN) actingNationId = aN.id;
            if (aC) actingCity  = aC;
          }
          break;
        }
      }

      if (!actingCity || actingNationId === 0) continue;

      events.push({
        id:   evId++,
        type: newType,
        date: old.fecha,
        nation: actingNationId,
        city:   actingCity,
        ...(targetNationId !== undefined && { targetNation: targetNationId }),
        ...(targetCity     !== undefined && { targetCity }),
      });
    }

    // Clean up old keys
    ['atlas_nations','atlas_cities','atlas_events'].forEach(k => localStorage.removeItem(k));

    return { nations, cities, events };
  } catch (e) {
    console.error('[Atlas] V1→V2 migration failed:', e);
    return null;
  }
}
/* eslint-enable @typescript-eslint/no-explicit-any */

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useAtlasData() {
  const [nations, setNations] = useState<Nation[]>(() => {
    try {
      // Try V2 first
      const v2 = localStorage.getItem(K.nations);
      if (v2) return JSON.parse(v2) as Nation[];
      // Try migration from V1
      const migrated = migrateFromV1();
      if (migrated) {
        localStorage.setItem(K.nations, JSON.stringify(migrated.nations));
        localStorage.setItem(K.cities,  JSON.stringify(migrated.cities));
        localStorage.setItem(K.events,  JSON.stringify(migrated.events));
        return migrated.nations;
      }
      return [];
    } catch { return []; }
  });

  const [cities, setCities] = useState<City[]>(() => {
    try {
      const v2 = localStorage.getItem(K.cities);
      if (v2) return JSON.parse(v2) as City[];
      return [];
    } catch { return []; }
  });

  const [events, setEvents] = useState<AtlasEvent[]>(() => {
    try {
      const v2 = localStorage.getItem(K.events);
      if (v2) return JSON.parse(v2) as AtlasEvent[];
      return [];
    } catch { return []; }
  });

  const [currentDate, setCurrentDate] = useState<string>(
    () => localStorage.getItem(K.currentDate) ?? '2026-01-10',
  );

  useEffect(() => { localStorage.setItem(K.nations,     JSON.stringify(nations)); }, [nations]);
  useEffect(() => { localStorage.setItem(K.cities,      JSON.stringify(cities));  }, [cities]);
  useEffect(() => { localStorage.setItem(K.events,      JSON.stringify(events));  }, [events]);
  useEffect(() => { localStorage.setItem(K.currentDate, currentDate);             }, [currentDate]);

  // ── Nation CRUD ────────────────────────────────────────────────────────────
  const addNation = (data: Omit<Nation, 'id'>) =>
    setNations(prev => [...prev, { ...data, id: nextId(prev) }]);

  const updateNation = (id: number, data: Partial<Nation>) =>
    setNations(prev => prev.map(n => n.id === id ? { ...n, ...data } : n));

  const deleteNation = (id: number) => {
    setNations(prev => prev.filter(n => n.id !== id));
    setCities (prev => prev.filter(c => c.nationId !== id));
  };

  // ── City CRUD ──────────────────────────────────────────────────────────────
  const addCity = (data: Omit<City, 'id'>) =>
    setCities(prev => [...prev, { ...data, id: nextId(prev) }]);

  const updateCity = (id: number, data: Partial<City>) =>
    setCities(prev => prev.map(c => c.id === id ? { ...c, ...data } : c));

  const deleteCity = (id: number) =>
    setCities(prev => prev.filter(c => c.id !== id));

  // ── Nation stats (derived) ─────────────────────────────────────────────────
  const getNationStats = (nationId: number) => {
    const nc = cities.filter(c => c.nationId === nationId);
    return {
      totalInfra: nc.reduce((s, c) => s + c.infrastructureLevel, 0),
      totalMil:   nc.reduce((s, c) => s + c.militaryPower, 0),
      cityCount:  nc.length,
    };
  };

  // ── Event mechanics ────────────────────────────────────────────────────────
  const addEvent = (input: EventInput) => {
    const date = currentDate;

    switch (input.type) {
      case 'nationFounded': {
        const newNationId = nextId(nations);
        const newCityId   = nextId(cities);

        const newNation: Nation = { id: newNationId, name: input.nationName, color: input.color };
        const newCity: City = {
          id: newCityId,
          name: input.capitalName,
          nationId: newNationId,
          latitude:  input.latitude,
          longitude: input.longitude,
          infrastructureLevel: 1,
          developmentPoints:   0,
          militaryPower:       0,
        };

        setNations(prev => [...prev, newNation]);
        setCities (prev => [...prev, newCity]);

        setEvents(prev => [...prev, {
          id: nextId(prev), type: 'nationFounded', date,
          nation: newNationId, city: newCity,
        }]);
        break;
      }

      case 'increaseMilitaryPower': {
        const city   = cities.find(c => c.id === input.cityId)!;
        const gained = city.infrastructureLevel;
        const after: City = { ...city, militaryPower: city.militaryPower + gained };
        setCities(prev => prev.map(c => c.id === city.id ? after : c));
        setEvents(prev => [...prev, {
          id: nextId(prev), type: 'increaseMilitaryPower', date,
          nation: city.nationId, city: after,
        }]);
        break;
      }

      case 'developInfrastructure': {
        const city    = cities.find(c => c.id === input.cityId)!;
        const newPts  = city.developmentPoints + 1;
        const leveled = newPts >= city.infrastructureLevel;
        const after: City = {
          ...city,
          developmentPoints:   leveled ? 0 : newPts,
          infrastructureLevel: leveled ? city.infrastructureLevel + 1 : city.infrastructureLevel,
        };
        setCities(prev => prev.map(c => c.id === city.id ? after : c));
        setEvents(prev => [...prev, {
          id: nextId(prev), type: 'developInfrastructure', date,
          nation: city.nationId, city: after,
        }]);
        break;
      }

      case 'attack': {
        const attacker = cities.find(c => c.id === input.attackerCityId)!;
        const eligible = cities.filter(
          c => c.nationId !== attacker.nationId && c.infrastructureLevel > 1,
        );

        if (eligible.length === 0) {
          // No targets — store event with no targetCity
          const afterAttacker: City = { ...attacker };
          setEvents(prev => [...prev, {
            id: nextId(prev), type: 'attack', date,
            nation: attacker.nationId, city: afterAttacker,
          }]);
          break;
        }

        // Nearest eligible city by haversine
        const defender = eligible.reduce((best, t) =>
          haversineKm(attacker.latitude, attacker.longitude, t.latitude, t.longitude) <
          haversineKm(attacker.latitude, attacker.longitude, best.latitude, best.longitude) ? t : best,
        );

        const aPM = attacker.militaryPower;
        const dPM = defender.militaryPower;
        const attackerWins = aPM > dPM;
        const defenderNationId = defender.nationId;

        let afterAttacker: City;
        let afterDefender: City;

        if (attackerWins) {
          afterAttacker = { ...attacker, militaryPower: aPM - dPM };
          afterDefender = {
            ...defender,
            militaryPower:       0,
            infrastructureLevel: Math.max(1, defender.infrastructureLevel - 1),
            developmentPoints:   0,
            nationId:            attacker.nationId,  // conquered!
          };
        } else {
          afterAttacker = { ...attacker, militaryPower: 0 };
          afterDefender = { ...defender, militaryPower: Math.max(0, dPM - aPM) };
        }

        setCities(prev => prev.map(c => {
          if (c.id === attacker.id) return afterAttacker;
          if (c.id === defender.id) return afterDefender;
          return c;
        }));

        setEvents(prev => [...prev, {
          id: nextId(prev), type: 'attack', date,
          nation:       attacker.nationId,
          city:         afterAttacker,
          targetNation: defenderNationId,
          targetCity:   afterDefender,
          attackerInitialPM: aPM,
          defenderInitialPM: dPM,
        }]);
        break;
      }
    }
  };

  const deleteEvent = (id: number) =>
    setEvents(prev => prev.filter(e => e.id !== id));

  // ── Import / export ────────────────────────────────────────────────────────
  const replaceData = (data: Partial<AtlasData>) => {
    if (data.nations)     setNations(data.nations);
    if (data.cities)      setCities(data.cities);
    if (data.events)      setEvents(data.events);
    if (data.currentDate) setCurrentDate(data.currentDate);
  };

  return {
    nations, cities, events,
    currentDate, setCurrentDate,
    addNation, updateNation, deleteNation,
    addCity, updateCity, deleteCity,
    addEvent, deleteEvent,
    getNationStats,
    replaceData,
  };
}
