import React, { useState, useEffect, useMemo } from 'react';
import { Drawer } from 'vaul';
import { Nation, City, EventInput, EventType } from '../types';
import { haversineKm } from '../utils';
import { Crown, Zap, TrendingUp, Crosshair, Swords, Shield } from 'lucide-react';

const PRESET_COLORS = ['#c9a24c','#4f9c8c','#b5524a','#5b7fa6','#8a6bbf','#c47c3a','#5a9e6f','#a64c6b'];

const TIPOS: { type: EventType; label: string; desc: string; color: string; Icon: React.FC<{ size?: number }> }[] = [
  { type: 'nationFounded',         label: 'Nueva Nación',    desc: 'Funda una nación con capital',          color: '#c9a24c', Icon: Crown      },
  { type: 'increaseMilitaryPower', label: 'Gen. Militar',    desc: 'Ciudad produce poder militar',          color: '#b5524a', Icon: Zap        },
  { type: 'developInfrastructure', label: 'Mejora de Infra', desc: 'Ciudad acumula un punto de desarrollo', color: '#4f9c8c', Icon: TrendingUp },
  { type: 'attack',                label: 'Ataque',          desc: 'Ciudad lanza un ataque al enemigo',     color: '#c47c3a', Icon: Crosshair  },
];

interface BattlePreview {
  attacker: City; attackerNation: Nation | undefined;
  defender: City; defenderNation: Nation | undefined;
  dist: number; attackerWins: boolean; noTarget: boolean;
}

function computeBattle(attackerCityId: number, cities: City[], nations: Nation[]): BattlePreview | null {
  const attacker = cities.find(c => c.id === attackerCityId);
  if (!attacker) return null;
  const attackerNation = nations.find(n => n.id === attacker.nationId);
  const eligible = cities.filter(c => c.nationId !== attacker.nationId && c.infrastructureLevel > 1);
  if (eligible.length === 0) {
    return { attacker, attackerNation, defender: attacker, defenderNation: undefined, dist: 0, attackerWins: false, noTarget: true };
  }
  const defender = eligible.reduce((best, t) =>
    haversineKm(attacker.latitude, attacker.longitude, t.latitude, t.longitude) <
    haversineKm(attacker.latitude, attacker.longitude, best.latitude, best.longitude) ? t : best,
  );
  const defenderNation = nations.find(n => n.id === defender.nationId);
  const dist = Math.round(haversineKm(attacker.latitude, attacker.longitude, defender.latitude, defender.longitude));
  const attackerWins = attacker.militaryPower > defender.militaryPower;
  return { attacker, attackerNation, defender, defenderNation, dist, attackerWins, noTarget: false };
}

interface EventSheetProps {
  open: boolean; onOpenChange: (o: boolean) => void;
  nations: Nation[]; cities: City[];
  currentDate: string;
  onSave: (input: EventInput) => void;
}

export const EventSheet: React.FC<EventSheetProps> = ({ open, onOpenChange, nations, cities, currentDate, onSave }) => {
  const [type, setType] = useState<EventType | null>(null);

  // nationFounded fields
  const [nationName,    setNationName]    = useState('');
  const [color,         setColor]         = useState(PRESET_COLORS[0]);
  const [capitalName,   setCapitalName]   = useState('');
  const [latStr,        setLatStr]        = useState('');
  const [lngStr,        setLngStr]        = useState('');
  const [latError,      setLatError]      = useState<string | null>(null);
  const [lngError,      setLngError]      = useState<string | null>(null);

  // city-selection fields
  const [nationFilterId, setNationFilterId] = useState<number | ''>('');
  const [cityId,         setCityId]         = useState<number | ''>('');
  const [attackerNationId, setAttackerNationId] = useState<number | ''>('');
  const [attackerCityId,   setAttackerCityId]   = useState<number | ''>('');

  useEffect(() => {
    if (!open) return;
    setType(null);
    setNationName(''); setColor(PRESET_COLORS[0]); setCapitalName('');
    setLatStr(''); setLngStr(''); setLatError(null); setLngError(null);
    setNationFilterId(''); setCityId('');
    setAttackerNationId(''); setAttackerCityId('');
  }, [open]);

  const norm = (v: string) => v.replace(',', '.');
  const validateLat = (v: string) => { const n = parseFloat(norm(v)); if (isNaN(n)) return 'Número inválido'; if (n < -90 || n > 90) return 'Entre −90 y 90'; return null; };
  const validateLng = (v: string) => { const n = parseFloat(norm(v)); if (isNaN(n)) return 'Número inválido'; if (n < -180 || n > 180) return 'Entre −180 y 180'; return null; };
  const coordsValid = !validateLat(latStr) && !validateLng(lngStr);

  const eligibleAttackers = cities.filter(c => c.militaryPower > 0 && c.infrastructureLevel > 1);
  // Only nations with at least one city are active (defeated nations have 0 cities)
  const activeNations = nations.filter(n => cities.some(c => c.nationId === n.id));
  const citiesOfNation    = nationFilterId !== '' ? cities.filter(c => c.nationId === nationFilterId) : [];
  const attackersOfNation = attackerNationId !== '' ? eligibleAttackers.filter(c => c.nationId === attackerNationId) : [];

  const battle = useMemo<BattlePreview | null>(() => {
    if (type !== 'attack' || attackerCityId === '') return null;
    return computeBattle(attackerCityId, cities, nations);
  }, [type, attackerCityId, cities, nations]);

  const getCityLabel = (c: City) => {
    const n = nations.find(x => x.id === c.nationId);
    return `${c.name} (${n?.name ?? '?'}) · Infra ${c.infrastructureLevel} · Mil ${c.militaryPower}`;
  };

  const selectedCity = cityId !== '' ? cities.find(c => c.id === cityId) : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!type) return;
    let input: EventInput;
    switch (type) {
      case 'nationFounded': {
        if (!nationName.trim() || !capitalName.trim()) return;
        const latErr = validateLat(latStr); const lngErr = validateLng(lngStr);
        if (latErr) { setLatError(latErr); return; }
        if (lngErr) { setLngError(lngErr); return; }
        input = { type, nationName: nationName.trim(), color, capitalName: capitalName.trim(), latitude: parseFloat(norm(latStr)), longitude: parseFloat(norm(lngStr)) };
        break;
      }
      case 'increaseMilitaryPower':
        if (cityId === '') return;
        input = { type, cityId };
        break;
      case 'developInfrastructure':
        if (cityId === '') return;
        input = { type, cityId };
        break;
      case 'attack':
        if (attackerCityId === '' || !battle || battle.noTarget) return;
        input = { type, attackerCityId };
        break;
    }
    onSave(input!);
    onOpenChange(false);
  };

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999]" />
        <Drawer.Content className="bg-[#16212b] border-t border-[#2a3a47] flex flex-col rounded-t-[20px] fixed bottom-0 left-0 right-0 z-[10000] outline-none max-h-[92vh]">
          <div className="p-4 rounded-t-[20px] overflow-y-auto" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)' }}>
            <div className="mx-auto w-12 h-1.5 rounded-full bg-[#2a3a47] mb-6" />
            <h2 className="text-2xl font-serif text-[#ece7d9] mb-6">Registrar Evento</h2>

            <form onSubmit={handleSubmit} className="flex flex-col gap-6">
              {/* Type grid */}
              <div className="flex flex-col gap-2">
                <label className="text-sm font-sans text-foreground/70">Tipo de evento</label>
                <div className="grid grid-cols-2 gap-2">
                  {TIPOS.map(({ type: t, label, desc, color: c, Icon }) => (
                    <button key={t} type="button" onClick={() => setType(t)}
                      className="flex flex-col items-start gap-1 p-3 rounded-xl border text-left transition-all active:scale-95"
                      style={{ borderColor: type === t ? c : '#2a3a47', backgroundColor: type === t ? `${c}18` : '#0e1720' }}>
                      <div className="flex items-center gap-2"><Icon size={13} />
                        <span className="font-sans text-xs font-semibold" style={{ color: type === t ? c : '#ece7d9' }}>{label}</span>
                      </div>
                      <span className="font-sans text-[10px] text-foreground/40 leading-tight">{desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* World date (read-only) */}
              <div className="flex items-center justify-between bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3">
                <span className="text-sm font-sans text-foreground/50">Fecha del mundo</span>
                <span className="text-[#c9a24c] font-mono">{currentDate}</span>
              </div>

              {/* ── Nation Founded ── */}
              {type === 'nationFounded' && (<>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-sans text-foreground/70">Nombre de la nación</label>
                  <input type="text" value={nationName} onChange={e => setNationName(e.target.value)} required placeholder="Imperio Romano..."
                    className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-serif text-lg focus:outline-none focus:border-[#c9a24c]" />
                </div>
                <div className="flex flex-col gap-3">
                  <label className="text-sm font-sans text-foreground/70">Color</label>
                  <div className="flex flex-wrap gap-3">
                    {PRESET_COLORS.map(pc => (
                      <button key={pc} type="button" onClick={() => setColor(pc)}
                        className={`w-9 h-9 rounded-full shadow-sm active:scale-95 transition-transform ${color === pc ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-[#16212b]' : ''}`}
                        style={{ backgroundColor: pc }} />
                    ))}
                    <div className="w-9 h-9 rounded-full overflow-hidden relative border border-[#2a3a47]">
                      <input type="color" value={color} onChange={e => setColor(e.target.value)} className="absolute w-[150%] h-[150%] cursor-pointer" />
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-sans text-foreground/70">Nombre de la capital</label>
                  <input type="text" value={capitalName} onChange={e => setCapitalName(e.target.value)} required placeholder="Roma..."
                    className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-serif text-lg focus:outline-none focus:border-[#c9a24c]" />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-sans text-foreground/70">Coordenadas de la capital</label>
                  <div className="flex gap-3">
                    <div className="flex-1 flex flex-col gap-1">
                      <span className="font-mono text-[10px] text-foreground/40 uppercase">Latitud (−90 a 90)</span>
                      <input type="text" value={latStr} onChange={e => { setLatStr(e.target.value); setLatError(null); }} onBlur={() => setLatError(validateLat(latStr))} placeholder="40.416"
                        className={`bg-[#0e1720] border rounded-lg px-3 py-2 text-[#c9a24c] font-mono text-sm focus:outline-none transition-colors ${latError ? 'border-[#b5524a]' : 'border-[#2a3a47] focus:border-[#c9a24c]'}`} />
                      {latError && <span className="font-sans text-[11px] text-[#b5524a]">{latError}</span>}
                    </div>
                    <div className="flex-1 flex flex-col gap-1">
                      <span className="font-mono text-[10px] text-foreground/40 uppercase">Longitud (−180 a 180)</span>
                      <input type="text" value={lngStr} onChange={e => { setLngStr(e.target.value); setLngError(null); }} onBlur={() => setLngError(validateLng(lngStr))} placeholder="-3.703"
                        className={`bg-[#0e1720] border rounded-lg px-3 py-2 text-[#c9a24c] font-mono text-sm focus:outline-none transition-colors ${lngError ? 'border-[#b5524a]' : 'border-[#2a3a47] focus:border-[#c9a24c]'}`} />
                      {lngError && <span className="font-sans text-[11px] text-[#b5524a]">{lngError}</span>}
                    </div>
                  </div>
                  <p className="font-mono text-[10px] text-foreground/30 mt-1">Capital: infra nivel 1 · poder militar 0</p>
                </div>
              </>)}

              {/* ── Increase Military Power / Develop Infrastructure ── */}
              {(type === 'increaseMilitaryPower' || type === 'developInfrastructure') && (
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-sans text-foreground/70">País</label>
                    {activeNations.length === 0
                      ? <p className="font-sans text-sm text-[#b5524a]">No hay naciones todavía.</p>
                      : <select value={String(nationFilterId)} onChange={e => { setNationFilterId(Number(e.target.value)); setCityId(''); }}
                          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c]">
                          <option value="">Selecciona un país</option>
                          {activeNations.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                        </select>
                    }
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-sans text-foreground/70">Ciudad</label>
                    {nationFilterId === ''
                      ? <p className="font-sans text-sm text-foreground/40">Elige primero un país.</p>
                      : citiesOfNation.length === 0
                      ? <p className="font-sans text-sm text-[#b5524a]">Este país no tiene ciudades.</p>
                      : <select value={String(cityId)} onChange={e => setCityId(Number(e.target.value))}
                          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c]">
                          <option value="">Selecciona una ciudad</option>
                          {citiesOfNation.map(c => <option key={c.id} value={c.id}>{getCityLabel(c)}</option>)}
                        </select>
                    }
                  </div>
                  {type === 'increaseMilitaryPower' && selectedCity && (
                    <p className="font-mono text-[11px] text-[#b5524a]">
                      Genera +{selectedCity.infrastructureLevel} pts · Nuevo total: {selectedCity.militaryPower + selectedCity.infrastructureLevel}
                    </p>
                  )}
                  {type === 'developInfrastructure' && selectedCity && (() => {
                    const next = selectedCity.developmentPoints + 1;
                    const up   = next >= selectedCity.infrastructureLevel;
                    return <p className="font-mono text-[11px] text-[#4f9c8c]">
                      {up ? `Sube al nivel de infraestructura ${selectedCity.infrastructureLevel + 1}` : `Progreso: ${next}/${selectedCity.infrastructureLevel} pts`}
                    </p>;
                  })()}
                </div>
              )}

              {/* ── Attack ── */}
              {type === 'attack' && (
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-sans text-foreground/70">País atacante</label>
                    <select value={String(attackerNationId)} onChange={e => { setAttackerNationId(Number(e.target.value)); setAttackerCityId(''); }}
                      className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c]">
                      <option value="">Selecciona un país</option>
                      {activeNations.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                    </select>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-sans text-foreground/70">Ciudad atacante</label>
                    {attackerNationId === ''
                      ? <p className="font-sans text-sm text-foreground/40">Elige primero un país.</p>
                      : attackersOfNation.length === 0
                      ? <p className="font-sans text-sm text-[#b5524a]">Ninguna ciudad elegible (PM &gt; 0 e infra &gt; 1).</p>
                      : <select value={String(attackerCityId)} onChange={e => setAttackerCityId(Number(e.target.value))}
                          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c]">
                          <option value="">Selecciona ciudad atacante</option>
                          {attackersOfNation.map(c => <option key={c.id} value={c.id}>{getCityLabel(c)}</option>)}
                        </select>
                    }
                  </div>

                  {/* Battle preview */}
                  {battle && !battle.noTarget && (
                    <div className="rounded-xl border border-[#2a3a47] overflow-hidden">
                      <div className="bg-[#0e1720] px-4 py-2 flex items-center gap-2">
                        <Swords size={13} className="text-[#c9a24c]" />
                        <span className="font-mono text-[10px] text-[#c9a24c] uppercase tracking-widest">Preview de batalla</span>
                        <span className="font-mono text-[10px] text-foreground/30 ml-auto">{battle.dist} km</span>
                      </div>
                      <div className="grid grid-cols-2 divide-x divide-[#2a3a47]">
                        <div className="p-3 flex flex-col gap-1.5">
                          <div className="flex items-center gap-1.5 mb-1"><Swords size={11} className="text-[#b5524a]" /><span className="font-mono text-[9px] text-[#b5524a] uppercase">Atacante</span></div>
                          <p className="font-serif text-[14px] text-[#ece7d9]">{battle.attacker.name}</p>
                          <p className="font-mono text-[10px] text-foreground/40">{battle.attackerNation?.name ?? '?'}</p>
                          <div className="flex items-center gap-1 mt-1"><span className="font-mono text-[9px] text-[#4f9c8c] uppercase">Infra</span><span className="font-mono text-[11px] text-[#4f9c8c] font-semibold">{battle.attacker.infrastructureLevel}</span></div>
                          <div className="flex items-center gap-1"><span className="font-mono text-[9px] text-[#b5524a] uppercase">⚔ PM</span><span className="font-mono text-[18px] text-[#b5524a] font-bold">{battle.attacker.militaryPower}</span></div>
                        </div>
                        <div className="p-3 flex flex-col gap-1.5">
                          <div className="flex items-center gap-1.5 mb-1"><Shield size={11} className="text-[#4f9c8c]" /><span className="font-mono text-[9px] text-[#4f9c8c] uppercase">Defensor</span></div>
                          <p className="font-serif text-[14px] text-[#ece7d9]">{battle.defender.name}</p>
                          <p className="font-mono text-[10px] text-foreground/40">{battle.defenderNation?.name ?? '?'}</p>
                          <div className="flex items-center gap-1 mt-1"><span className="font-mono text-[9px] text-[#4f9c8c] uppercase">Infra</span><span className="font-mono text-[11px] text-[#4f9c8c] font-semibold">{battle.defender.infrastructureLevel}</span></div>
                          <div className="flex items-center gap-1"><span className="font-mono text-[9px] text-[#4f9c8c] uppercase">🛡 PM</span><span className="font-mono text-[18px] text-[#4f9c8c] font-bold">{battle.defender.militaryPower}</span></div>
                        </div>
                      </div>
                      <div className="px-4 py-3 flex items-center gap-2"
                        style={{ backgroundColor: battle.attackerWins ? '#b5524a18' : '#4f9c8c18', borderTop: `1px solid ${battle.attackerWins ? '#b5524a40' : '#4f9c8c40'}` }}>
                        <span className="font-mono text-[10px] uppercase tracking-widest" style={{ color: battle.attackerWins ? '#b5524a' : '#4f9c8c' }}>
                          {battle.attackerWins ? '⚔ Victoria prevista' : '🛡 Defensa prevista'}
                        </span>
                        <span className="font-mono text-[9px] text-foreground/40 ml-auto">
                          {battle.attackerWins ? `${battle.defender.name} conquistada` : `${battle.attacker.name} pierde todo su PM`}
                        </span>
                      </div>
                    </div>
                  )}
                  {battle?.noTarget && <p className="font-sans text-sm text-foreground/50 italic">No hay objetivos válidos (ninguna ciudad enemiga con infra &gt; 1).</p>}
                </div>
              )}

              {type && (
                <button type="submit"
                  disabled={(type === 'attack' && (!battle || battle.noTarget)) || (type === 'nationFounded' && !coordsValid)}
                  className="mt-2 bg-[#c9a24c] text-[#0e1720] font-sans font-semibold py-4 rounded-xl active:bg-[#a8863c] transition-colors disabled:opacity-40 disabled:pointer-events-none">
                  {type === 'attack' ? '⚔ Realizar Ataque' : 'Registrar Evento'}
                </button>
              )}
            </form>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
};
