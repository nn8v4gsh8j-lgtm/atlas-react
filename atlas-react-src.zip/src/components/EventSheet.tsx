import React, { useState, useEffect, useMemo } from 'react';
import { Drawer } from 'vaul';
import { Nation, City, EventInput, TipoEvento } from '../types';
import { Crown, Zap, TrendingUp, Crosshair, Swords, Shield } from 'lucide-react';
import { haversineKm } from '../hooks/useAtlasData';

const PRESET_COLORS = [
  '#c9a24c', '#4f9c8c', '#b5524a', '#5b7fa6',
  '#8a6bbf', '#c47c3a', '#5a9e6f', '#a64c6b',
];

const TIPOS: { tipo: TipoEvento; label: string; desc: string; color: string; Icon: React.FC<{ size?: number }> }[] = [
  { tipo: 'nueva_nacion',            label: 'Nueva Nación',     desc: 'Funda una nación con capital',         color: '#c9a24c', Icon: Crown },
  { tipo: 'generacion_poder_militar',label: 'Gen. Militar',     desc: 'Ciudad produce poder militar',         color: '#b5524a', Icon: Zap },
  { tipo: 'mejora_infraestructura',  label: 'Mejora de Infra',  desc: 'Ciudad acumula un punto de desarrollo', color: '#4f9c8c', Icon: TrendingUp },
  { tipo: 'ataque',                  label: 'Ataque',            desc: 'Ciudad lanza un ataque al enemigo',   color: '#c47c3a', Icon: Crosshair },
];

interface BattlePreview {
  attacker: City;
  attackerNation: Nation | undefined;
  defender: City | null;
  defenderNation: Nation | undefined;
  dist: number;
  attackerWins: boolean;
  noTarget: boolean;
}

function computeBattle(attackerCityId: string, cities: City[], nations: Nation[]): BattlePreview | null {
  const attacker = cities.find(c => c.id === attackerCityId);
  if (!attacker) return null;
  const attackerNation = nations.find(n => n.id === attacker.nationId);

  const eligible = cities.filter(c => c.nationId !== attacker.nationId && c.nivelInfraestructura > 1);

  if (eligible.length === 0) {
    return { attacker, attackerNation, defender: null, defenderNation: undefined, dist: 0, attackerWins: false, noTarget: true };
  }

  const defender = eligible.reduce((best, t) =>
    haversineKm(attacker.latitude, attacker.longitude, t.latitude, t.longitude) <
    haversineKm(attacker.latitude, attacker.longitude, best.latitude, best.longitude) ? t : best,
  );
  const defenderNation = nations.find(n => n.id === defender.nationId);
  const dist = Math.round(haversineKm(attacker.latitude, attacker.longitude, defender.latitude, defender.longitude));
  const attackerWins = attacker.poderMilitar > defender.poderMilitar;

  return { attacker, attackerNation, defender, defenderNation, dist, attackerWins, noTarget: false };
}

interface EventSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  nations: Nation[];
  cities: City[];
  currentDate: string;
  onSave: (input: EventInput) => void;
}

export const EventSheet: React.FC<EventSheetProps> = ({ open, onOpenChange, nations, cities, currentDate, onSave }) => {
  const [tipo, setTipo] = useState<TipoEvento | null>(null);

  // nueva_nacion
  const [nombreNacion,   setNombreNacion]   = useState('');
  const [color,          setColor]          = useState(PRESET_COLORS[0]);
  const [nombreCapital,  setNombreCapital]  = useState('');
  const [latStr,         setLatStr]         = useState('');
  const [lngStr,         setLngStr]         = useState('');
  const [latError,       setLatError]       = useState<string | null>(null);
  const [lngError,       setLngError]       = useState<string | null>(null);

  // generacion / mejora
  const [nationFilterId, setNationFilterId] = useState('');
  const [cityId,         setCityId]         = useState('');

  // ataque
  const [attackerNationId, setAttackerNationId] = useState('');
  const [attackerCityId, setAttackerCityId] = useState('');

  useEffect(() => {
    if (!open) return;
    setTipo(null);
    setNombreNacion('');
    setColor(PRESET_COLORS[0]);
    setNombreCapital('');
    setLatStr('');
    setLngStr('');
    setLatError(null);
    setLngError(null);
    setNationFilterId('');
    setCityId('');
    setAttackerNationId('');
    setAttackerCityId('');
  }, [open]);

  // Normalise decimal separator: accept both '.' and ','
  const normalizeDecimal = (v: string) => v.replace(',', '.');

  // Coordinate validation
  const validateLat = (v: string): string | null => {
    const s = normalizeDecimal(v).trim();
    if (s === '' || s === '-') return 'Introduce una latitud';
    const n = parseFloat(s);
    if (isNaN(n)) return 'Debe ser un número';
    if (n < -90 || n > 90) return 'La latitud debe estar entre −90 y 90';
    return null;
  };
  const validateLng = (v: string): string | null => {
    const s = normalizeDecimal(v).trim();
    if (s === '' || s === '-') return 'Introduce una longitud';
    const n = parseFloat(s);
    if (isNaN(n)) return 'Debe ser un número';
    if (n < -180 || n > 180) return 'La longitud debe estar entre −180 y 180';
    return null;
  };
  const coordsValid =
    !validateLat(latStr) && !validateLng(lngStr);

  const attackerEligible = cities.filter(c => c.poderMilitar > 0 && c.nivelInfraestructura > 1);
  const citiesOfNation = nationFilterId ? cities.filter(c => c.nationId === nationFilterId) : [];
  const attackerEligibleOfNation = attackerNationId ? attackerEligible.filter(c => c.nationId === attackerNationId) : [];

  const battle = useMemo<BattlePreview | null>(() => {
    if (tipo !== 'ataque' || !attackerCityId) return null;
    return computeBattle(attackerCityId, cities, nations);
  }, [tipo, attackerCityId, cities, nations]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tipo) return;
    const fecha = currentDate;
    let input: EventInput;
    switch (tipo) {
      case 'nueva_nacion': {
        if (!nombreNacion.trim() || !nombreCapital.trim()) return;
        const latErr = validateLat(latStr);
        const lngErr = validateLng(lngStr);
        if (latErr) { setLatError(latErr); return; }
        if (lngErr) { setLngError(lngErr); return; }
        input = { tipo, fecha, nombreNacion: nombreNacion.trim(), color, nombreCapital: nombreCapital.trim(), latitude: parseFloat(normalizeDecimal(latStr)), longitude: parseFloat(normalizeDecimal(lngStr)) };
        break;
      }
      case 'generacion_poder_militar':
        if (!cityId) return;
        input = { tipo, fecha, cityId };
        break;
      case 'mejora_infraestructura':
        if (!cityId) return;
        input = { tipo, fecha, cityId };
        break;
      case 'ataque':
        if (!attackerCityId || !battle || battle.noTarget || !battle.defender) return;
        input = { tipo, fecha, attackerCityId };
        break;
    }
    onSave(input!);
    onOpenChange(false);
  };

  const getCityLabel = (c: City) => {
    const n = nations.find(x => x.id === c.nationId);
    return `${c.name} (${n?.name ?? '?'}) · Infra ${c.nivelInfraestructura} · Mil ${c.poderMilitar}`;
  };

  const selectedCity = cityId ? cities.find(c => c.id === cityId) : null;

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999]" />
        <Drawer.Content className="bg-[#16212b] border-t border-[#2a3a47] flex flex-col rounded-t-[20px] fixed bottom-0 left-0 right-0 z-[10000] outline-none max-h-[92vh]">
          <div className="p-4 rounded-t-[20px] overflow-y-auto" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)' }}>
            <div className="mx-auto w-12 h-1.5 rounded-full bg-[#2a3a47] mb-6" />
            <h2 className="text-2xl font-serif text-[#ece7d9] mb-6">Registrar Evento</h2>

            <form onSubmit={handleSubmit} className="flex flex-col gap-6">

              {/* Type selection grid */}
              <div className="flex flex-col gap-2">
                <label className="text-sm font-sans text-foreground/70">Tipo de evento</label>
                <div className="grid grid-cols-2 gap-2">
                  {TIPOS.map(({ tipo: t, label, desc, color: c, Icon }) => (
                    <button
                      key={t} type="button" onClick={() => setTipo(t)}
                      className="flex flex-col items-start gap-1 p-3 rounded-xl border text-left transition-all active:scale-95"
                      style={{ borderColor: tipo === t ? c : '#2a3a47', backgroundColor: tipo === t ? `${c}18` : '#0e1720' }}
                    >
                      <div className="flex items-center gap-2">
                        <Icon size={13} />
                        <span className="font-sans text-xs font-semibold" style={{ color: tipo === t ? c : '#ece7d9' }}>{label}</span>
                      </div>
                      <span className="font-sans text-[10px] text-foreground/40 leading-tight">{desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Date (global, read-only here) */}
              <div className="flex items-center justify-between bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3">
                <span className="text-sm font-sans text-foreground/50">Fecha del mundo</span>
                <span className="text-[#c9a24c] font-mono">{currentDate}</span>
              </div>

              {/* ── Nueva Nación ── */}
              {tipo === 'nueva_nacion' && (<>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-sans text-foreground/70">Nombre de la nación</label>
                  <input type="text" value={nombreNacion} onChange={e => setNombreNacion(e.target.value)} required
                    placeholder="Imperio Romano..." className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-serif text-lg focus:outline-none focus:border-[#c9a24c]" />
                </div>
                <div className="flex flex-col gap-3">
                  <label className="text-sm font-sans text-foreground/70">Color</label>
                  <div className="flex flex-wrap gap-3">
                    {PRESET_COLORS.map(pc => (
                      <button key={pc} type="button" onClick={() => setColor(pc)}
                        className={`w-9 h-9 rounded-full shadow-sm active:scale-95 transition-transform ${color === pc ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-[#16212b]' : ''}`}
                        style={{ backgroundColor: pc }} />
                    ))}
                    <div className="w-9 h-9 rounded-full overflow-hidden relative border border-[#2a3a47]">
                      <input type="color" value={color} onChange={e => setColor(e.target.value)} className="absolute w-[150%] h-[150%] cursor-pointer" />
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-sans text-foreground/70">Nombre de la capital</label>
                  <input type="text" value={nombreCapital} onChange={e => setNombreCapital(e.target.value)} required
                    placeholder="Roma..." className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-serif text-lg focus:outline-none focus:border-[#c9a24c]" />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-sans text-foreground/70">Coordenadas de la capital</label>
                  <div className="flex gap-3">
                    <div className="flex-1 flex flex-col gap-1">
                      <span className="font-mono text-[10px] text-foreground/40 uppercase">Latitud (−90 a 90)</span>
                      <input
                        type="text"
                        value={latStr}
                        onChange={e => { setLatStr(e.target.value); setLatError(null); }}
                        onBlur={() => setLatError(validateLat(latStr))}
                        placeholder="40.416"
                        className={`w-full bg-[#0e1720] border rounded-lg px-3 py-2 text-[#c9a24c] font-mono text-sm focus:outline-none transition-colors ${latError ? 'border-[#b5524a] focus:border-[#b5524a]' : 'border-[#2a3a47] focus:border-[#c9a24c]'}`}
                      />
                      {latError && (
                        <span className="font-sans text-[11px] text-[#b5524a] mt-0.5">{latError}</span>
                      )}
                    </div>
                    <div className="flex-1 flex flex-col gap-1">
                      <span className="font-mono text-[10px] text-foreground/40 uppercase">Longitud (−180 a 180)</span>
                      <input
                        type="text"
                        value={lngStr}
                        onChange={e => { setLngStr(e.target.value); setLngError(null); }}
                        onBlur={() => setLngError(validateLng(lngStr))}
                        placeholder="-3.703"
                        className={`w-full bg-[#0e1720] border rounded-lg px-3 py-2 text-[#c9a24c] font-mono text-sm focus:outline-none transition-colors ${lngError ? 'border-[#b5524a] focus:border-[#b5524a]' : 'border-[#2a3a47] focus:border-[#c9a24c]'}`}
                      />
                      {lngError && (
                        <span className="font-sans text-[11px] text-[#b5524a] mt-0.5">{lngError}</span>
                      )}
                    </div>
                  </div>
                  <p className="font-mono text-[10px] text-foreground/30 mt-1">Capital: infra nivel 1 · poder militar 0</p>
                </div>
              </>)}

              {/* ── Generación / Mejora ── */}
              {(tipo === 'generacion_poder_militar' || tipo === 'mejora_infraestructura') && (
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-sans text-foreground/70">País</label>
                    {nations.length === 0
                      ? <p className="font-sans text-sm text-[#b5524a]">No hay naciones todavía.</p>
                      : <select value={nationFilterId} onChange={e => { setNationFilterId(e.target.value); setCityId(''); }} required
                          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c]">
                          <option value="" disabled>Selecciona un país</option>
                          {nations.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                        </select>
                    }
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-sans text-foreground/70">Ciudad</label>
                    {!nationFilterId
                      ? <p className="font-sans text-sm text-foreground/40">Elige primero un país.</p>
                      : citiesOfNation.length === 0
                      ? <p className="font-sans text-sm text-[#b5524a]">Este país no tiene ciudades.</p>
                      : <select value={cityId} onChange={e => setCityId(e.target.value)} required
                          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c]">
                          <option value="" disabled>Selecciona una ciudad</option>
                          {citiesOfNation.map(c => <option key={c.id} value={c.id}>{getCityLabel(c)}</option>)}
                        </select>
                    }
                  </div>
                  {tipo === 'generacion_poder_militar' && selectedCity && (
                    <p className="font-mono text-[11px] text-[#b5524a] mt-1">
                      Genera +{selectedCity.nivelInfraestructura} pts · Nuevo total: {selectedCity.poderMilitar + selectedCity.nivelInfraestructura}
                    </p>
                  )}
                  {tipo === 'mejora_infraestructura' && selectedCity && (() => {
                    const next = selectedCity.puntosDesarrollo + 1;
                    const up   = next >= selectedCity.nivelInfraestructura;
                    return (
                      <p className="font-mono text-[11px] text-[#4f9c8c] mt-1">
                        {up ? `Sube al nivel de infraestructura ${selectedCity.nivelInfraestructura + 1}`
                           : `Progreso: ${next}/${selectedCity.nivelInfraestructura} pts para nivel ${selectedCity.nivelInfraestructura + 1}`}
                      </p>
                    );
                  })()}
                </div>
              )}

              {/* ── Ataque ── */}
              {tipo === 'ataque' && (
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-sans text-foreground/70">País atacante</label>
                    {nations.length === 0
                      ? <p className="font-sans text-sm text-[#b5524a]">No hay naciones todavía.</p>
                      : <select value={attackerNationId} onChange={e => { setAttackerNationId(e.target.value); setAttackerCityId(''); }} required
                          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c]">
                          <option value="" disabled>Selecciona un país</option>
                          {nations.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                        </select>
                    }
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-sans text-foreground/70">Ciudad atacante</label>
                    {!attackerNationId
                      ? <p className="font-sans text-sm text-foreground/40">Elige primero un país.</p>
                      : attackerEligibleOfNation.length === 0
                      ? <p className="font-sans text-sm text-[#b5524a]">
                          Ninguna ciudad elegible en este país. Se necesita poder militar &gt; 0 e infra &gt; 1.
                        </p>
                      : <select value={attackerCityId} onChange={e => setAttackerCityId(e.target.value)} required
                          className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c]">
                          <option value="">Selecciona ciudad atacante</option>
                          {attackerEligibleOfNation.map(c => <option key={c.id} value={c.id}>{getCityLabel(c)}</option>)}
                        </select>
                    }
                  </div>

                  {/* Battle preview */}
                  {battle && !battle.noTarget && battle.defender && (
                    <div className="rounded-xl border border-[#2a3a47] overflow-hidden">
                      {/* Header */}
                      <div className="bg-[#0e1720] px-4 py-2 flex items-center gap-2">
                        <Swords size={13} className="text-[#c9a24c]" />
                        <span className="font-mono text-[10px] text-[#c9a24c] uppercase tracking-widest">Preview de batalla</span>
                        <span className="font-mono text-[10px] text-foreground/30 ml-auto">{battle.dist} km</span>
                      </div>

                      {/* Two columns: attacker vs defender */}
                      <div className="grid grid-cols-2 divide-x divide-[#2a3a47]">
                        {/* Attacker */}
                        <div className="p-3 flex flex-col gap-1.5">
                          <div className="flex items-center gap-1.5 mb-1">
                            <Swords size={11} className="text-[#b5524a]" />
                            <span className="font-mono text-[9px] text-[#b5524a] uppercase tracking-widest">Atacante</span>
                          </div>
                          <p className="font-serif text-[14px] text-[#ece7d9] leading-tight">{battle.attacker.name}</p>
                          <p className="font-mono text-[10px] text-foreground/40">{battle.attackerNation?.name ?? '?'}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <span className="font-mono text-[9px] text-[#4f9c8c] uppercase">Infra</span>
                            <span className="font-mono text-[11px] text-[#4f9c8c] font-semibold">{battle.attacker.nivelInfraestructura}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="font-mono text-[9px] text-[#b5524a] uppercase">⚔ PM</span>
                            <span className="font-mono text-[18px] text-[#b5524a] font-bold leading-none">{battle.attacker.poderMilitar}</span>
                          </div>
                        </div>

                        {/* Defender */}
                        <div className="p-3 flex flex-col gap-1.5">
                          <div className="flex items-center gap-1.5 mb-1">
                            <Shield size={11} className="text-[#4f9c8c]" />
                            <span className="font-mono text-[9px] text-[#4f9c8c] uppercase tracking-widest">Defensor</span>
                          </div>
                          <p className="font-serif text-[14px] text-[#ece7d9] leading-tight">{battle.defender.name}</p>
                          <p className="font-mono text-[10px] text-foreground/40">{battle.defenderNation?.name ?? '?'}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <span className="font-mono text-[9px] text-[#4f9c8c] uppercase">Infra</span>
                            <span className="font-mono text-[11px] text-[#4f9c8c] font-semibold">{battle.defender.nivelInfraestructura}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="font-mono text-[9px] text-[#4f9c8c] uppercase">🛡 PM</span>
                            <span className="font-mono text-[18px] text-[#4f9c8c] font-bold leading-none">{battle.defender.poderMilitar}</span>
                          </div>
                        </div>
                      </div>

                      {/* Outcome prediction */}
                      <div
                        className="px-4 py-3 flex items-center gap-2"
                        style={{ backgroundColor: battle.attackerWins ? '#b5524a18' : '#4f9c8c18', borderTop: `1px solid ${battle.attackerWins ? '#b5524a40' : '#4f9c8c40'}` }}
                      >
                        <span className="font-mono text-[10px] uppercase tracking-widest" style={{ color: battle.attackerWins ? '#b5524a' : '#4f9c8c' }}>
                          {battle.attackerWins ? '⚔ Victoria prevista' : '🛡 Defensa prevista'}
                        </span>
                        {battle.attackerWins
                          ? <span className="font-mono text-[9px] text-foreground/40 ml-auto">
                              {battle.defender.name} conquistada · -{battle.defender.poderMilitar} PM al atacante
                            </span>
                          : <span className="font-mono text-[9px] text-foreground/40 ml-auto">
                              {battle.attacker.name} pierde todo su PM
                            </span>
                        }
                      </div>
                    </div>
                  )}

                  {battle?.noTarget && (
                    <p className="font-sans text-sm text-foreground/50 italic">
                      No hay objetivos válidos (ninguna ciudad enemiga con infra &gt; 1).
                    </p>
                  )}
                </div>
              )}

              {/* Submit button */}
              {tipo && (
                <button
                  type="submit"
                  disabled={
                    (tipo === 'ataque' && (!battle || battle.noTarget || !battle.defender)) ||
                    (tipo === 'nueva_nacion' && !coordsValid)
                  }
                  className="mt-2 bg-[#c9a24c] text-[#0e1720] font-sans font-semibold py-4 rounded-xl active:bg-[#a8863c] transition-colors disabled:opacity-40 disabled:pointer-events-none"
                >
                  {tipo === 'ataque' ? '⚔ Realizar Ataque' : 'Registrar Evento'}
                </button>
              )}
            </form>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
};
