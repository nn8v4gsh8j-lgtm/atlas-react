import React, { useMemo } from 'react';
import { Polygon } from 'react-leaflet';
import type { LatLngExpression } from 'leaflet';
import { Delaunay } from 'd3-delaunay';
import { simplify, combine, intersect, polygon as turfPolygon, featureCollection } from '@turf/turf';
import type { Feature, FeatureCollection, MultiPolygon, Polygon as GeoPolygon } from 'geojson';
import landRaw from '../data/land-110m.json';
import { Nation, City } from '../types';

interface VoronoiBordersProps {
  cities: City[];
  nations: Nation[];
}

// Turf space: [lng, lat]. Leaflet space: [lat, lng].
type LngLat = [number, number];
type LatLng = [number, number];
type LandShape = LatLngExpression[][] | LatLngExpression[][][];

// Bounding box for the Voronoi diagram, in [lng, lat] space. Padded well beyond
// the valid world extent (±180/±90) so that edge cities near the antimeridian
// or poles still get a sensibly clipped cell instead of an unbounded one.
const BOUNDS: [number, number, number, number] = [-200, -100, 200, 100];

// ─── land mask, precomputed once at module load — static data, computed only once
// per app lifetime, never re-derived per render or per city change ───────────────
const LAND_SIMPLIFY_TOLERANCE = 0.03; // degrees; coarse enough for a world-scale mobile map

const landMask: Feature<MultiPolygon> = (() => {
  const simplified = simplify(landRaw as FeatureCollection<GeoPolygon>, {
    tolerance: LAND_SIMPLIFY_TOLERANCE,
    highQuality: false,
  });
  const combined = combine(simplified as FeatureCollection<GeoPolygon>);
  return combined.features[0] as Feature<MultiPolygon>;
})();

// Clip a Voronoi cell ring (closed, [lng, lat] pairs) to land. Returns Leaflet-ready
// coordinates preserving the outer-ring/hole and single/multi-polygon nesting that
// Leaflet's <Polygon> expects, or null if the cell has no land at all (e.g. a city
// placed over open ocean).
function clipCellToLand(ringLngLat: LngLat[]): LandShape | null {
  let clipped: Feature<GeoPolygon | MultiPolygon> | null;
  try {
    clipped = intersect(featureCollection([turfPolygon([ringLngLat]), landMask]));
  } catch {
    return null;
  }
  if (!clipped) return null;

  const toLatLng = (ring: number[][]): LatLngExpression[] =>
    ring.map(([lng, lat]) => [lat, lng] as LatLng);

  if (clipped.geometry.type === 'Polygon') {
    // [outerRing, ...holes]
    return clipped.geometry.coordinates.map(toLatLng);
  }
  // MultiPolygon: array of polygons, each with its own [outerRing, ...holes] —
  // keep this exact nesting so Leaflet renders each piece (e.g. islands)
  // as a separate polygon instead of punching a hole in the first one.
  return clipped.geometry.coordinates.map(poly => poly.map(toLatLng));
}

function buildLandPolygons(cities: City[]): (LandShape | null)[] {
  if (cities.length < 2) return [];

  const points: LngLat[] = cities.map(c => [c.longitude, c.latitude]);
  const delaunay = Delaunay.from(points);
  const voronoi = delaunay.voronoi(BOUNDS);

  const rawCells: (LngLat[] | null)[] = cities.map((_, i) => voronoi.cellPolygon(i));
  return rawCells.map(poly => (poly ? clipCellToLand(poly) : null));
}

// Nation borders were dropped (see v1.6.2): the Voronoi cell fill color is
// enough on its own to show which nation controls each territory, and the
// province/international border lines had rendering gaps that weren't worth
// chasing down for a cosmetic feature.
export const VoronoiBorders: React.FC<VoronoiBordersProps> = ({ cities, nations }) => {
  const landPolygons = useMemo(() => buildLandPolygons(cities), [cities]);

  if (cities.length < 2) return null;

  const nationOf = (idx: number): Nation | undefined =>
    nations.find(n => n.id === cities[idx].nationId);

  return (
    <>
      {landPolygons.map((shape, i) => {
        if (!shape || shape.length === 0) return null;
        const color = nationOf(i)?.color ?? '#888';
        return (
          <Polygon
            key={`fill-${cities[i].id}`}
            positions={shape}
            interactive={false}
            pathOptions={{ stroke: false, fillColor: color, fillOpacity: 0.16 }}
          />
        );
      })}
    </>
  );
};
