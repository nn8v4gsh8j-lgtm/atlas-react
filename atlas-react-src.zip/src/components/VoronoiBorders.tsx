import React, { useMemo } from 'react';
import { Polygon, Polyline } from 'react-leaflet';
import type { LatLngExpression } from 'leaflet';
import { Delaunay } from 'd3-delaunay';
import { simplify, combine, intersect, polygon as turfPolygon, featureCollection } from '@turf/turf';
import type { Feature, FeatureCollection, MultiPolygon, Polygon as GeoPolygon } from 'geojson';
import landRaw from '../data/land-110m.json';
import { Nation, City } from '../types';

interface VoronoiBordersProps {
  cities: City[];
  nations: Nation[];
}

// Turf space: [lng, lat]. Leaflet space: [lat, lng]. Kept as distinct aliases
// below purely to keep the two coordinate orders from getting mixed up.
type LngLat = [number, number];
type LatLng = [number, number];
type LandShape = LatLngExpression[][] | LatLngExpression[][][];

interface EdgeInfo {
  key: string;
  points: [LatLng, LatLng];
  cityIdxs: number[];
}

// Bounding box for the Voronoi diagram, in [lng, lat] space. Padded well beyond
// the valid world extent (±180/±90) so that edge cities near the antimeridian
// or poles still get a sensibly clipped cell instead of an unbounded one.
const BOUNDS: [number, number, number, number] = [-200, -100, 200, 100];

// Rounding used only to detect which two cells share the exact same computed
// Voronoi edge (both cells derive that edge from the same underlying
// circumcenters, so this is a safety margin against floating-point noise,
// not a real precision loss for a world map).
const round = (n: number) => Math.round(n * 10000) / 10000;

// ─── land mask, precomputed once at module load — static data, computed only once
// per app lifetime, never re-derived per render or per city change ───────────────
const LAND_SIMPLIFY_TOLERANCE = 0.03; // degrees; coarse enough for a world-scale mobile map

const landMask: Feature<MultiPolygon> = (() => {
  const simplified = simplify(landRaw as FeatureCollection<GeoPolygon>, {
    tolerance: LAND_SIMPLIFY_TOLERANCE,
    highQuality: false,
  });
  const combined = combine(simplified as FeatureCollection<GeoPolygon>);
  return combined.features[0] as Feature<MultiPolygon>;
})();

// Clip a Voronoi cell ring (closed, [lng, lat] pairs) to land. Returns Leaflet-ready
// coordinates preserving the outer-ring/hole and single/multi-polygon nesting that
// Leaflet's <Polygon> expects, or null if the cell has no land at all (e.g. a city
// placed over open ocean).
function clipCellToLand(ringLngLat: LngLat[]): LandShape | null {
  let clipped: Feature<GeoPolygon | MultiPolygon> | null;
  try {
    clipped = intersect(featureCollection([turfPolygon([ringLngLat]), landMask]));
  } catch {
    return null;
  }
  if (!clipped) return null;

  const toLatLng = (ring: number[][]): LatLngExpression[] =>
    ring.map(([lng, lat]) => [lat, lng] as LatLng);

  if (clipped.geometry.type === 'Polygon') {
    // [outerRing, ...holes]
    return clipped.geometry.coordinates.map(toLatLng);
  }
  // MultiPolygon: array of polygons, each with its own [outerRing, ...holes] —
  // keep this exact nesting so Leaflet renders each piece (e.g. islands)
  // as a separate polygon instead of punching a hole in the first one.
  return clipped.geometry.coordinates.map(poly => poly.map(toLatLng));
}

function buildVoronoi(cities: City[]): { landPolygons: (LandShape | null)[]; edges: EdgeInfo[] } {
  if (cities.length < 2) return { landPolygons: [], edges: [] };

  const points: LngLat[] = cities.map(c => [c.longitude, c.latitude]);
  const delaunay = Delaunay.from(points);
  const voronoi = delaunay.voronoi(BOUNDS);

  const rawCells: (LngLat[] | null)[] = cities.map((_, i) => voronoi.cellPolygon(i));
  const landPolygons = rawCells.map(poly => (poly ? clipCellToLand(poly) : null));

  // d3-delaunay works in [lng, lat]; Leaflet wants [lat, lng].
  const leafletCells: (LatLng[] | null)[] = rawCells.map(poly =>
    poly ? poly.map(([lng, lat]) => [lat, lng] as LatLng) : null,
  );

  // Every polygon edge is shared with at most one neighboring cell (or none, if
  // it lies on the artificial bounding box). Match edges by their rounded
  // endpoint coordinates to find which cells border each other. Border lines are
  // NOT clipped to land — see the "Pendiente" note in the README for why, and
  // what a safe land-clipped version would need.
  const edgeMap = new Map<string, EdgeInfo>();
  leafletCells.forEach((poly, i) => {
    if (!poly) return;
    for (let k = 0; k < poly.length - 1; k++) {
      const a = poly[k];
      const b = poly[k + 1];
      const ka = `${round(a[0])},${round(a[1])}`;
      const kb = `${round(b[0])},${round(b[1])}`;
      const key = ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
      const existing = edgeMap.get(key);
      if (existing) {
        if (!existing.cityIdxs.includes(i)) existing.cityIdxs.push(i);
      } else {
        edgeMap.set(key, { key, points: [a, b], cityIdxs: [i] });
      }
    }
  });

  return { landPolygons, edges: [...edgeMap.values()] };
}

export const VoronoiBorders: React.FC<VoronoiBordersProps> = ({ cities, nations }) => {
  const { landPolygons, edges } = useMemo(() => buildVoronoi(cities), [cities]);

  if (cities.length < 2) return null;

  const nationOf = (idx: number): Nation | undefined =>
    nations.find(n => n.id === cities[idx].nationId);

  const sameNationEdges = edges.filter(
    e => e.cityIdxs.length === 2 && nationOf(e.cityIdxs[0])?.id === nationOf(e.cityIdxs[1])?.id,
  );
  const differentNationEdges = edges.filter(
    e => e.cityIdxs.length === 2 && nationOf(e.cityIdxs[0])?.id !== nationOf(e.cityIdxs[1])?.id,
  );

  return (
    <>
      {/* Cell fills — only over land, translucent, colored by controlling nation.
          The water portion of every cell is left with no fill at all. */}
      {landPolygons.map((shape, i) => {
        if (!shape || shape.length === 0) return null;
        const color = nationOf(i)?.color ?? '#888';
        return (
          <Polygon
            key={`fill-${cities[i].id}`}
            positions={shape}
            interactive={false}
            pathOptions={{ stroke: false, fillColor: color, fillOpacity: 0.16 }}
          />
        );
      })}

      {/* Internal (same-nation) borders — thin, nation color */}
      {sameNationEdges.map(e => (
        <Polyline
          key={`same-${e.key}`}
          positions={e.points}
          interactive={false}
          pathOptions={{ color: nationOf(e.cityIdxs[0])?.color ?? '#888', weight: 1.2, opacity: 0.45 }}
        />
      ))}

      {/* International borders — same thinness as province borders, soft white/light gray */}
      {differentNationEdges.map(e => (
        <Polyline
          key={`diff-${e.key}`}
          positions={e.points}
          interactive={false}
          pathOptions={{ color: '#e8e4d9', weight: 1.2, opacity: 0.5 }}
        />
      ))}
    </>
  );
};
