import React, { useMemo } from 'react';
import { Polygon, Polyline } from 'react-leaflet';
import { Delaunay } from 'd3-delaunay';
import { Nation, City } from '../types';

interface VoronoiBordersProps {
  cities: City[];
  nations: Nation[];
}

type LatLng = [number, number];

interface EdgeInfo {
  key: string;
  points: [LatLng, LatLng];
  cityIdxs: number[];
}

// Bounding box for the Voronoi diagram, in [lng, lat] space. Padded well beyond
// the valid world extent (±180/±90) so that edge cities near the antimeridian
// or poles still get a sensibly clipped cell instead of an unbounded one.
const BOUNDS: [number, number, number, number] = [-200, -100, 200, 100];

// Rounding used only to detect which two cells share the exact same computed
// Voronoi edge (both cells derive that edge from the same underlying
// circumcenters, so this is a safety margin against floating-point noise,
// not a real precision loss for a world map).
const round = (n: number) => Math.round(n * 10000) / 10000;

function buildVoronoi(cities: City[]): { cellPolygons: (LatLng[] | null)[]; edges: EdgeInfo[] } {
  if (cities.length < 2) return { cellPolygons: [], edges: [] };

  const points: [number, number][] = cities.map(c => [c.longitude, c.latitude]);
  const delaunay = Delaunay.from(points);
  const voronoi = delaunay.voronoi(BOUNDS);

  // d3-delaunay works in [x, y] = [lng, lat]; Leaflet wants [lat, lng].
  const cellPolygons: (LatLng[] | null)[] = cities.map((_, i) => {
    const poly = voronoi.cellPolygon(i);
    if (!poly) return null;
    return poly.map(([lng, lat]) => [lat, lng] as LatLng);
  });

  // Every polygon edge is shared with at most one neighboring cell (or none,
  // if it lies on the artificial bounding box). Match edges by their rounded
  // endpoint coordinates to find which cells border each other.
  const edgeMap = new Map<string, EdgeInfo>();
  cellPolygons.forEach((poly, i) => {
    if (!poly) return;
    for (let k = 0; k < poly.length - 1; k++) {
      const a = poly[k];
      const b = poly[k + 1];
      const ka = `${round(a[0])},${round(a[1])}`;
      const kb = `${round(b[0])},${round(b[1])}`;
      const key = ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
      const existing = edgeMap.get(key);
      if (existing) {
        if (!existing.cityIdxs.includes(i)) existing.cityIdxs.push(i);
      } else {
        edgeMap.set(key, { key, points: [a, b], cityIdxs: [i] });
      }
    }
  });

  return { cellPolygons, edges: [...edgeMap.values()] };
}

export const VoronoiBorders: React.FC<VoronoiBordersProps> = ({ cities, nations }) => {
  const { cellPolygons, edges } = useMemo(() => buildVoronoi(cities), [cities]);

  if (cities.length < 2) return null;

  const nationOf = (idx: number): Nation | undefined =>
    nations.find(n => n.id === cities[idx].nationId);

  const sameNationEdges = edges.filter(
    e => e.cityIdxs.length === 2 && nationOf(e.cityIdxs[0])?.id === nationOf(e.cityIdxs[1])?.id,
  );
  const differentNationEdges = edges.filter(
    e => e.cityIdxs.length === 2 && nationOf(e.cityIdxs[0])?.id !== nationOf(e.cityIdxs[1])?.id,
  );

  return (
    <>
      {/* Cell fills — translucent, colored by controlling nation */}
      {cellPolygons.map((poly, i) => {
        if (!poly) return null;
        const color = nationOf(i)?.color ?? '#888';
        return (
          <Polygon
            key={`fill-${cities[i].id}`}
            positions={poly}
            interactive={false}
            pathOptions={{ stroke: false, fillColor: color, fillOpacity: 0.14 }}
          />
        );
      })}

      {/* Internal (same-nation) borders — thin */}
      {sameNationEdges.map(e => (
        <Polyline
          key={`same-${e.key}`}
          positions={e.points}
          interactive={false}
          pathOptions={{ color: nationOf(e.cityIdxs[0])?.color ?? '#888', weight: 1.2, opacity: 0.45 }}
        />
      ))}

      {/* International borders — thick, two-tone (one nation's color layered over the other's) */}
      {differentNationEdges.map(e => {
        const [idxA, idxB] = e.cityIdxs;
        return (
          <React.Fragment key={`diff-${e.key}`}>
            <Polyline
              positions={e.points}
              interactive={false}
              pathOptions={{ color: nationOf(idxA)?.color ?? '#888', weight: 5, opacity: 0.9 }}
            />
            <Polyline
              positions={e.points}
              interactive={false}
              pathOptions={{ color: nationOf(idxB)?.color ?? '#888', weight: 2.2, opacity: 0.9 }}
            />
          </React.Fragment>
        );
      })}
    </>
  );
};
