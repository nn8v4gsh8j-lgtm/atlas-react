import React, { useState, useMemo } from 'react';
import { AtlasEvent, Nation, City, EventType } from '../types';
import { describeEvent, describeResult, wasConquest, wasNationDefeated, wasRepelled, EVENT_META, formatDate } from '../utils';
import { Crown, Zap, TrendingUp, Trash2, Swords, Skull, Shield, SlidersHorizontal, X } from 'lucide-react';

const ICONS: Record<string, React.FC<{ size?: number }>> = {
  nationFounded:         Crown,
  increaseMilitaryPower: Zap,
  developInfrastructure: TrendingUp,
  attack:                Swords,
};

const ALL_TYPES: EventType[] = ['nationFounded', 'increaseMilitaryPower', 'developInfrastructure', 'attack'];
const TYPE_LABELS: Record<EventType, string> = {
  nationFounded:         'Fundación',
  increaseMilitaryPower: 'Gen. Militar',
  developInfrastructure: 'Infraestructura',
  attack:                'Ataque',
};

interface EventosTabProps {
  events: AtlasEvent[];
  nations: Nation[];
  cities: City[];
  onAdd: () => void;
  onDelete: (id: number) => void;
}

interface Filters {
  nationId: number | '';
  cityId:   number | '';
  types:    Set<EventType>;
  dateFrom: string;
  dateTo:   string;
}

const EMPTY_FILTERS: Filters = {
  nationId: '', cityId: '', types: new Set(), dateFrom: '', dateTo: '',
};

function countActiveFilters(f: Filters): number {
  let n = 0;
  if (f.nationId !== '') n++;
  if (f.cityId !== '') n++;
  if (f.types.size > 0) n++;
  if (f.dateFrom || f.dateTo) n++;
  return n;
}

function applyFilters(events: AtlasEvent[], f: Filters): AtlasEvent[] {
  return events.filter(ev => {
    // Nation filter: acting nation OR target nation
    if (f.nationId !== '') {
      const nid = f.nationId;
      const match = ev.nation === nid || ev.targetNation === nid;
      if (!match) return false;
    }
    // City filter: acting city OR target city
    if (f.cityId !== '') {
      const cid = f.cityId;
      const match = ev.city.id === cid || ev.targetCity?.id === cid;
      if (!match) return false;
    }
    // Type filter
    if (f.types.size > 0 && !f.types.has(ev.type)) return false;
    // Date range
    if (f.dateFrom && ev.date < f.dateFrom) return false;
    if (f.dateTo   && ev.date > f.dateTo)   return false;
    return true;
  });
}

export const EventosTab: React.FC<EventosTabProps> = ({ events, nations, cities, onAdd, onDelete }) => {
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);

  const activeCount = countActiveFilters(filters);

  const setNationId = (v: number | '') => setFilters(f => ({ ...f, nationId: v, cityId: '' }));
  const setCityId   = (v: number | '') => setFilters(f => ({ ...f, cityId: v }));
  const setDateFrom = (v: string)      => setFilters(f => ({ ...f, dateFrom: v }));
  const setDateTo   = (v: string)      => setFilters(f => ({ ...f, dateTo: v }));
  const toggleType  = (t: EventType)   => setFilters(f => {
    const types = new Set(f.types);
    types.has(t) ? types.delete(t) : types.add(t);
    return { ...f, types };
  });
  const clearFilters = () => setFilters(EMPTY_FILTERS);

  // Cities to show in city selector (if nation selected, only cities ever involved with that nation)
  const cityOptions = useMemo(() => {
    if (filters.nationId === '') return cities;
    const nid = filters.nationId;
    // Include cities currently in this nation, plus cities that appear in events for this nation
    const citiesInEvents = new Set<number>();
    events.forEach(ev => {
      if (ev.nation === nid) citiesInEvents.add(ev.city.id);
      if (ev.targetNation === nid && ev.targetCity) citiesInEvents.add(ev.targetCity.id);
    });
    return cities.filter(c => c.nationId === nid || citiesInEvents.has(c.id));
  }, [cities, events, filters.nationId]);

  const filtered = useMemo(() => applyFilters(events, filters), [events, filters]);

  if (events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">
          Ningún evento registrado aún.<br />Registra el primer acontecimiento.
        </p>
        <button onClick={onAdd} className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors">
          ✦ Registrar Evento
        </button>
      </div>
    );
  }

  const grouped = new Map<string, AtlasEvent[]>();
  [...filtered]
    .sort((a, b) => b.date !== a.date ? b.date.localeCompare(a.date) : b.id - a.id)
    .forEach(ev => {
      if (!grouped.has(ev.date)) grouped.set(ev.date, []);
      grouped.get(ev.date)!.push(ev);
    });

  // Input style reused in filter panel
  const inputCls = "w-full bg-[#0e1720] border border-[#2a3a47] rounded-lg px-3 py-2 text-[#ece7d9] font-sans text-sm focus:outline-none focus:border-[#c9a24c] transition-colors";
  const selectCls = inputCls;

  return (
    <div className="flex flex-col h-full">
      {/* ── Filter bar ── */}
      <div className="flex-shrink-0 flex items-center justify-between gap-2 px-4 py-2 border-b border-[#2a3a47] bg-[#16212b]">
        <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/40">
          {filtered.length} {filtered.length === 1 ? 'evento' : 'eventos'}
          {activeCount > 0 && <span className="text-[#c9a24c]"> · {activeCount} filtro{activeCount > 1 ? 's' : ''}</span>}
        </span>
        <div className="flex items-center gap-2">
          {activeCount > 0 && (
            <button
              onClick={clearFilters}
              className="font-mono text-[9px] uppercase tracking-wider text-[#b5524a] active:opacity-60 px-2 py-1"
            >
              Limpiar
            </button>
          )}
          <button
            onClick={() => setFiltersOpen(o => !o)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors"
            style={{
              borderColor: filtersOpen || activeCount > 0 ? '#c9a24c55' : '#2a3a47',
              backgroundColor: filtersOpen || activeCount > 0 ? '#c9a24c12' : '#0e1720',
            }}
          >
            <SlidersHorizontal size={12} style={{ color: activeCount > 0 ? '#c9a24c' : '#5c6b73' }} />
            <span className="font-mono text-[10px] uppercase tracking-wider" style={{ color: activeCount > 0 ? '#c9a24c' : '#5c6b73' }}>
              Filtros{activeCount > 0 ? ` (${activeCount})` : ''}
            </span>
          </button>
        </div>
      </div>

      {/* ── Filter panel ── */}
      {filtersOpen && (
        <div className="flex-shrink-0 bg-[#16212b] border-b border-[#2a3a47] px-4 py-4 flex flex-col gap-4">

          {/* Row 1: Nation + City */}
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="font-mono text-[9px] uppercase tracking-wider text-foreground/40">Nación</label>
              <select
                value={String(filters.nationId)}
                onChange={e => setNationId(e.target.value === '' ? '' : Number(e.target.value))}
                className={selectCls}
              >
                <option value="">Todas</option>
                {nations.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="font-mono text-[9px] uppercase tracking-wider text-foreground/40">Ciudad</label>
              <select
                value={String(filters.cityId)}
                onChange={e => setCityId(e.target.value === '' ? '' : Number(e.target.value))}
                className={selectCls}
              >
                <option value="">Todas</option>
                {cityOptions.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          </div>

          {/* Row 2: Type toggles */}
          <div className="flex flex-col gap-1.5">
            <label className="font-mono text-[9px] uppercase tracking-wider text-foreground/40">Tipo de evento</label>
            <div className="flex gap-2 flex-wrap">
              {ALL_TYPES.map(t => {
                const meta    = EVENT_META[t];
                const active  = filters.types.has(t);
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => toggleType(t)}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-colors text-left"
                    style={{
                      borderColor: active ? `${meta.color}80` : '#2a3a47',
                      backgroundColor: active ? `${meta.color}18` : '#0e1720',
                      color: active ? meta.color : '#5c6b73',
                    }}
                  >
                    <span className="font-mono text-[10px] font-bold">{TYPE_LABELS[t]}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Row 3: Date range */}
          <div className="flex flex-col gap-1.5">
            <label className="font-mono text-[9px] uppercase tracking-wider text-foreground/40">Rango de fechas</label>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1">
                <span className="font-mono text-[9px] text-foreground/30">Desde</span>
                <input type="date" value={filters.dateFrom} onChange={e => setDateFrom(e.target.value)}
                  className={inputCls} style={{ colorScheme: 'dark' }} />
              </div>
              <div className="flex flex-col gap-1">
                <span className="font-mono text-[9px] text-foreground/30">Hasta</span>
                <input type="date" value={filters.dateTo} onChange={e => setDateTo(e.target.value)}
                  className={inputCls} style={{ colorScheme: 'dark' }} />
              </div>
            </div>
          </div>

          {/* Close panel */}
          <button
            onClick={() => setFiltersOpen(false)}
            className="self-end flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-foreground/40 active:text-foreground/70 py-1"
          >
            <X size={11} /> Cerrar
          </button>
        </div>
      )}

      {/* ── Empty filtered result ── */}
      {filtered.length === 0 && events.length > 0 && (
        <div className="flex flex-col items-center justify-center px-6 text-center pt-20 flex-1">
          <p className="text-foreground/50 font-sans text-sm leading-relaxed mb-3">
            Ningún evento coincide con los filtros actuales.
          </p>
          <button onClick={clearFilters} className="text-[#c9a24c] font-mono text-[11px] uppercase tracking-wider active:opacity-60">
            Limpiar filtros
          </button>
        </div>
      )}

      {/* ── Timeline ── */}
      {filtered.length > 0 && (
        <div className="flex-1 overflow-y-auto relative">
          <div className="absolute top-0 bottom-0 w-px bg-[#2a3a47]" style={{ left: 43 }} />
          <div className="p-4">
            {Array.from(grouped.keys()).map(date => (
              <div key={date} className="mb-8">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-[14px] h-[14px] rounded-full bg-[#c9a24c] border-2 border-[#0e1720] shrink-0 relative z-10" style={{ marginLeft: 20 }} />
                  <span className="font-mono text-xs text-[#c9a24c] uppercase tracking-widest">{formatDate(date)}</span>
                </div>

                <div className="flex flex-col gap-2" style={{ marginLeft: 44 }}>
                  {grouped.get(date)!.map(ev => {
                    const meta           = EVENT_META[ev.type] ?? EVENT_META['attack'];
                    const Icon           = ICONS[ev.type] ?? Swords;
                    const isHighlight    = ev.type === 'nationFounded';
                    const conquest       = wasConquest(ev);
                    const defeated       = wasNationDefeated(ev, cities);
                    const repelled       = wasRepelled(ev);
                    const actingNation   = nations.find(n => n.id === ev.nation);
                    const defenderNationName = ev.targetNation !== undefined
                      ? nations.find(n => n.id === ev.targetNation)?.name ?? '?' : undefined;

                    return (
                      <div
                        key={ev.id}
                        className="rounded-xl border overflow-hidden"
                        style={isHighlight ? {
                          background: `linear-gradient(135deg, ${meta.color}12 0%, #16212b 60%)`,
                          borderColor: `${meta.color}55`,
                          boxShadow:   `0 0 0 1px ${meta.color}22`,
                        } : { background: '#16212b', borderColor: '#2a3a47' }}
                      >
                        {/* Nation header */}
                        <div className="flex items-center gap-2 px-3 pt-2.5 pb-1.5 border-b" style={{ borderColor: '#2a3a47' }}>
                          {actingNation && <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: actingNation.color }} />}
                          <span className="font-mono text-[10px] uppercase tracking-widest font-bold" style={{ color: actingNation?.color ?? '#c9a24c' }}>
                            {actingNation?.name ?? '?'}
                          </span>
                        </div>

                        {/* Main content */}
                        <div className="p-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                                style={{ backgroundColor: `${meta.color}22`, border: `1px solid ${meta.color}55` }}>
                                <Icon size={13} />
                              </div>
                              <div className="min-w-0">
                                <span className="inline-block font-mono text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded mb-1 font-bold"
                                  style={{ color: meta.color, backgroundColor: `${meta.color}18`, border: `1px solid ${meta.color}40` }}>
                                  {meta.label}
                                </span>
                                <p className={`font-sans text-[13px] leading-snug ${isHighlight ? 'text-[#ece7d9] font-medium' : 'text-[#ece7d9]'}`}>
                                  {describeEvent(ev, nations)}
                                </p>
                                {(() => {
                                  const r = describeResult(ev, nations);
                                  if (!r) return null;
                                  return r.split('\n').map((line, i) => (
                                    <p key={i} className="font-mono text-[10px] text-foreground/45 mt-1 leading-relaxed">{line}</p>
                                  ));
                                })()}
                              </div>
                            </div>
                            <button
                              onClick={() => { if (window.confirm('¿Eliminar este registro?')) onDelete(ev.id); }}
                              className="p-1 text-foreground/20 active:text-[#b5524a] transition-colors shrink-0 mt-0.5"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>

                        {/* Battle preview */}
                        {ev.type === 'attack' && ev.targetCity && (() => {
                          const won       = ev.city.militaryPower >= 1;
                          const defNation = nations.find(n => n.id === ev.targetNation);
                          const ATTK_CLR  = '#b5524a';
                          const DEF_CLR   = '#4f9c8c';
                          return (
                            <div className="border-t" style={{ borderColor: '#2a3a47' }}>
                              <div className="grid grid-cols-2 divide-x divide-[#2a3a47]">
                                <div className="p-3 flex flex-col gap-1">
                                  <div className="flex items-center gap-1.5 mb-1">
                                    <Swords size={10} style={{ color: ATTK_CLR }} />
                                    <span className="font-mono text-[9px] uppercase tracking-wider font-bold" style={{ color: ATTK_CLR }}>Atacante</span>
                                  </div>
                                  <p className="font-serif text-[14px] text-[#ece7d9] leading-tight">{ev.city.name}</p>
                                  <p className="font-mono text-[9px] text-foreground/40">{actingNation?.name ?? '?'}</p>
                                  <div className="flex items-center gap-1 mt-0.5">
                                    <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold">Infra</span>
                                    <span className="font-mono text-[11px] text-[#4f9c8c] font-semibold">{ev.city.infrastructureLevel}</span>
                                  </div>
                                  <div className="flex items-baseline gap-1.5 mt-0.5">
                                    <span className="font-mono text-[9px] font-bold uppercase" style={{ color: ATTK_CLR }}>PM</span>
                                    <span className="font-mono text-[22px] font-bold leading-none" style={{ color: ATTK_CLR }}>
                                      {ev.attackerInitialPM ?? ev.city.militaryPower}
                                    </span>
                                    {ev.attackerInitialPM !== undefined && (
                                      <>
                                        <span className="font-mono text-[10px] text-foreground/30">→</span>
                                        <span className="font-mono text-[11px] font-semibold" style={{ color: won ? ATTK_CLR : '#5c6b73' }}>
                                          {ev.city.militaryPower}
                                        </span>
                                      </>
                                    )}
                                  </div>
                                </div>
                                <div className="p-3 flex flex-col gap-1">
                                  <div className="flex items-center gap-1.5 mb-1">
                                    <Shield size={10} style={{ color: DEF_CLR }} />
                                    <span className="font-mono text-[9px] uppercase tracking-wider font-bold" style={{ color: DEF_CLR }}>Defensor</span>
                                  </div>
                                  <p className="font-serif text-[14px] text-[#ece7d9] leading-tight">{ev.targetCity.name}</p>
                                  <p className="font-mono text-[9px] text-foreground/40">{defNation?.name ?? '?'}</p>
                                  <div className="flex items-center gap-1 mt-0.5">
                                    <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold">Infra</span>
                                    <span className="font-mono text-[11px] text-[#4f9c8c] font-semibold">{ev.targetCity.infrastructureLevel}</span>
                                  </div>
                                  <div className="flex items-baseline gap-1.5 mt-0.5">
                                    <span className="font-mono text-[9px] font-bold uppercase" style={{ color: DEF_CLR }}>PM</span>
                                    <span className="font-mono text-[22px] font-bold leading-none" style={{ color: DEF_CLR }}>
                                      {ev.defenderInitialPM ?? ev.targetCity.militaryPower}
                                    </span>
                                    {ev.defenderInitialPM !== undefined && (
                                      <>
                                        <span className="font-mono text-[10px] text-foreground/30">→</span>
                                        <span className="font-mono text-[11px] font-semibold" style={{ color: !won ? DEF_CLR : '#5c6b73' }}>
                                          {ev.targetCity.militaryPower}
                                        </span>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        })()}

                        {/* Repelled banner */}
                        {repelled && ev.targetCity && (
                          <div className="flex items-center gap-2 px-3 py-2 border-t" style={{ backgroundColor: '#4f9c8c18', borderColor: '#4f9c8c40' }}>
                            <Shield size={11} style={{ color: '#4f9c8c', flexShrink: 0 }} />
                            <span className="font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: '#4f9c8c' }}>Defensa</span>
                            <span className="font-sans text-[11px] text-[#ece7d9]/80 min-w-0">🛡️ {ev.targetCity.name} repele el ataque</span>
                          </div>
                        )}

                        {/* Conquest banner */}
                        {conquest && ev.targetCity && (
                          <div className="flex items-center gap-2 px-3 py-2 border-t" style={{ backgroundColor: '#8a6bbf18', borderColor: '#8a6bbf40' }}>
                            <Swords size={11} style={{ color: '#8a6bbf', flexShrink: 0 }} />
                            <span className="font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: '#8a6bbf' }}>Conquista</span>
                            <span className="font-sans text-[11px] text-[#ece7d9]/80 min-w-0">
                              {ev.targetCity.name} pasa a {actingNation?.name ?? '?'}
                            </span>
                          </div>
                        )}

                        {/* Nation defeated banner */}
                        {defeated && defenderNationName && (
                          <div className="flex items-center gap-2 px-3 py-2 border-t" style={{ backgroundColor: '#b5524a1a', borderColor: '#b5524a50' }}>
                            <Skull size={11} style={{ color: '#b5524a', flexShrink: 0 }} />
                            <span className="font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: '#b5524a' }}>Nación derrotada</span>
                            <span className="font-sans text-[11px] text-[#ece7d9]/80 min-w-0">
                              {defenderNationName} cae y cesa de existir
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
