import React from 'react';
import { AtlasEvent, Nation, City } from '../types';
import { describeEvent, describeResult, wasConquest, wasNationDefeated, EVENT_META, formatDate } from '../utils';
import { Crown, Zap, TrendingUp, Crosshair, Trash2, Swords, Skull } from 'lucide-react';

const ICONS: Record<string, React.FC<{ size?: number }>> = {
  nationFounded:         Crown,
  increaseMilitaryPower: Zap,
  developInfrastructure: TrendingUp,
  attack:                Crosshair,
};

interface EventosTabProps {
  events: AtlasEvent[];
  nations: Nation[];
  cities: City[];
  onAdd: () => void;
  onDelete: (id: number) => void;
}

export const EventosTab: React.FC<EventosTabProps> = ({ events, nations, cities, onAdd, onDelete }) => {
  if (events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">
          Ningún evento registrado aún.<br />Registra el primer acontecimiento.
        </p>
        <button onClick={onAdd} className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors">
          ✦ Registrar Evento
        </button>
      </div>
    );
  }

  // Group by date, newest first; within same date sort by id desc
  const grouped = new Map<string, AtlasEvent[]>();
  [...events]
    .sort((a, b) => b.date !== a.date ? b.date.localeCompare(a.date) : b.id - a.id)
    .forEach(ev => {
      if (!grouped.has(ev.date)) grouped.set(ev.date, []);
      grouped.get(ev.date)!.push(ev);
    });

  return (
    <div className="relative pb-32">
      <div className="absolute top-0 bottom-0 w-px bg-[#2a3a47]" style={{ left: 27 }} />
      <div className="p-4">
        {Array.from(grouped.keys()).map(date => (
          <div key={date} className="mb-8">
            {/* Date marker */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-[14px] h-[14px] rounded-full bg-[#c9a24c] border-2 border-[#0e1720] shrink-0 relative z-10" style={{ marginLeft: 20 }} />
              <span className="font-mono text-xs text-[#c9a24c] uppercase tracking-widest">{formatDate(date)}</span>
            </div>

            <div className="flex flex-col gap-2" style={{ marginLeft: 44 }}>
              {grouped.get(date)!.map(ev => {
                const meta      = EVENT_META[ev.type] ?? EVENT_META['attack'];
                const Icon      = ICONS[ev.type] ?? Crosshair;
                const isHighlight = ev.type === 'nationFounded';
                const conquest  = wasConquest(ev);
                const defeated  = wasNationDefeated(ev, cities);
                const defenderNationName = ev.targetNation !== undefined
                  ? nations.find(n => n.id === ev.targetNation)?.name ?? '?'
                  : undefined;

                return (
                  <div
                    key={ev.id}
                    className="rounded-xl border overflow-hidden"
                    style={isHighlight ? {
                      background: `linear-gradient(135deg, ${meta.color}12 0%, #16212b 60%)`,
                      borderColor: `${meta.color}55`,
                      boxShadow:   `0 0 0 1px ${meta.color}22`,
                    } : { background: '#16212b', borderColor: '#2a3a47' }}
                  >
                    {/* Main row */}
                    <div className="p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5 min-w-0">
                          {/* Icon */}
                          <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                            style={{ backgroundColor: `${meta.color}22`, border: `1px solid ${meta.color}55` }}>
                            <Icon size={13} />
                          </div>
                          <div className="min-w-0">
                            {/* Badge */}
                            <span className="inline-block font-mono text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded mb-1 font-bold"
                              style={{ color: meta.color, backgroundColor: `${meta.color}18`, border: `1px solid ${meta.color}40` }}>
                              {meta.label}
                            </span>
                            {/* Description */}
                            <p className={`font-sans text-[13px] leading-snug ${isHighlight ? 'text-[#ece7d9] font-medium' : 'text-[#ece7d9]'}`}>
                              {describeEvent(ev, nations)}
                            </p>
                            {/* Result */}
                            {(() => {
                              const r = describeResult(ev, nations);
                              if (!r) return null;
                              return r.split('\n').map((line, i) => (
                                <p key={i} className="font-mono text-[10px] text-foreground/45 mt-1 leading-relaxed">{line}</p>
                              ));
                            })()}
                          </div>
                        </div>
                        <button
                          onClick={() => { if (window.confirm('¿Eliminar este registro?')) onDelete(ev.id); }}
                          className="p-1 text-foreground/20 active:text-[#b5524a] transition-colors shrink-0 mt-0.5"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>

                    {/* Conquest banner */}
                    {conquest && ev.targetCity && (
                      <div className="flex items-center gap-2 px-3 py-2 border-t"
                        style={{ backgroundColor: '#8a6bbf18', borderColor: '#8a6bbf40' }}>
                        <Swords size={11} style={{ color: '#8a6bbf', flexShrink: 0 }} />
                        <span className="font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: '#8a6bbf' }}>Conquista</span>
                        <span className="font-sans text-[11px] text-[#ece7d9]/80 min-w-0">
                          {ev.targetCity.name} pasa a {nations.find(n => n.id === ev.nation)?.name ?? '?'}
                        </span>
                      </div>
                    )}

                    {/* Nation defeated banner */}
                    {defeated && defenderNationName && (
                      <div className="flex items-center gap-2 px-3 py-2 border-t"
                        style={{ backgroundColor: '#b5524a1a', borderColor: '#b5524a50' }}>
                        <Skull size={11} style={{ color: '#b5524a', flexShrink: 0 }} />
                        <span className="font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: '#b5524a' }}>Nación derrotada</span>
                        <span className="font-sans text-[11px] text-[#ece7d9]/80 min-w-0">
                          {defenderNationName} cae y cesa de existir
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
