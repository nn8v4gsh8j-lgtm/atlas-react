import React from 'react';
import { GameEvent, TipoEvento } from '../types';
import { Crown, Zap, TrendingUp, Crosshair, Trash2, Swords, Skull } from 'lucide-react';

interface EventosTabProps {
  events: GameEvent[];
  onAdd: () => void;
  onDelete: (id: string) => void;
}

const TIPO_META: Record<TipoEvento, {
  label: string;
  color: string;
  Icon: React.FC<{ size?: number }>;
  highlight?: boolean; // full-card highlight style
}> = {
  nueva_nacion:             { label: 'Fundación',       color: '#c9a24c', Icon: Crown,     highlight: true },
  generacion_poder_militar: { label: 'Gen. Militar',    color: '#b5524a', Icon: Zap },
  mejora_infraestructura:   { label: 'Mejora de Infra', color: '#4f9c8c', Icon: TrendingUp },
  ataque:                   { label: 'Ataque',          color: '#c47c3a', Icon: Crosshair },
  conquista:                { label: 'Conquista',       color: '#8a6bbf', Icon: Swords,    highlight: true },
  derrota_nacion:           { label: 'Nación derrotada',color: '#b5524a', Icon: Skull,     highlight: true },
};

const MONTH_NAMES = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
function formatDate(fecha: string) {
  try {
    const [y, m, d] = fecha.split('-');
    return `${parseInt(d)} ${MONTH_NAMES[parseInt(m) - 1] ?? m} ${y}`;
  } catch { return fecha; }
}

export const EventosTab: React.FC<EventosTabProps> = ({ events, onAdd, onDelete }) => {
  if (events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">
          Ningún evento registrado aún.<br />Registra el primer acontecimiento.
        </p>
        <button
          onClick={onAdd}
          className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors"
        >
          ✦ Registrar Evento
        </button>
      </div>
    );
  }

  const grouped = new Map<string, GameEvent[]>();
  [...events]
    .sort((a, b) => {
      if (b.fecha !== a.fecha) return b.fecha.localeCompare(a.fecha);
      return b.createdAt.localeCompare(a.createdAt);
    })
    .forEach(ev => {
      if (!grouped.has(ev.fecha)) grouped.set(ev.fecha, []);
      grouped.get(ev.fecha)!.push(ev);
    });

  const dates = Array.from(grouped.keys());

  return (
    <div className="relative pb-32">
      {/* Vertical timeline line */}
      <div className="absolute top-0 bottom-0 w-px bg-[#2a3a47]" style={{ left: 27 }} />

      <div className="p-4">
        {dates.map(date => {
          const dayEvents = grouped.get(date)!;
          return (
            <div key={date} className="mb-8">
              {/* Date header */}
              <div className="flex items-center gap-3 mb-3">
                <div
                  className="w-[14px] h-[14px] rounded-full bg-[#c9a24c] border-2 border-[#0e1720] shrink-0 relative z-10"
                  style={{ marginLeft: 20 }}
                />
                <span className="font-mono text-xs text-[#c9a24c] uppercase tracking-widest">
                  {formatDate(date)}
                </span>
              </div>

              <div className="flex flex-col gap-2" style={{ marginLeft: 44 }}>
                {dayEvents.map(ev => {
                  const meta = TIPO_META[ev.tipo] ?? TIPO_META['ataque'];
                  const { Icon } = meta;
                  const isHighlight = meta.highlight === true;

                  return (
                    <div
                      key={ev.id}
                      data-testid={`card-event-${ev.id}`}
                      className={`rounded-xl p-3 border ${
                        isHighlight
                          ? 'border-opacity-60'
                          : 'bg-[#16212b] border-[#2a3a47]'
                      }`}
                      style={isHighlight ? {
                        background: `linear-gradient(135deg, ${meta.color}12 0%, #16212b 60%)`,
                        borderColor: `${meta.color}55`,
                        boxShadow: `0 0 0 1px ${meta.color}22`,
                      } : undefined}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5 min-w-0">
                          {/* Icon */}
                          <div
                            className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                            style={{ backgroundColor: `${meta.color}22`, border: `1px solid ${meta.color}55` }}
                          >
                            <Icon size={13} />
                          </div>

                          <div className="min-w-0">
                            {/* Type badge */}
                            <span
                              className="inline-block font-mono text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded mb-1 font-bold"
                              style={{ color: meta.color, backgroundColor: `${meta.color}18`, border: `1px solid ${meta.color}40` }}
                            >
                              {meta.label}
                            </span>

                            {/* Description */}
                            <p className={`font-sans text-[13px] leading-snug ${isHighlight ? 'text-[#ece7d9] font-medium' : 'text-[#ece7d9]'}`}>
                              {ev.descripcion}
                            </p>

                            {/* Result */}
                            {ev.resultado && (
                              <p className="font-mono text-[10px] text-foreground/45 mt-1 leading-relaxed">
                                {ev.resultado}
                              </p>
                            )}
                          </div>
                        </div>

                        <button
                          data-testid={`button-delete-event-${ev.id}`}
                          onClick={() => {
                            if (window.confirm('¿Eliminar este registro?')) onDelete(ev.id);
                          }}
                          className="p-1 text-foreground/20 active:text-[#b5524a] transition-colors shrink-0 mt-0.5"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
