import React, { useState, useMemo } from 'react';
import { Nation, City, AtlasEvent } from '../types';
import { Trash2, ArrowUpDown, ChevronDown, ChevronRight, Skull } from 'lucide-react';

interface NacionesTabProps {
  nations: Nation[];
  cities: City[];
  events: AtlasEvent[];
  onEdit: (nation: Nation) => void;
  onDelete: (id: number) => void;
}

type SortKey = 'fundacion' | 'alfabetico' | 'desarrollo' | 'militar' | 'ciudades';
const SORT_LABELS: Record<SortKey, string> = {
  fundacion: 'Fundación', alfabetico: 'A–Z', desarrollo: 'Desarrollo', militar: 'Poder militar', ciudades: 'Nº ciudades',
};
const SORT_ORDER: SortKey[] = ['fundacion', 'alfabetico', 'desarrollo', 'militar', 'ciudades'];

type EnrichedNation = {
  nation: Nation;
  cityCount: number;
  totalInfra: number;
  totalMil: number;
  foundingEventId: number;
  foundingDate: string | null;
  defeatDate: string | null;
};

const NationCard: React.FC<EnrichedNation & {
  onEdit: (n: Nation) => void;
  onDelete: (id: number) => void;
}> = ({ nation, cityCount, totalInfra, totalMil, foundingDate, defeatDate, onEdit, onDelete }) => (
  <div onClick={() => onEdit(nation)} className="bg-[#16212b] border border-[#2a3a47] rounded-xl p-4 active:bg-[#1c2a38] transition-colors cursor-pointer">
    <div className="flex items-start justify-between gap-2">
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-3 h-3 rounded-full shrink-0 border border-black/20 mt-1" style={{ backgroundColor: nation.color }} />
        <div className="min-w-0">
          <p className="font-serif text-[18px] text-[#ece7d9] leading-tight break-words">{nation.name}</p>
          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
            <span className="font-mono text-[10px] text-[#c9a24c] uppercase tracking-wider">
              {cityCount} {cityCount === 1 ? 'ciudad' : 'ciudades'}
            </span>
            {/* Dates */}
            {defeatDate && foundingDate ? (
              <span className="font-mono text-[9px]" style={{ color: '#5c6b73' }}>
                {foundingDate} – {defeatDate}
              </span>
            ) : foundingDate ? (
              <span className="font-mono text-[9px]" style={{ color: '#5c6b73' }}>
                Fundada: {foundingDate}
              </span>
            ) : null}
          </div>
        </div>
      </div>
      <button onClick={e => {
        e.stopPropagation();
        if (window.confirm(`¿Eliminar "${nation.name}"?${cityCount > 0 ? `\n\nSus ${cityCount} ciudades también serán eliminadas.` : ''}`)) onDelete(nation.id);
      }} className="p-1.5 -mr-1 -mt-1 text-foreground/25 active:text-[#b5524a] transition-colors shrink-0">
        <Trash2 size={16} />
      </button>
    </div>
    <div className="flex items-center gap-4 mt-3 ml-6 flex-wrap">
      <div className="flex items-center gap-1.5">
        <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold tracking-wider">Infra</span>
        <span className="font-mono text-[17px] text-[#4f9c8c] font-bold tabular-nums leading-none">{totalInfra}</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="font-mono text-[9px] text-[#b5524a] uppercase font-bold tracking-wider">Mil</span>
        <span className="font-mono text-[17px] text-[#b5524a] font-bold tabular-nums leading-none">{totalMil}</span>
        <span className="font-mono text-[9px] text-foreground/30">pts</span>
      </div>
    </div>
  </div>
);

export const NacionesTab: React.FC<NacionesTabProps> = ({ nations, cities, events, onEdit, onDelete }) => {
  const [sortKey, setSortKey] = useState<SortKey>('fundacion');
  const [fallenOpen, setFallenOpen] = useState(false);

  const enriched = useMemo<EnrichedNation[]>(() => nations.map(nation => {
    const nc = cities.filter(c => c.nationId === nation.id);

    // Founding: earliest nationFounded event for this nation
    const foundingEvent = events
      .filter(e => e.type === 'nationFounded' && e.nation === nation.id)
      .sort((a, b) => a.id - b.id)[0];

    // Defeat: last attack event where a city was conquered FROM this nation
    // (targetNation === nation.id and targetCity changed nationId)
    const defeatEvent = nc.length === 0
      ? events
          .filter(e =>
            e.type === 'attack' &&
            e.targetNation === nation.id &&
            e.targetCity !== undefined &&
            e.targetCity.nationId !== nation.id   // city was conquered away
          )
          .sort((a, b) => b.id - a.id)[0]         // most recent
      : undefined;

    return {
      nation,
      cityCount:       nc.length,
      totalInfra:      nc.reduce((s, c) => s + c.infrastructureLevel, 0),
      totalMil:        nc.reduce((s, c) => s + c.militaryPower, 0),
      foundingEventId: foundingEvent?.id ?? nation.id * 1_000_000,
      foundingDate:    foundingEvent?.date ?? null,
      defeatDate:      defeatEvent?.date ?? null,
    };
  }), [nations, cities, events]);

  const sorted = useMemo(() => {
    const arr = [...enriched];
    switch (sortKey) {
      case 'alfabetico': return arr.sort((a, b) => a.nation.name.localeCompare(b.nation.name, 'es'));
      case 'desarrollo': return arr.sort((a, b) => b.totalInfra - a.totalInfra || a.foundingEventId - b.foundingEventId);
      case 'militar':    return arr.sort((a, b) => b.totalMil - a.totalMil   || a.foundingEventId - b.foundingEventId);
      case 'ciudades':   return arr.sort((a, b) => b.cityCount - a.cityCount  || a.foundingEventId - b.foundingEventId);
      default:           return arr.sort((a, b) => a.foundingEventId - b.foundingEventId);
    }
  }, [enriched, sortKey]);

  const active = sorted.filter(e => e.cityCount > 0);
  const fallen = sorted.filter(e => e.cityCount === 0);
  const cycleSort = () => setSortKey(k => SORT_ORDER[(SORT_ORDER.indexOf(k) + 1) % SORT_ORDER.length]);

  if (nations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans leading-relaxed">
          Ninguna nación todavía.<br />Registra el evento <span className="text-[#c9a24c]">Fundación</span> para crear la primera.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 p-4 pb-32">
      <button type="button" onClick={cycleSort} className="self-start flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#2a3a47] bg-[#16212b] active:bg-[#1c2a38] transition-colors mb-1">
        <ArrowUpDown size={12} className="text-[#c9a24c]" />
        <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/50">Orden:</span>
        <span className="font-mono text-[10px] uppercase tracking-widest text-[#c9a24c]">{SORT_LABELS[sortKey]}</span>
      </button>

      {active.map(e => <NationCard key={e.nation.id} {...e} onEdit={onEdit} onDelete={onDelete} />)}

      {fallen.length > 0 && (
        <div className="mt-4">
          <button onClick={() => setFallenOpen(o => !o)} className="w-full flex items-center gap-2 py-2 text-left">
            <div className="flex-1 h-px bg-[#2a3a47]" />
            <div className="flex items-center gap-1.5 shrink-0">
              <Skull size={12} className="text-[#b5524a]/60" />
              <span className="font-mono text-[9px] uppercase tracking-widest text-[#b5524a]/60">Naciones caídas ({fallen.length})</span>
              {fallenOpen ? <ChevronDown size={12} className="text-[#b5524a]/40" /> : <ChevronRight size={12} className="text-[#b5524a]/40" />}
            </div>
            <div className="flex-1 h-px bg-[#2a3a47]" />
          </button>
          {fallenOpen && (
            <div className="flex flex-col gap-3 mt-2">
              {fallen.map(e => <div key={e.nation.id} className="opacity-50"><NationCard {...e} onEdit={onEdit} onDelete={onDelete} /></div>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
