import React, { useState, useMemo } from 'react';
import { Nation, City, GameEvent } from '../types';
import { Trash2, ArrowUpDown, ChevronDown, ChevronRight, Skull } from 'lucide-react';
import { TickBar } from './TickBar';

interface NacionesTabProps {
  nations: Nation[];
  cities: City[];
  events: GameEvent[];
  onEdit: (nation: Nation) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
}

type SortKey = 'fundacion' | 'alfabetico' | 'desarrollo' | 'militar' | 'ciudades';
const SORT_LABELS: Record<SortKey, string> = {
  fundacion:  'Fundación',
  alfabetico: 'A–Z',
  desarrollo: 'Desarrollo',
  militar:    'Poder militar',
  ciudades:   'Nº ciudades',
};
const SORT_ORDER: SortKey[] = ['fundacion', 'alfabetico', 'desarrollo', 'militar', 'ciudades'];

type EnrichedNation = {
  nation: Nation;
  cityCount: number;
  totalInfra: number;
  totalMil: number;
  foundingDate: string;
  foundingAt: string;
};

const NationCard: React.FC<EnrichedNation & {
  onEdit: (n: Nation) => void;
  onDelete: (id: string) => void;
}> = ({ nation, cityCount, totalInfra, totalMil, foundingDate, onEdit, onDelete }) => (
  <div
    data-testid={`card-nation-${nation.id}`}
    onClick={() => onEdit(nation)}
    className="bg-[#16212b] border border-[#2a3a47] rounded-xl p-4 active:bg-[#1c2a38] transition-colors cursor-pointer"
  >
    <div className="flex items-start justify-between gap-2">
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-3 h-3 rounded-full shrink-0 border border-black/20 mt-1" style={{ backgroundColor: nation.color }} />
        <div className="min-w-0">
          <p className="font-serif text-[18px] text-[#ece7d9] leading-tight break-words">{nation.name}</p>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="font-mono text-[10px] text-[#c9a24c] uppercase tracking-wider">
              {cityCount} {cityCount === 1 ? 'ciudad' : 'ciudades'}
            </span>
            <span className="font-mono text-[9px] text-foreground/25">· f. {foundingDate}</span>
          </div>
        </div>
      </div>
      <button
        data-testid={`button-delete-nation-${nation.id}`}
        onClick={e => {
          e.stopPropagation();
          if (window.confirm(`¿Eliminar "${nation.name}"?${cityCount > 0 ? `\n\nSus ${cityCount} ciudades también serán eliminadas.` : ''}`)) {
            onDelete(nation.id);
          }
        }}
        className="p-1.5 -mr-1 -mt-1 text-foreground/25 active:text-[#b5524a] transition-colors shrink-0"
      >
        <Trash2 size={16} />
      </button>
    </div>

    <div className="flex items-center gap-4 mt-3 ml-6 flex-wrap">
      <div className="flex items-center gap-1.5">
        <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold tracking-wider">Infra</span>
        <TickBar value={Math.min(totalInfra, 20)} max={20} color="teal" />
        <span className="font-mono text-[13px] text-[#4f9c8c] font-semibold tabular-nums">{totalInfra}</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="font-mono text-[9px] text-[#b5524a] uppercase font-bold tracking-wider">Mil</span>
        <span className="font-mono text-[15px] text-[#b5524a] font-semibold tabular-nums">{totalMil}</span>
        <span className="font-mono text-[9px] text-foreground/30">pts</span>
      </div>
    </div>
  </div>
);

export const NacionesTab: React.FC<NacionesTabProps> = ({ nations, cities, events, onEdit, onDelete, onAdd }) => {
  const [sortKey, setSortKey] = useState<SortKey>('fundacion');
  const [fallenOpen, setFallenOpen] = useState(false);

  // Map nationId -> founding event fecha (earliest nueva_nacion event for that nation name)
  // We use nation.createdAt as the authoritative founding time (set when the event was processed)
  const enriched = useMemo(() => nations.map(nation => {
    const nc = cities.filter(c => c.nationId === nation.id);
    // Find the founding event fecha from events (match by nation name since we don't store nationId in event)
    const foundingEvent = events
      .filter(e => e.tipo === 'nueva_nacion' && e.descripcion.includes(`"${nation.name}"`))
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))[0];
    return {
      nation,
      cityCount: nc.length,
      totalInfra: nc.reduce((s, c) => s + c.nivelInfraestructura, 0),
      totalMil: nc.reduce((s, c) => s + c.poderMilitar, 0),
      foundingDate: foundingEvent?.fecha ?? nation.createdAt.slice(0, 10),
      foundingAt: nation.createdAt, // ISO for stable secondary sort
    };
  }), [nations, cities, events]);

  const sorted = useMemo(() => {
    const arr = [...enriched];
    switch (sortKey) {
      case 'alfabetico': return arr.sort((a, b) => a.nation.name.localeCompare(b.nation.name, 'es'));
      case 'desarrollo': return arr.sort((a, b) => b.totalInfra - a.totalInfra || a.foundingAt.localeCompare(b.foundingAt));
      case 'militar':    return arr.sort((a, b) => b.totalMil - a.totalMil || a.foundingAt.localeCompare(b.foundingAt));
      case 'ciudades':   return arr.sort((a, b) => b.cityCount - a.cityCount || a.foundingAt.localeCompare(b.foundingAt));
      default:           return arr.sort((a, b) => a.foundingAt.localeCompare(b.foundingAt)); // fundacion
    }
  }, [enriched, sortKey]);

  const active = sorted.filter(e => e.cityCount > 0);
  const fallen = sorted.filter(e => e.cityCount === 0);

  const cycleSort = () => {
    const i = SORT_ORDER.indexOf(sortKey);
    setSortKey(SORT_ORDER[(i + 1) % SORT_ORDER.length]);
  };

  if (nations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">
          Ninguna nación todavía.<br />Funda tu primera nación con el botón ✦.
        </p>
        <button
          onClick={onAdd}
          className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors"
        >
          ✦ Fundar Nación
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 p-4 pb-32">
      {/* Sort control */}
      <button
        type="button"
        onClick={cycleSort}
        data-testid="button-sort-nations"
        className="self-start flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#2a3a47] bg-[#16212b] active:bg-[#1c2a38] transition-colors mb-1"
      >
        <ArrowUpDown size={12} className="text-[#c9a24c]" />
        <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/50">Orden:</span>
        <span className="font-mono text-[10px] uppercase tracking-widest text-[#c9a24c]">{SORT_LABELS[sortKey]}</span>
      </button>

      {/* Active nations */}
      {active.map(e => <NationCard key={e.nation.id} {...e} onEdit={onEdit} onDelete={onDelete} />)}

      {/* Fallen nations — collapsible */}
      {fallen.length > 0 && (
        <div className="mt-4">
          <button
            onClick={() => setFallenOpen(o => !o)}
            className="w-full flex items-center gap-2 py-2 text-left group"
          >
            <div className="flex-1 h-px bg-[#2a3a47]" />
            <div className="flex items-center gap-1.5 shrink-0">
              <Skull size={12} className="text-[#b5524a]/60" />
              <span className="font-mono text-[9px] uppercase tracking-widest text-[#b5524a]/60">
                Naciones caídas ({fallen.length})
              </span>
              {fallenOpen
                ? <ChevronDown size={12} className="text-[#b5524a]/40" />
                : <ChevronRight size={12} className="text-[#b5524a]/40" />
              }
            </div>
            <div className="flex-1 h-px bg-[#2a3a47]" />
          </button>

          {fallenOpen && (
            <div className="flex flex-col gap-3 mt-2">
              {fallen.map(e => (
                <div key={e.nation.id} className="opacity-50">
                  <NationCard {...e} onEdit={onEdit} onDelete={onDelete} />
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
