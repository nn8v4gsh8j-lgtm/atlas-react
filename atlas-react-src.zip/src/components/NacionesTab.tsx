import React from 'react';
import { Nation, City } from '../types';
import { Trash2 } from 'lucide-react';

interface NacionesTabProps {
  nations: Nation[];
  cities: City[];
  onEdit: (nation: Nation) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
}

export const NacionesTab: React.FC<NacionesTabProps> = ({ nations, cities, onEdit, onDelete, onAdd }) => {
  if (nations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">
          Ninguna nación todavía.<br />Funda tu primera nación con el botón ✦.
        </p>
        <button
          onClick={onAdd}
          className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors"
        >
          ✦ Fundar Nación
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 p-4 pb-32">
      {nations.map(nation => {
        const nc = cities.filter(c => c.nationId === nation.id);
        const totalInfra = nc.reduce((s, c) => s + c.nivelInfraestructura, 0);
        const totalMil  = nc.reduce((s, c) => s + c.poderMilitar, 0);

        return (
          <div
            key={nation.id}
            data-testid={`card-nation-${nation.id}`}
            onClick={() => onEdit(nation)}
            className="bg-[#16212b] border border-[#2a3a47] rounded-xl p-4 active:bg-[#1c2a38] transition-colors cursor-pointer"
          >
            {/* Row 1 — name + delete */}
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-3 h-3 rounded-full shrink-0 border border-black/20 mt-1"
                  style={{ backgroundColor: nation.color }}
                />
                <div className="min-w-0">
                  <p className="font-serif text-[18px] text-[#ece7d9] leading-tight break-words">
                    {nation.name}
                  </p>
                  <span className="font-mono text-[10px] text-[#c9a24c] uppercase tracking-wider">
                    {nc.length} {nc.length === 1 ? 'ciudad' : 'ciudades'}
                  </span>
                </div>
              </div>
              <button
                data-testid={`button-delete-nation-${nation.id}`}
                onClick={e => {
                  e.stopPropagation();
                  if (window.confirm(`¿Eliminar "${nation.name}"?${nc.length > 0 ? `\n\nSus ${nc.length} ciudades también serán eliminadas.` : ''}`)) {
                    onDelete(nation.id);
                  }
                }}
                className="p-1.5 -mr-1 -mt-1 text-foreground/25 active:text-[#b5524a] transition-colors shrink-0"
              >
                <Trash2 size={16} />
              </button>
            </div>

            {/* Row 2 — computed stats */}
            <div className="flex items-center gap-5 mt-3 ml-6">
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold tracking-wider">Infra</span>
                <span className="font-mono text-[15px] text-[#4f9c8c] font-semibold tabular-nums">{totalInfra}</span>
                <span className="font-mono text-[9px] text-foreground/30">pts</span>
              </div>
              <div className="w-px h-4 bg-[#2a3a47]" />
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-[9px] text-[#b5524a] uppercase font-bold tracking-wider">Mil</span>
                <span className="font-mono text-[15px] text-[#b5524a] font-semibold tabular-nums">{totalMil}</span>
                <span className="font-mono text-[9px] text-foreground/30">pts</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
