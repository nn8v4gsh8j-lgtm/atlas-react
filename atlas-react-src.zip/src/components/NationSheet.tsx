import React, { useState, useEffect } from 'react';
import { Drawer } from 'vaul';
import { Nation } from '../types';

const PRESET_COLORS = ['#c9a24c','#4f9c8c','#b5524a','#5b7fa6','#8a6bbf','#c47c3a','#5a9e6f','#a64c6b'];

interface NationSheetProps {
  open: boolean; onOpenChange: (o: boolean) => void;
  nation?: Nation | null;
  onSave: (data: Omit<Nation, 'id'>) => void;
}

export const NationSheet: React.FC<NationSheetProps> = ({ open, onOpenChange, nation, onSave }) => {
  const [name,  setName]  = useState('');
  const [color, setColor] = useState(PRESET_COLORS[0]);

  useEffect(() => {
    if (!open) return;
    setName(nation?.name ?? '');
    setColor(nation?.color ?? PRESET_COLORS[0]);
  }, [open, nation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave({ name, color });
    onOpenChange(false);
  };

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999]" />
        <Drawer.Content className="bg-[#16212b] border-t border-[#2a3a47] flex flex-col rounded-t-[20px] fixed bottom-0 left-0 right-0 z-[10000] outline-none max-h-[85vh]">
          <div className="p-4 bg-[#16212b] rounded-t-[20px] overflow-y-auto" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)' }}>
            <div className="mx-auto w-12 h-1.5 rounded-full bg-[#2a3a47] mb-8" />
            <h2 className="text-2xl font-serif text-[#ece7d9] mb-2">{nation ? 'Editar Nación' : 'Fundar Nación'}</h2>
            <p className="text-xs font-sans text-[#ece7d9]/40 mb-6">El poder militar e infraestructura se calculan a partir de las ciudades que controla.</p>
            <form onSubmit={handleSubmit} className="flex flex-col gap-8">
              <div className="flex flex-col gap-2">
                <label className="text-sm font-sans text-foreground/70">Nombre de la nación</label>
                <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Imperio..." required
                  className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-serif text-lg focus:outline-none focus:border-[#c9a24c] transition-colors" />
              </div>
              <div className="flex flex-col gap-3">
                <label className="text-sm font-sans text-foreground/70">Color</label>
                <div className="flex flex-wrap gap-3">
                  {PRESET_COLORS.map(c => (
                    <button key={c} type="button" onClick={() => setColor(c)}
                      className={`w-10 h-10 rounded-full shadow-sm transition-transform active:scale-95 ${color === c ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-[#16212b]' : ''}`}
                      style={{ backgroundColor: c }} />
                  ))}
                  <div className="w-10 h-10 rounded-full overflow-hidden relative border border-[#2a3a47] flex items-center justify-center">
                    <input type="color" value={color} onChange={e => setColor(e.target.value)} className="absolute w-[150%] h-[150%] cursor-pointer" />
                  </div>
                </div>
              </div>
              <button type="submit" className="mt-2 bg-[#c9a24c] text-[#0e1720] font-sans font-semibold py-4 rounded-xl active:bg-[#a8863c] transition-colors">
                {nation ? 'Guardar Cambios' : 'Crear Nación'}
              </button>
            </form>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
};
