import React, { useEffect, useMemo } from 'react';
import { Drawer } from 'vaul';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import {
  ComposedChart, Line, XAxis, YAxis, Tooltip,
  CartesianGrid,
} from 'recharts';
import { Pencil, Skull } from 'lucide-react';
import { AtlasEvent, City, Nation, EventType } from '../types';
import { wasConquest, wasRepelled } from '../utils';

interface NationDetailSheetProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  nation: Nation | null;
  nations: Nation[];
  cities: City[];
  events: AtlasEvent[];
  onEdit: (nation: Nation) => void;
}

// ─── history point (aggregated across the whole nation) ───────────────────────
type ChartType = EventType | 'defeat';

interface HistoryPoint {
  idx: number;
  dateNum: number;
  date: string;
  eventId: number;
  type: ChartType;
  isAttacker: boolean;
  isTarget: boolean;
  hasTarget: boolean;
  totalInfra: number;
  totalMil: number;
  cityCount: number;
  gainedCity: boolean;
  lostCity: boolean;
  repelled: boolean;
  actingCityName: string;
  contestedCityName?: string;
  opponentNationId?: number;
  attackerInitialPM?: number;
  defenderInitialPM?: number;
}

function getEmoji(p: HistoryPoint): string {
  switch (p.type) {
    case 'nationFounded':         return '🌟';
    case 'developInfrastructure': return '🏗️';
    case 'increaseMilitaryPower': return '🪖';
    case 'attack':
      if (p.isAttacker) return p.gainedCity ? '🎖️' : (p.hasTarget ? '🤕' : '⚔️');
      return p.lostCity ? '💥' : '🛡️';
    case 'defeat':                return '💀';
  }
}

// Build the full aggregated history for a nation: totals are recomputed from a
// running map of every city's latest known snapshot (from ALL events, not just
// this nation's), so totals reflect the true world state at each point in time.
function buildNationHistory(nationId: number, events: AtlasEvent[]): HistoryPoint[] {
  const sorted = [...events].sort((a, b) => a.id - b.id);
  const cityState = new Map<number, City>();
  const points: HistoryPoint[] = [];

  for (const ev of sorted) {
    cityState.set(ev.city.id, ev.city);
    if (ev.targetCity) cityState.set(ev.targetCity.id, ev.targetCity);

    const isAttacker = ev.nation === nationId;
    const isTarget    = ev.targetNation === nationId;
    if (!isAttacker && !isTarget) continue;

    const owned = [...cityState.values()].filter(c => c.nationId === nationId);
    const totalInfra = owned.reduce((s, c) => s + c.infrastructureLevel, 0);
    const totalMil   = owned.reduce((s, c) => s + c.militaryPower, 0);
    const cityCount  = owned.length;

    const hasTarget  = ev.targetCity !== undefined;
    const gainedCity = ev.type === 'attack' && isAttacker && wasConquest(ev);
    const lostCity   = ev.type === 'attack' && isTarget    && wasConquest(ev);
    const repelled   = ev.type === 'attack' && isTarget    && wasRepelled(ev);

    points.push({
      idx: points.length,
      dateNum: new Date(ev.date + 'T00:00:00').getTime(),
      date: ev.date,
      eventId: ev.id,
      type: ev.type,
      isAttacker, isTarget, hasTarget,
      totalInfra, totalMil, cityCount,
      gainedCity, lostCity, repelled,
      actingCityName: ev.city.name,
      contestedCityName: ev.targetCity?.name,
      opponentNationId: ev.type === 'attack' ? (isAttacker ? ev.targetNation : ev.nation) : undefined,
      attackerInitialPM: ev.attackerInitialPM,
      defenderInitialPM: ev.defenderInitialPM,
    });
  }

  return points;
}

// ─── custom dots with emoji ────────────────────────────────────────────────────
const InfraDot = (props: { cx?: number; cy?: number; payload?: HistoryPoint }) => {
  const { cx, cy, payload } = props;
  if (!payload || cx === undefined || cy === undefined) return null;
  if (payload.type === 'nationFounded' || payload.type === 'developInfrastructure') {
    return <text x={cx} y={cy - 10} textAnchor="middle" fontSize={13} style={{ userSelect: 'none' }}>{getEmoji(payload)}</text>;
  }
  return null;
};

const MilDot = (props: { cx?: number; cy?: number; payload?: HistoryPoint }) => {
  const { cx, cy, payload } = props;
  if (!payload || cx === undefined || cy === undefined) return null;
  if (payload.type === 'increaseMilitaryPower' || payload.type === 'attack') {
    return <text x={cx} y={cy - 10} textAnchor="middle" fontSize={13} style={{ userSelect: 'none' }}>{getEmoji(payload)}</text>;
  }
  return null;
};

const CityCountDot = (props: { cx?: number; cy?: number; payload?: HistoryPoint }) => {
  const { cx, cy, payload } = props;
  if (!payload || cx === undefined || cy === undefined) return null;
  if (payload.type === 'defeat') {
    return <text x={cx} y={cy - 10} textAnchor="middle" fontSize={13} style={{ userSelect: 'none' }}>{getEmoji(payload)}</text>;
  }
  return <circle cx={cx} cy={cy} r={2.5} fill="#8a6bbf" />;
};

// ─── custom tooltip ───────────────────────────────────────────────────────────
const CustomTooltip = ({
  active, payload, nations,
}: { active?: boolean; payload?: { payload: HistoryPoint }[]; nations: Nation[] }) => {
  if (!active || !payload?.length) return null;
  const p = payload[0].payload;
  const opponentNation = p.opponentNationId !== undefined ? nations.find(n => n.id === p.opponentNationId) : undefined;

  return (
    <div style={{
      background: '#16212b', border: '1px solid #2a3a47', borderRadius: 8,
      padding: '8px 10px', fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, minWidth: 150,
    }}>
      <div style={{ color: '#c9a24c', marginBottom: 3 }}>{p.date}</div>
      <div style={{ color: '#ece7d9', fontSize: 13, marginBottom: 3 }}>{getEmoji(p)}</div>

      {p.type === 'defeat' && <div style={{ color: '#b5524a', fontWeight: 700 }}>Nación derrotada</div>}

      {p.type !== 'defeat' && (
        <>
          <div style={{ color: '#4f9c8c' }}>Infra total: {p.totalInfra}</div>
          <div style={{ color: '#b5524a' }}>Mil total: {p.totalMil}</div>
          <div style={{ color: '#8a6bbf' }}>Ciudades: {p.cityCount}</div>
        </>
      )}

      {p.type === 'attack' && (
        <>
          {p.attackerInitialPM !== undefined && p.defenderInitialPM !== undefined && (
            <div style={{ marginTop: 3, color: '#ece7d9aa' }}>
              PM{' '}
              <span style={{ fontWeight: p.isAttacker ? 700 : 400 }}>{p.attackerInitialPM}</span>
              {' vs '}
              <span style={{ fontWeight: p.isAttacker ? 400 : 700 }}>{p.defenderInitialPM}</span>
            </div>
          )}
          {opponentNation && (
            <div style={{ marginTop: 3 }}>
              <span style={{ color: opponentNation.color }}>vs {opponentNation.name}</span>
              {p.contestedCityName && <span style={{ color: '#5c6b73' }}> ({p.contestedCityName})</span>}
            </div>
          )}
        </>
      )}
    </div>
  );
};

// ─── map: fit to all current cities of the nation ──────────────────────────────
const FitBounds: React.FC<{ cities: City[] }> = ({ cities }) => {
  const map = useMap();
  useEffect(() => {
    const t = setTimeout(() => {
      map.invalidateSize();
      if (cities.length === 0) return;
      if (cities.length === 1) {
        map.setView([cities[0].latitude, cities[0].longitude], 5);
        return;
      }
      const bounds = L.latLngBounds(cities.map(c => [c.latitude, c.longitude] as [number, number]));
      map.fitBounds(bounds, { padding: [30, 30], maxZoom: 6 });
    }, 150);
    return () => clearTimeout(t);
  }, [cities, map]);
  return null;
};

// ─── component ───────────────────────────────────────────────────────────────
export const NationDetailSheet: React.FC<NationDetailSheetProps> = ({
  open, onOpenChange, nation, nations, cities, events, onEdit,
}) => {
  const nationCities = useMemo(
    () => nation ? cities.filter(c => c.nationId === nation.id).sort((a, b) => a.id - b.id) : [],
    [nation, cities],
  );

  const history = useMemo(() => nation ? buildNationHistory(nation.id, events) : [], [nation, events]);

  const defeatEvent = useMemo(() => {
    if (!nation || nationCities.length > 0) return undefined;
    return [...events]
      .filter(e => e.type === 'attack' && e.targetNation === nation.id && e.targetCity !== undefined && e.targetCity.nationId !== nation.id)
      .sort((a, b) => b.id - a.id)[0];
  }, [nation, nationCities, events]);

  const fullHistory = useMemo<HistoryPoint[]>(() => {
    if (!defeatEvent) return history;
    return [...history, {
      idx: history.length,
      dateNum: new Date(defeatEvent.date + 'T00:00:00').getTime(),
      date: defeatEvent.date,
      eventId: defeatEvent.id,
      type: 'defeat',
      isAttacker: false, isTarget: true, hasTarget: true,
      totalInfra: 0, totalMil: 0, cityCount: 0,
      gainedCity: false, lostCity: true, repelled: false,
      actingCityName: defeatEvent.city.name,
      contestedCityName: defeatEvent.targetCity?.name,
      opponentNationId: defeatEvent.nation,
    }];
  }, [history, defeatEvent]);

  if (!nation) return null;

  const foundingPoint = history.find(p => p.type === 'nationFounded');
  const foundingDate  = foundingPoint?.date ?? '—';
  const isDefeated    = nationCities.length === 0;

  const totalInfra = nationCities.reduce((s, c) => s + c.infrastructureLevel, 0);
  const totalMil   = nationCities.reduce((s, c) => s + c.militaryPower, 0);

  const conquests = history.filter(p => p.type === 'attack' && (p.gainedCity || p.lostCity));

  const minDate  = fullHistory.length ? Math.min(...fullHistory.map(p => p.dateNum)) : 0;
  const maxDate  = fullHistory.length ? Math.max(...fullHistory.map(p => p.dateNum)) : 1;
  const dayRange = Math.max(1, (maxDate - minDate) / 86_400_000);
  const pxPerDay = Math.max(10, Math.min(60, 500 / dayRange));
  const chartWidth = Math.max(340, Math.ceil(dayRange * pxPerDay) + 80);
  const uniqueDateTicks = [...new Set(fullHistory.map(p => p.dateNum))].sort((a, b) => a - b);
  const yMax = Math.ceil(Math.max(...fullHistory.map(p => Math.max(p.totalInfra, p.totalMil)), 5) / 5) * 5;
  const cityMax = Math.max(...fullHistory.map(p => p.cityCount), 1);

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999]" />
        <Drawer.Content
          className="fixed bottom-0 left-0 right-0 z-[10000] outline-none flex flex-col"
          style={{ maxHeight: '94vh', background: '#0e1720', borderRadius: '20px 20px 0 0', border: '1px solid #2a3a47', borderBottom: 'none' }}
        >
          {/* drag handle */}
          <div className="flex-shrink-0 flex justify-center pt-3 pb-1">
            <div className="w-10 h-1 rounded-full bg-[#2a3a47]" />
          </div>

          {/* scrollable body */}
          <div className="flex-1 overflow-y-auto" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 24px)' }}>

            {/* ── Header ── */}
            <div className="flex items-start justify-between gap-3 px-5 pt-3 pb-4 border-b border-[#2a3a47]">
              <div className="flex items-start gap-3 min-w-0">
                <div className="w-3 h-3 rounded-full shrink-0 mt-2" style={{ backgroundColor: nation.color }} />
                <div>
                  <h2 className="font-serif text-2xl text-[#ece7d9]">{nation.name}</h2>
                  {isDefeated && (
                    <p className="font-mono text-[10px] uppercase tracking-wider mt-0.5 flex items-center gap-1" style={{ color: '#b5524a' }}>
                      <Skull size={11} /> Nación derrotada
                    </p>
                  )}
                </div>
              </div>
              <button
                onClick={() => { onOpenChange(false); setTimeout(() => onEdit(nation), 200); }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#2a3a47] bg-[#16212b] active:bg-[#1c2a38] transition-colors shrink-0"
              >
                <Pencil size={13} className="text-[#c9a24c]" />
                <span className="font-mono text-[10px] uppercase tracking-wider text-[#c9a24c]">Editar</span>
              </button>
            </div>

            {/* ── Map with current cities ── */}
            {nationCities.length > 0 ? (
              <div className="mx-4 mt-4 rounded-xl overflow-hidden border border-[#2a3a47]" style={{ height: 170 }}>
                <MapContainer
                  center={[nationCities[0].latitude, nationCities[0].longitude]} zoom={4}
                  style={{ width: '100%', height: '100%' }}
                  zoomControl={false} dragging={false}
                  scrollWheelZoom={false} doubleClickZoom={false}
                  attributionControl={false}
                >
                  <TileLayer url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" subdomains={['a','b','c','d']} />
                  <FitBounds cities={nationCities} />
                  {nationCities.map(city => (
                    <CircleMarker
                      key={city.id}
                      center={[city.latitude, city.longitude]}
                      radius={Math.max(5, Math.min(4 + city.infrastructureLevel, 13))}
                      pathOptions={{ color: '#0e1720', weight: 2, fillColor: nation.color, fillOpacity: 0.9 }}
                    >
                      <Popup className="atlas-popup">
                        <div style={{ background: '#16212b', border: '1px solid #2a3a47', borderRadius: 10, padding: '10px 12px', minWidth: 150 }}>
                          <div style={{ fontFamily: 'Spectral, serif', fontSize: 15, color: '#ece7d9', marginBottom: 6 }}>{city.name}</div>
                          <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: '#4f9c8c' }}>Infra: {city.infrastructureLevel}</div>
                          <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: '#b5524a' }}>Mil: {city.militaryPower}</div>
                        </div>
                      </Popup>
                    </CircleMarker>
                  ))}
                </MapContainer>
              </div>
            ) : (
              <div className="mx-4 mt-4 rounded-xl border border-[#2a3a47] bg-[#16212b] flex items-center justify-center" style={{ height: 80 }}>
                <p className="font-mono text-[10px] text-foreground/30 uppercase tracking-wider">Sin territorio</p>
              </div>
            )}

            {/* ── Stats ── */}
            <div className="grid grid-cols-2 gap-2 px-4 mt-4">
              {[
                { label: 'Fundación',           value: foundingDate,          color: '#c9a24c' },
                { label: 'Nº Ciudades',          value: nationCities.length,   color: '#8a6bbf' },
                { label: 'Desarrollo Total',     value: totalInfra,             color: '#4f9c8c' },
                { label: 'Poder Militar Total',  value: totalMil,               color: '#b5524a' },
              ].map(s => (
                <div key={s.label} className="bg-[#16212b] border border-[#2a3a47] rounded-xl px-3 py-2.5">
                  <p className="font-mono text-[9px] uppercase tracking-wider text-foreground/40 mb-1">{s.label}</p>
                  <p className="font-mono text-[18px] font-bold leading-none" style={{ color: s.color }}>{s.value}</p>
                </div>
              ))}
            </div>

            {/* ── City list ── */}
            {nationCities.length > 0 && (
              <div className="px-4 mt-5">
                <h3 className="font-serif text-[17px] text-[#ece7d9] mb-3">Ciudades</h3>
                <div className="flex flex-col gap-2">
                  {nationCities.map(city => (
                    <div key={city.id} className="bg-[#16212b] border border-[#2a3a47] rounded-xl px-4 py-3 flex items-center justify-between gap-3">
                      <span className="font-serif text-[15px] text-[#ece7d9] truncate">{city.name}</span>
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold tracking-wider">Infra</span>
                          <span className="font-mono text-[14px] text-[#4f9c8c] font-bold tabular-nums leading-none">{city.infrastructureLevel}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-[9px] text-[#b5524a] uppercase font-bold tracking-wider">Mil</span>
                          <span className="font-mono text-[14px] text-[#b5524a] font-bold tabular-nums leading-none">{city.militaryPower}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ── Chart ── */}
            {fullHistory.length > 0 && (
              <div className="px-4 mt-5">
                <div className="flex items-center gap-2 mb-3">
                  <h3 className="font-serif text-[17px] text-[#ece7d9]">Historia</h3>
                  <span className="font-mono text-[9px] text-foreground/30">{history.length} eventos</span>
                </div>

                {/* Legend */}
                <div className="flex flex-wrap gap-x-4 gap-y-1.5 mb-3">
                  {[
                    { emoji: '🌟', label: 'Fundación' },
                    { emoji: '🪖', label: 'Gen. Militar' },
                    { emoji: '🏗️', label: 'Infra' },
                    { emoji: '🎖️', label: 'Conquista' },
                    { emoji: '🤕', label: 'Ataque ✗' },
                    { emoji: '🛡️', label: 'Defensa ✓' },
                    { emoji: '💥', label: 'Ciudad perdida' },
                    { emoji: '💀', label: 'Derrota' },
                  ].map(({ emoji, label }) => (
                    <div key={label} className="flex items-center gap-1">
                      <span style={{ fontSize: 11 }}>{emoji}</span>
                      <span className="font-mono text-[9px] text-foreground/40">{label}</span>
                    </div>
                  ))}
                </div>

                {/* Series legend (colors) */}
                <div className="flex flex-wrap gap-x-4 gap-y-1 mb-3">
                  {[
                    { color: '#4f9c8c', label: 'Desarrollo' },
                    { color: '#b5524a', label: 'Poder militar' },
                    { color: '#8a6bbf', label: 'Nº ciudades' },
                  ].map(({ color, label }) => (
                    <div key={label} className="flex items-center gap-1.5">
                      <div className="w-2.5 h-0.5 rounded-full" style={{ backgroundColor: color }} />
                      <span className="font-mono text-[9px] text-foreground/40">{label}</span>
                    </div>
                  ))}
                </div>

                {/* Scrollable chart */}
                <div className="rounded-xl border border-[#2a3a47] overflow-hidden bg-[#16212b]">
                  <div style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
                    <div style={{ width: chartWidth, height: 230 }}>
                      <ComposedChart
                        width={chartWidth} height={230}
                        data={fullHistory}
                        margin={{ top: 24, right: 16, bottom: 32, left: 8 }}
                      >
                        <CartesianGrid strokeDasharray="2 4" stroke="#1c2a36" vertical={false} />

                        <XAxis
                          dataKey="dateNum"
                          type="number"
                          scale="time"
                          domain={[minDate, maxDate]}
                          ticks={uniqueDateTicks}
                          tickFormatter={v => {
                            const d = new Date(v);
                            return `${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
                          }}
                          tick={{ fill: '#4a5c6a', fontSize: 9, fontFamily: 'IBM Plex Mono, monospace' }}
                          axisLine={{ stroke: '#2a3a47' }}
                          tickLine={false}
                          angle={-40}
                          dy={10}
                        />

                        <YAxis
                          yAxisId="left"
                          domain={[0, yMax]}
                          tick={{ fill: '#4a5c6a', fontSize: 9, fontFamily: 'IBM Plex Mono, monospace' }}
                          axisLine={false} tickLine={false} width={24}
                        />

                        <YAxis
                          yAxisId="right"
                          orientation="right"
                          domain={[0, cityMax]}
                          allowDecimals={false}
                          tick={{ fill: '#8a6bbf', fontSize: 9, fontFamily: 'IBM Plex Mono, monospace' }}
                          axisLine={false} tickLine={false} width={20}
                        />

                        <Tooltip content={<CustomTooltip nations={nations} />} />

                        {/* Infra total line */}
                        <Line
                          yAxisId="left"
                          type="stepAfter"
                          dataKey="totalInfra"
                          stroke="#4f9c8c"
                          strokeWidth={2}
                          dot={(p: { cx?: number; cy?: number; payload?: HistoryPoint }) => <InfraDot {...p} />}
                          activeDot={{ r: 4, fill: '#4f9c8c' }}
                          isAnimationActive={false}
                        />

                        {/* Military total line */}
                        <Line
                          yAxisId="left"
                          type="stepAfter"
                          dataKey="totalMil"
                          stroke="#b5524a"
                          strokeWidth={2}
                          dot={(p: { cx?: number; cy?: number; payload?: HistoryPoint }) => <MilDot {...p} />}
                          activeDot={{ r: 4, fill: '#b5524a' }}
                          isAnimationActive={false}
                        />

                        {/* City count line */}
                        <Line
                          yAxisId="right"
                          type="stepAfter"
                          dataKey="cityCount"
                          stroke="#8a6bbf"
                          strokeWidth={1.5}
                          strokeDasharray="3 3"
                          dot={(p: { cx?: number; cy?: number; payload?: HistoryPoint }) => <CityCountDot {...p} />}
                          activeDot={{ r: 4, fill: '#8a6bbf' }}
                          isAnimationActive={false}
                        />
                      </ComposedChart>
                    </div>
                  </div>
                </div>

                {/* Territory log — only events where a city was gained or lost */}
                {conquests.length > 0 && (
                  <div className="mt-3 flex flex-col gap-1.5">
                    <p className="font-mono text-[9px] uppercase tracking-wider text-foreground/30 mb-1">Territorio</p>
                    {[...conquests].sort((a, b) => b.eventId - a.eventId).map(p => {
                      const resultColor = p.gainedCity ? '#4f9c8c' : '#b5524a';
                      const label = p.gainedCity ? 'Conquista' : 'Pérdida';
                      const opponentNation = p.opponentNationId !== undefined ? nations.find(n => n.id === p.opponentNationId) : undefined;
                      const hasPMs = p.attackerInitialPM !== undefined && p.defenderInitialPM !== undefined;
                      return (
                        <div key={p.eventId} className="flex flex-col gap-1 px-3 py-2 rounded-lg border border-[#2a3a47] bg-[#16212b]">
                          {/* Row 1: emoji + result + city + opponent */}
                          <div className="flex items-center gap-2 flex-wrap">
                            <span style={{ fontSize: 13 }}>{getEmoji(p)}</span>
                            <span className="font-mono text-[10px] font-semibold" style={{ color: resultColor }}>{label}</span>
                            {p.contestedCityName && (
                              <span className="font-mono text-[10px] text-[#ece7d9]">{p.contestedCityName}</span>
                            )}
                            {opponentNation && (
                              <span className="font-mono text-[9px] text-foreground/40">
                                {p.gainedCity ? 'a' : 'de'}{' '}
                                <span style={{ color: opponentNation.color }}>{opponentNation.name}</span>
                              </span>
                            )}
                            <span className="font-mono text-[9px] text-foreground/40 ml-auto">{p.date}</span>
                          </div>
                          {/* Row 2: PM X vs Y */}
                          {hasPMs && (
                            <div className="font-mono text-[9px] text-foreground/50 pl-0">
                              PM{' '}
                              <span className="font-mono" style={{ fontWeight: p.isAttacker ? 700 : 400, color: '#b5524a' }}>
                                {p.attackerInitialPM}
                              </span>
                              <span className="text-foreground/30"> vs </span>
                              <span className="font-mono" style={{ fontWeight: p.isAttacker ? 400 : 700, color: '#4f9c8c' }}>
                                {p.defenderInitialPM}
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {fullHistory.length === 0 && (
              <p className="font-sans text-sm text-foreground/40 text-center px-6 mt-8">
                No hay eventos registrados para esta nación.
              </p>
            )}
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
};
