import React, { useState, useEffect } from 'react';
import { Drawer } from 'vaul';
import { Nation, City } from '../types';
import { TickBar } from './TickBar';
import { MapPin } from 'lucide-react';

interface CitySheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  city?: City | null;
  nations: Nation[];
  onSave: (city: Omit<City, 'id' | 'createdAt'> | Partial<City>) => void;
  onRequestMapSelection: (draft: Partial<City>) => void;
  draftData?: Partial<City>;
}

export const CitySheet: React.FC<CitySheetProps> = ({
  open, onOpenChange, city, nations, onSave, onRequestMapSelection, draftData,
}) => {
  const [name, setName] = useState('');
  const [nationId, setNationId] = useState('');
  const [latStr, setLatStr] = useState('0');
  const [lngStr, setLngStr] = useState('0');
  const [latError, setLatError] = useState<string | null>(null);
  const [lngError, setLngError] = useState<string | null>(null);
  const [infra, setInfra] = useState(1);
  const [puntos, setPuntos] = useState(0);
  const [mil, setMil] = useState(0);

  const normalizeDecimal = (v: string) => v.replace(',', '.');

  const validateLat = (v: string): string | null => {
    const s = normalizeDecimal(v).trim();
    if (s === '' || s === '-') return 'Introduce una latitud';
    const n = parseFloat(s);
    if (isNaN(n)) return 'Debe ser un número';
    if (n < -90 || n > 90) return 'Entre −90 y 90';
    return null;
  };
  const validateLng = (v: string): string | null => {
    const s = normalizeDecimal(v).trim();
    if (s === '' || s === '-') return 'Introduce una longitud';
    const n = parseFloat(s);
    if (isNaN(n)) return 'Debe ser un número';
    if (n < -180 || n > 180) return 'Entre −180 y 180';
    return null;
  };

  const parsedLat = () => parseFloat(normalizeDecimal(latStr)) || 0;
  const parsedLng = () => parseFloat(normalizeDecimal(lngStr)) || 0;

  useEffect(() => {
    if (!open) return;
    if (draftData) {
      setName(draftData.name ?? '');
      setNationId(draftData.nationId ?? nations[0]?.id ?? '');
      setLatStr(String(draftData.latitude ?? 0));
      setLngStr(String(draftData.longitude ?? 0));
      setInfra(draftData.nivelInfraestructura ?? 1);
      setPuntos(draftData.puntosDesarrollo ?? 0);
      setMil(draftData.poderMilitar ?? 0);
    } else if (city) {
      setName(city.name);
      setNationId(city.nationId);
      setLatStr(String(city.latitude));
      setLngStr(String(city.longitude));
      setInfra(city.nivelInfraestructura);
      setPuntos(city.puntosDesarrollo);
      setMil(city.poderMilitar);
    } else {
      setName('');
      setNationId(nations[0]?.id ?? '');
      setLatStr('0');
      setLngStr('0');
      setInfra(1);
      setPuntos(0);
      setMil(0);
    }
    setLatError(null);
    setLngError(null);
  }, [open, city, draftData, nations]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !nationId) return;
    const latErr = validateLat(latStr);
    const lngErr = validateLng(lngStr);
    if (latErr) { setLatError(latErr); return; }
    if (lngErr) { setLngError(lngErr); return; }
    onSave({ name, nationId, latitude: parsedLat(), longitude: parsedLng(), nivelInfraestructura: infra, puntosDesarrollo: puntos, poderMilitar: mil });
    onOpenChange(false);
  };

  const handleMapSelect = () => {
    onRequestMapSelection({ name, nationId, latitude: parsedLat(), longitude: parsedLng(), nivelInfraestructura: infra, puntosDesarrollo: puntos, poderMilitar: mil });
  };

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999]" />
        <Drawer.Content className="bg-[#16212b] border-t border-[#2a3a47] flex flex-col rounded-t-[20px] fixed bottom-0 left-0 right-0 z-[10000] outline-none max-h-[92vh]">
          <div className="p-4 bg-[#16212b] rounded-t-[20px] flex-1 overflow-y-auto" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)' }}>
            <div className="mx-auto w-12 h-1.5 rounded-full bg-[#2a3a47] mb-8" />

            <h2 className="text-2xl font-serif text-[#ece7d9] mb-6">
              {city ? 'Editar Ciudad' : 'Asentar Ciudad'}
            </h2>

            <form onSubmit={handleSubmit} className="flex flex-col gap-7">
              <div className="flex flex-col gap-2">
                <label className="text-sm font-sans text-foreground/70">Nombre de la ciudad</label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-serif text-lg focus:outline-none focus:border-[#c9a24c] transition-colors"
                  placeholder="Roma..."
                  required
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-sm font-sans text-foreground/70">Nación</label>
                <select
                  value={nationId}
                  onChange={e => setNationId(e.target.value)}
                  className="bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#ece7d9] font-sans focus:outline-none focus:border-[#c9a24c] transition-colors"
                  required
                >
                  <option value="" disabled>Selecciona una nación</option>
                  {nations.map(n => (
                    <option key={n.id} value={n.id}>{n.name}</option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col gap-3">
                <label className="text-sm font-sans text-foreground/70">Coordenadas</label>
                <div className="flex gap-4">
                  <div className="flex-1 flex flex-col gap-1">
                    <span className="text-[10px] text-foreground/50 uppercase font-mono">Latitud (−90 a 90)</span>
                    <input
                      type="text"
                      value={latStr}
                      onChange={e => { setLatStr(e.target.value); setLatError(null); }}
                      onBlur={() => setLatError(validateLat(latStr))}
                      placeholder="40.416"
                      className={`bg-[#0e1720] border rounded-lg px-3 py-2 text-[#c9a24c] font-mono text-sm focus:outline-none transition-colors ${latError ? 'border-[#b5524a]' : 'border-[#2a3a47] focus:border-[#c9a24c]'}`}
                    />
                    {latError && <span className="text-[11px] text-[#b5524a]">{latError}</span>}
                  </div>
                  <div className="flex-1 flex flex-col gap-1">
                    <span className="text-[10px] text-foreground/50 uppercase font-mono">Longitud (−180 a 180)</span>
                    <input
                      type="text"
                      value={lngStr}
                      onChange={e => { setLngStr(e.target.value); setLngError(null); }}
                      onBlur={() => setLngError(validateLng(lngStr))}
                      placeholder="-3.703"
                      className={`bg-[#0e1720] border rounded-lg px-3 py-2 text-[#c9a24c] font-mono text-sm focus:outline-none transition-colors ${lngError ? 'border-[#b5524a]' : 'border-[#2a3a47] focus:border-[#c9a24c]'}`}
                    />
                    {lngError && <span className="text-[11px] text-[#b5524a]">{lngError}</span>}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleMapSelect}
                  className="flex items-center justify-center gap-2 mt-1 bg-[#4f9c8c]/10 text-[#4f9c8c] border border-[#4f9c8c]/30 rounded-lg py-3 font-sans text-sm active:bg-[#4f9c8c]/20 transition-colors"
                >
                  <MapPin size={16} /> Elegir en el mapa
                </button>
              </div>

              <div className="flex flex-col gap-3">
                <label className="text-sm font-sans text-foreground/70">Nivel de Infraestructura</label>
                <input
                  type="range" min="1" max="10"
                  value={infra}
                  onChange={e => { setInfra(parseInt(e.target.value)); setPuntos(0); }}
                  className="w-full accent-[#4f9c8c]"
                />
                <div className="flex items-center gap-3">
                  <TickBar value={infra} max={10} color="teal" />
                  <span className="font-mono text-sm text-[#ece7d9]">{infra}</span>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-sm font-sans text-foreground/70">
                  Puntos de desarrollo acumulados{' '}
                  <span className="text-foreground/40 text-xs">(0 – {Math.max(0, infra - 1)} para nivel {infra})</span>
                </label>
                <div className="flex items-center gap-3">
                  <TickBar value={puntos} max={Math.max(1, infra)} color="teal" />
                  <input
                    type="number" min="0" max={infra - 1}
                    value={puntos}
                    onChange={e => setPuntos(Math.max(0, Math.min(infra - 1, parseInt(e.target.value) || 0)))}
                    className="w-16 bg-[#0e1720] border border-[#2a3a47] rounded-lg px-2 py-1 text-[#c9a24c] font-mono text-sm focus:outline-none focus:border-[#c9a24c] text-center"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-sm font-sans text-foreground/70">Poder Militar</label>
                <div className="flex items-center gap-3">
                  <input
                    type="number" min="0"
                    value={mil}
                    onChange={e => setMil(Math.max(0, parseInt(e.target.value) || 0))}
                    className="flex-1 bg-[#0e1720] border border-[#2a3a47] rounded-lg px-4 py-3 text-[#b5524a] font-mono text-lg focus:outline-none focus:border-[#b5524a] transition-colors"
                  />
                  <span className="font-mono text-xs text-foreground/40">pts</span>
                </div>
              </div>

              <button
                type="submit"
                className="mt-2 bg-[#c9a24c] text-[#0e1720] font-sans font-semibold py-4 rounded-xl active:bg-[#a8863c] transition-colors"
              >
                {city ? 'Guardar Cambios' : 'Asentar Ciudad'}
              </button>
            </form>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
};
