import React, { useMemo } from 'react';
import { Drawer } from 'vaul';
import { MapContainer, TileLayer, CircleMarker } from 'react-leaflet';
import {
  ComposedChart, Line, XAxis, YAxis, Tooltip,
  ReferenceArea, ResponsiveContainer, Scatter, CartesianGrid,
} from 'recharts';
import { Pencil, Swords, Shield, Calendar, Flag } from 'lucide-react';
import { AtlasEvent, City, Nation, EventType } from '../types';

interface CityDetailSheetProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  city: City | null;
  nations: Nation[];
  events: AtlasEvent[];
  onEdit: (city: City) => void;
}

// ─── history builder ──────────────────────────────────────────────────────────
interface HistoryPoint {
  idx: number;
  date: string;
  eventId: number;
  type: EventType;
  infraLevel: number;
  militaryPower: number;
  nationId: number;
  isActing: boolean;   // city was the acting (attacker) side
  isBattle: boolean;
}

function buildHistory(cityId: number, events: AtlasEvent[]): HistoryPoint[] {
  return events
    .filter(e => e.city.id === cityId || e.targetCity?.id === cityId)
    .sort((a, b) => a.id - b.id)
    .map((ev, idx) => {
      const isActing = ev.city.id === cityId;
      const snap     = isActing ? ev.city : ev.targetCity!;
      return {
        idx,
        date: ev.date,
        eventId: ev.id,
        type: ev.type,
        infraLevel: snap.infrastructureLevel,
        militaryPower: snap.militaryPower,
        nationId: snap.nationId,
        isActing,
        isBattle: ev.type === 'attack',
      };
    });
}

// ─── nation control periods (for background reference areas) ─────────────────
interface NationPeriod { startIdx: number; endIdx: number; nationId: number }

function buildNationPeriods(points: HistoryPoint[]): NationPeriod[] {
  if (points.length === 0) return [];
  const periods: NationPeriod[] = [];
  let start = 0;
  for (let i = 1; i < points.length; i++) {
    if (points[i].nationId !== points[i - 1].nationId) {
      periods.push({ startIdx: start, endIdx: i - 1, nationId: points[i - 1].nationId });
      start = i;
    }
  }
  periods.push({ startIdx: start, endIdx: points.length - 1, nationId: points[points.length - 1].nationId });
  return periods;
}

// ─── custom battle dot ───────────────────────────────────────────────────────
const BattleDot = (props: { cx?: number; cy?: number; payload?: HistoryPoint; nations?: Nation[] }) => {
  const { cx, cy, payload } = props;
  if (!payload?.isBattle || cx === undefined || cy === undefined) return null;
  const color = payload.isActing ? '#b5524a' : '#4f9c8c';
  const r = 7;
  return (
    <g>
      <circle cx={cx} cy={cy} r={r + 2} fill={color} fillOpacity={0.15} />
      <circle cx={cx} cy={cy} r={r} fill={color} fillOpacity={0.9} />
      <text x={cx} y={cy + 4} textAnchor="middle" fontSize={8} fill="white" fontFamily="monospace">
        {payload.isActing ? '⚔' : '🛡'}
      </text>
    </g>
  );
};

// ─── custom tooltip ──────────────────────────────────────────────────────────
const CustomTooltip = ({ active, payload, nations }: { active?: boolean; payload?: { payload: HistoryPoint }[]; nations: Nation[] }) => {
  if (!active || !payload?.length) return null;
  const p = payload[0].payload;
  const nation = nations.find(n => n.id === p.nationId);
  const typeLabel: Record<EventType, string> = {
    nationFounded: 'Fundación', increaseMilitaryPower: 'Gen. Militar',
    developInfrastructure: 'Mejora Infra', attack: p.isActing ? '⚔ Ataque' : '🛡 Defensa',
  };
  return (
    <div style={{ background: '#16212b', border: '1px solid #2a3a47', borderRadius: 8, padding: '8px 10px', fontFamily: 'IBM Plex Mono, monospace', fontSize: 10 }}>
      <div style={{ color: '#c9a24c', marginBottom: 4 }}>{p.date}</div>
      <div style={{ color: '#ece7d9', marginBottom: 2 }}>{typeLabel[p.type]}</div>
      {nation && <div style={{ color: nation.color }}>● {nation.name}</div>}
      <div style={{ color: '#4f9c8c', marginTop: 3 }}>Infra: {p.infraLevel}</div>
      <div style={{ color: '#b5524a' }}>PM: {p.militaryPower}</div>
    </div>
  );
};

// ─── main component ──────────────────────────────────────────────────────────
export const CityDetailSheet: React.FC<CityDetailSheetProps> = ({
  open, onOpenChange, city, nations, events, onEdit,
}) => {
  const history = useMemo(() => city ? buildHistory(city.id, events) : [], [city, events]);
  const periods = useMemo(() => buildNationPeriods(history), [history]);

  if (!city) return null;

  const nation        = nations.find(n => n.id === city.nationId);
  const foundingPoint = history.find(p => p.type === 'nationFounded');
  const foundingDate  = foundingPoint?.date ?? '—';

  // chart sizing: min 50px per point, min 300px
  const PX_PER_POINT = 55;
  const chartWidth   = Math.max(340, history.length * PX_PER_POINT);

  // y-axis max: round up to nearest 5
  const maxVal = Math.max(
    ...history.map(p => Math.max(p.infraLevel, p.militaryPower)),
    5,
  );
  const yMax = Math.ceil(maxVal / 5) * 5;

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999]" />
        <Drawer.Content className="fixed bottom-0 left-0 right-0 z-[10000] outline-none flex flex-col"
          style={{ maxHeight: '94vh', background: '#0e1720', borderRadius: '20px 20px 0 0', border: '1px solid #2a3a47', borderBottom: 'none' }}>

          {/* drag handle */}
          <div className="flex-shrink-0 flex justify-center pt-3 pb-1">
            <div className="w-10 h-1 rounded-full bg-[#2a3a47]" />
          </div>

          {/* scrollable content */}
          <div className="flex-1 overflow-y-auto" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 24px)' }}>

            {/* ── Header ── */}
            <div className="flex items-start justify-between gap-3 px-5 pt-3 pb-4 border-b border-[#2a3a47]">
              <div className="flex items-start gap-3 min-w-0">
                {nation && <div className="w-3 h-3 rounded-full shrink-0 mt-2" style={{ backgroundColor: nation.color }} />}
                <div>
                  <h2 className="font-serif text-2xl text-[#ece7d9]">{city.name}</h2>
                  {nation && <p className="font-mono text-[11px] uppercase tracking-wider mt-0.5" style={{ color: nation.color }}>{nation.name}</p>}
                </div>
              </div>
              <button
                onClick={() => { onOpenChange(false); setTimeout(() => onEdit(city), 150); }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#2a3a47] bg-[#16212b] active:bg-[#1c2a38] transition-colors shrink-0"
              >
                <Pencil size={13} className="text-[#c9a24c]" />
                <span className="font-mono text-[10px] uppercase tracking-wider text-[#c9a24c]">Editar</span>
              </button>
            </div>

            {/* ── Mini-map ── */}
            <div className="mx-4 mt-4 rounded-xl overflow-hidden border border-[#2a3a47]" style={{ height: 160 }}>
              <MapContainer
                center={[city.latitude, city.longitude]}
                zoom={5}
                style={{ width: '100%', height: '100%' }}
                zoomControl={false}
                dragging={false}
                scrollWheelZoom={false}
                doubleClickZoom={false}
                attributionControl={false}
              >
                <TileLayer url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" subdomains={['a','b','c','d']} />
                <CircleMarker
                  center={[city.latitude, city.longitude]}
                  radius={9}
                  pathOptions={{ color: '#0e1720', weight: 2, fillColor: nation?.color ?? '#c9a24c', fillOpacity: 0.9 }}
                />
              </MapContainer>
            </div>

            {/* ── Stats grid ── */}
            <div className="grid grid-cols-2 gap-2 px-4 mt-4">
              {[
                { label: 'Infraestructura', value: city.infrastructureLevel, color: '#4f9c8c' },
                { label: 'Poder Militar',   value: city.militaryPower,       color: '#b5524a' },
                { label: 'Puntos Desarrollo', value: `${city.developmentPoints}/${city.infrastructureLevel}`, color: '#4f9c8c' },
                { label: 'Fundación',       value: foundingDate,             color: '#c9a24c' },
              ].map(s => (
                <div key={s.label} className="bg-[#16212b] border border-[#2a3a47] rounded-xl px-3 py-2.5">
                  <p className="font-mono text-[9px] uppercase tracking-wider text-foreground/40 mb-1">{s.label}</p>
                  <p className="font-mono text-[18px] font-bold leading-none" style={{ color: s.color }}>{s.value}</p>
                </div>
              ))}
            </div>

            {/* ── History chart ── */}
            {history.length > 0 && (
              <div className="px-4 mt-5">
                <div className="flex items-center gap-2 mb-3">
                  <h3 className="font-serif text-[17px] text-[#ece7d9]">Historia</h3>
                  <span className="font-mono text-[9px] text-foreground/30">{history.length} eventos</span>
                </div>

                {/* Legend */}
                <div className="flex items-center gap-4 mb-3 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-0.5 rounded bg-[#4f9c8c]" />
                    <span className="font-mono text-[9px] text-[#4f9c8c] uppercase tracking-wider">Infra</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-0.5 rounded bg-[#b5524a]" />
                    <span className="font-mono text-[9px] text-[#b5524a] uppercase tracking-wider">PM</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-[#b5524a] opacity-80" />
                    <span className="font-mono text-[9px] text-foreground/50">Ataque</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-[#4f9c8c] opacity-80" />
                    <span className="font-mono text-[9px] text-foreground/50">Defensa</span>
                  </div>
                </div>

                {/* Nation control timeline */}
                {periods.length > 1 && (
                  <div className="flex items-center gap-1 mb-3 flex-wrap">
                    {periods.map((p, i) => {
                      const n = nations.find(x => x.id === p.nationId);
                      return (
                        <div key={i} className="flex items-center gap-1 px-2 py-1 rounded-lg border border-[#2a3a47]" style={{ backgroundColor: `${n?.color ?? '#555'}15` }}>
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: n?.color ?? '#555' }} />
                          <span className="font-mono text-[9px]" style={{ color: n?.color ?? '#ece7d9' }}>{n?.name ?? '?'}</span>
                          <span className="font-mono text-[8px] text-foreground/30">{history[p.startIdx]?.date}</span>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Scrollable chart */}
                <div className="rounded-xl border border-[#2a3a47] overflow-hidden bg-[#16212b]">
                  <div style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
                    <div style={{ width: chartWidth, height: 220 }}>
                      <ComposedChart
                        width={chartWidth}
                        height={220}
                        data={history}
                        margin={{ top: 16, right: 16, bottom: 28, left: 8 }}
                      >
                        <CartesianGrid strokeDasharray="2 4" stroke="#2a3a47" vertical={false} />

                        {/* Nation background areas */}
                        {periods.map((p, i) => {
                          const n = nations.find(x => x.id === p.nationId);
                          return (
                            <ReferenceArea
                              key={i}
                              x1={p.startIdx}
                              x2={p.endIdx}
                              fill={n?.color ?? '#555'}
                              fillOpacity={0.06}
                            />
                          );
                        })}

                        <XAxis
                          dataKey="idx"
                          type="number"
                          domain={[0, history.length - 1]}
                          ticks={history.map((_, i) => i)}
                          tickFormatter={i => {
                            const p = history[i];
                            if (!p) return '';
                            // Show date only at first occurrence and when date changes
                            if (i === 0 || history[i - 1]?.date !== p.date) return p.date.slice(5); // MM-DD
                            return '';
                          }}
                          tick={{ fill: '#5c6b73', fontSize: 9, fontFamily: 'IBM Plex Mono, monospace' }}
                          axisLine={{ stroke: '#2a3a47' }}
                          tickLine={false}
                          angle={-35}
                          dy={8}
                        />

                        <YAxis
                          domain={[0, yMax]}
                          tick={{ fill: '#5c6b73', fontSize: 9, fontFamily: 'IBM Plex Mono, monospace' }}
                          axisLine={false}
                          tickLine={false}
                          width={24}
                        />

                        <Tooltip content={<CustomTooltip nations={nations} />} />

                        {/* Infra line */}
                        <Line
                          type="stepAfter"
                          dataKey="infraLevel"
                          stroke="#4f9c8c"
                          strokeWidth={2}
                          dot={false}
                          activeDot={{ r: 4, fill: '#4f9c8c' }}
                          isAnimationActive={false}
                        />

                        {/* PM line */}
                        <Line
                          type="linear"
                          dataKey="militaryPower"
                          stroke="#b5524a"
                          strokeWidth={2}
                          dot={false}
                          activeDot={{ r: 4, fill: '#b5524a' }}
                          isAnimationActive={false}
                        />

                        {/* Battle dots */}
                        <Scatter
                          dataKey="militaryPower"
                          data={history.filter(p => p.isBattle)}
                          shape={(props: { cx?: number; cy?: number; payload?: HistoryPoint }) =>
                            <BattleDot {...props} nations={nations} />
                          }
                          isAnimationActive={false}
                        />
                      </ComposedChart>
                    </div>
                  </div>
                </div>

                {/* Battle log below chart */}
                {history.filter(p => p.isBattle).length > 0 && (
                  <div className="mt-3 flex flex-col gap-1.5">
                    <p className="font-mono text-[9px] uppercase tracking-wider text-foreground/30 mb-1">Batallas</p>
                    {history.filter(p => p.isBattle).map(p => {
                      const color = p.isActing ? '#b5524a' : '#4f9c8c';
                      return (
                        <div key={p.eventId} className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#2a3a47] bg-[#16212b]">
                          <span style={{ fontSize: 12 }}>{p.isActing ? '⚔️' : '🛡️'}</span>
                          <span className="font-mono text-[10px]" style={{ color }}>{p.isActing ? 'Ataque' : 'Defensa'}</span>
                          <span className="font-mono text-[10px] text-foreground/40 ml-auto">{p.date}</span>
                          <span className="font-mono text-[10px]" style={{ color: '#b5524a' }}>PM {p.militaryPower}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {history.length === 0 && (
              <p className="font-sans text-sm text-foreground/40 text-center px-6 mt-8">
                No hay eventos registrados para esta ciudad.
              </p>
            )}
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
};
