import React, { useMemo } from 'react';
import { Drawer } from 'vaul';
import { MapContainer, TileLayer, CircleMarker } from 'react-leaflet';
import {
  ComposedChart, Line, XAxis, YAxis, Tooltip,
  ReferenceArea, CartesianGrid,
} from 'recharts';
import { Pencil } from 'lucide-react';
import { AtlasEvent, City, Nation, EventType } from '../types';

interface CityDetailSheetProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  city: City | null;
  nations: Nation[];
  events: AtlasEvent[];
  onEdit: (city: City) => void;
}

// ─── history point ────────────────────────────────────────────────────────────
interface HistoryPoint {
  idx: number;
  dateNum: number;     // ms timestamp — used as true time axis value
  date: string;
  eventId: number;
  type: EventType;
  infraLevel: number;
  developmentPoints: number;
  militaryPower: number;
  nationId: number;
  isActing: boolean;
  attackerWon: boolean;
  wasConquered: boolean;
  opponentNationId?: number;   // for attack events: the other nation
  opponentCityName?: string;   // for attack events: the other city
  attackerInitialPM?: number;
  defenderInitialPM?: number;
}

function getEmoji(p: HistoryPoint): string {
  switch (p.type) {
    case 'nationFounded':         return '🌟';
    case 'developInfrastructure': return '🏗️';
    case 'increaseMilitaryPower': return '🪖';
    case 'attack':
      if (p.isActing)  return p.attackerWon  ? '🎖️' : '🤕';
      else             return p.wasConquered  ? '💥' : '🛡️';
  }
}

function buildHistory(cityId: number, events: AtlasEvent[]): HistoryPoint[] {
  return events
    .filter(e => e.city.id === cityId || e.targetCity?.id === cityId)
    .sort((a, b) => a.id - b.id)
    .map((ev, idx) => {
      const isActing     = ev.city.id === cityId;
      const snap         = isActing ? ev.city : ev.targetCity!;
      const attackerWon  = ev.type === 'attack' ? ev.city.militaryPower >= 1 : false;
      const wasConquered = ev.type === 'attack' && !isActing
        ? ev.targetCity?.nationId !== ev.targetNation
        : false;
      return {
        idx, date: ev.date, dateNum: new Date(ev.date + 'T00:00:00').getTime(), eventId: ev.id, type: ev.type, isActing,
        infraLevel: snap.infrastructureLevel,
        developmentPoints: snap.developmentPoints,
        militaryPower: snap.militaryPower,
        nationId: snap.nationId,
        attackerWon, wasConquered,
        opponentNationId:  ev.type === 'attack' ? (isActing ? ev.targetNation : ev.nation) : undefined,
        opponentCityName:  ev.type === 'attack' ? (isActing ? ev.targetCity?.name : ev.city.name) : undefined,
        attackerInitialPM: ev.attackerInitialPM,
        defenderInitialPM: ev.defenderInitialPM,
      };
    });
}

// ─── nation control periods ───────────────────────────────────────────────────
interface NationPeriod { startDate: number; endDate: number; nationId: number }

function buildNationPeriods(points: HistoryPoint[]): NationPeriod[] {
  if (points.length === 0) return [];
  const periods: NationPeriod[] = [];
  let startDate = points[0].dateNum;
  for (let i = 1; i < points.length; i++) {
    if (points[i].nationId !== points[i - 1].nationId) {
      periods.push({ startDate, endDate: points[i].dateNum, nationId: points[i - 1].nationId });
      startDate = points[i].dateNum;
    }
  }
  periods.push({ startDate, endDate: points[points.length - 1].dateNum, nationId: points[points.length - 1].nationId });
  return periods;
}

// ─── custom dots with emoji (no text annotations — shown in tooltip instead) ──
const InfraDot = (props: { cx?: number; cy?: number; payload?: HistoryPoint }) => {
  const { cx, cy, payload } = props;
  if (!payload || cx === undefined || cy === undefined) return null;
  if (payload.type === 'nationFounded' || payload.type === 'developInfrastructure') {
    return <text x={cx} y={cy - 10} textAnchor="middle" fontSize={13} style={{ userSelect: 'none' }}>{getEmoji(payload)}</text>;
  }
  return null;
};

const PMDot = (props: { cx?: number; cy?: number; payload?: HistoryPoint }) => {
  const { cx, cy, payload } = props;
  if (!payload || cx === undefined || cy === undefined) return null;
  if (payload.type === 'increaseMilitaryPower' || payload.type === 'attack') {
    return <text x={cx} y={cy - 10} textAnchor="middle" fontSize={13} style={{ userSelect: 'none' }}>{getEmoji(payload)}</text>;
  }
  return null;
};

// ─── custom tooltip ───────────────────────────────────────────────────────────
const CustomTooltip = ({
  active, payload, nations,
}: { active?: boolean; payload?: { payload: HistoryPoint }[]; nations: Nation[] }) => {
  if (!active || !payload?.length) return null;
  const p      = payload[0].payload;
  const nation = nations.find(n => n.id === p.nationId);
  const opponentNation = p.opponentNationId !== undefined ? nations.find(n => n.id === p.opponentNationId) : undefined;

  return (
    <div style={{
      background: '#16212b', border: '1px solid #2a3a47', borderRadius: 8,
      padding: '8px 10px', fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, minWidth: 140,
    }}>
      <div style={{ color: '#c9a24c', marginBottom: 3 }}>{p.date}</div>
      <div style={{ color: '#ece7d9', fontSize: 13, marginBottom: 3 }}>{getEmoji(p)}</div>
      {nation && <div style={{ color: nation.color, marginBottom: 4 }}>● {nation.name}</div>}

      {/* Infra: show Y/X for developInfrastructure */}
      {p.type === 'developInfrastructure' && (
        <div style={{ color: '#4f9c8c' }}>
          Infra: {p.infraLevel} <span style={{ color: '#4f9c8c88' }}>({p.developmentPoints}/{p.infraLevel})</span>
        </div>
      )}
      {p.type !== 'developInfrastructure' && p.type !== 'attack' && (
        <div style={{ color: '#4f9c8c' }}>Infra: {p.infraLevel}</div>
      )}

      {/* PM: show +X for increaseMilitaryPower, X vs Y for attacks */}
      {p.type === 'increaseMilitaryPower' && (
        <div style={{ color: '#b5524a' }}>
          PM: {p.militaryPower} <span style={{ color: '#b5524a88' }}>(+{p.infraLevel})</span>
        </div>
      )}
      {p.type === 'attack' && (
        <>
          {p.attackerInitialPM !== undefined && p.defenderInitialPM !== undefined ? (
            <div style={{ color: '#b5524a' }}>
              PM{' '}
              <span style={{ fontWeight: p.isActing ? 700 : 400 }}>{p.attackerInitialPM}</span>
              {' vs '}
              <span style={{ fontWeight: p.isActing ? 400 : 700 }}>{p.defenderInitialPM}</span>
            </div>
          ) : (
            <div style={{ color: '#b5524a' }}>PM: {p.militaryPower}</div>
          )}
          {opponentNation && (
            <div style={{ marginTop: 3 }}>
              <span style={{ color: opponentNation.color }}>vs {opponentNation.name}</span>
              {p.opponentCityName && <span style={{ color: '#5c6b73' }}> ({p.opponentCityName})</span>}
            </div>
          )}
        </>
      )}
      {p.type !== 'increaseMilitaryPower' && p.type !== 'attack' && (
        <div style={{ color: '#b5524a' }}>PM: {p.militaryPower}</div>
      )}
    </div>
  );
};

// ─── component ───────────────────────────────────────────────────────────────
export const CityDetailSheet: React.FC<CityDetailSheetProps> = ({
  open, onOpenChange, city, nations, events, onEdit,
}) => {
  const history = useMemo(() => city ? buildHistory(city.id, events) : [], [city, events]);
  const periods = useMemo(() => buildNationPeriods(history), [history]);

  if (!city) return null;

  const nation        = nations.find(n => n.id === city.nationId);
  const foundingPoint = history.find(p => p.type === 'nationFounded');
  const foundingDate  = foundingPoint?.date ?? '—';
  const battles       = history.filter(p => p.type === 'attack');

  const minDate  = history.length ? Math.min(...history.map(p => p.dateNum)) : 0;
  const maxDate  = history.length ? Math.max(...history.map(p => p.dateNum)) : 1;
  const dayRange = Math.max(1, (maxDate - minDate) / 86_400_000);
  const pxPerDay = Math.max(10, Math.min(60, 500 / dayRange));
  const chartWidth = Math.max(340, Math.ceil(dayRange * pxPerDay) + 80);
  const uniqueDateTicks = [...new Set(history.map(p => p.dateNum))].sort((a, b) => a - b);
  const yMax = Math.ceil(Math.max(...history.map(p => Math.max(p.infraLevel, p.militaryPower)), 5) / 5) * 5;

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999]" />
        <Drawer.Content
          className="fixed bottom-0 left-0 right-0 z-[10000] outline-none flex flex-col"
          style={{ maxHeight: '94vh', background: '#0e1720', borderRadius: '20px 20px 0 0', border: '1px solid #2a3a47', borderBottom: 'none' }}
        >
          {/* drag handle */}
          <div className="flex-shrink-0 flex justify-center pt-3 pb-1">
            <div className="w-10 h-1 rounded-full bg-[#2a3a47]" />
          </div>

          {/* scrollable body */}
          <div className="flex-1 overflow-y-auto" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 24px)' }}>

            {/* ── Header ── */}
            <div className="flex items-start justify-between gap-3 px-5 pt-3 pb-4 border-b border-[#2a3a47]">
              <div className="flex items-start gap-3 min-w-0">
                {nation && <div className="w-3 h-3 rounded-full shrink-0 mt-2" style={{ backgroundColor: nation.color }} />}
                <div>
                  <h2 className="font-serif text-2xl text-[#ece7d9]">{city.name}</h2>
                  {nation && (
                    <p className="font-mono text-[11px] uppercase tracking-wider mt-0.5" style={{ color: nation.color }}>
                      {nation.name}
                    </p>
                  )}
                </div>
              </div>
              <button
                onClick={() => { onOpenChange(false); setTimeout(() => onEdit(city), 200); }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#2a3a47] bg-[#16212b] active:bg-[#1c2a38] transition-colors shrink-0"
              >
                <Pencil size={13} className="text-[#c9a24c]" />
                <span className="font-mono text-[10px] uppercase tracking-wider text-[#c9a24c]">Editar</span>
              </button>
            </div>

            {/* ── Mini-map ── */}
            <div className="mx-4 mt-4 rounded-xl overflow-hidden border border-[#2a3a47]" style={{ height: 155 }}>
              <MapContainer
                center={[city.latitude, city.longitude]} zoom={5}
                style={{ width: '100%', height: '100%' }}
                zoomControl={false} dragging={false}
                scrollWheelZoom={false} doubleClickZoom={false}
                attributionControl={false}
              >
                <TileLayer url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" subdomains={['a','b','c','d']} />
                <CircleMarker
                  center={[city.latitude, city.longitude]} radius={9}
                  pathOptions={{ color: '#0e1720', weight: 2, fillColor: nation?.color ?? '#c9a24c', fillOpacity: 0.9 }}
                />
              </MapContainer>
            </div>

            {/* ── Stats ── */}
            <div className="grid grid-cols-2 gap-2 px-4 mt-4">
              {[
                { label: 'Infraestructura',   value: city.infrastructureLevel,                          color: '#4f9c8c' },
                { label: 'Poder Militar',      value: city.militaryPower,                                color: '#b5524a' },
                { label: 'Pts Desarrollo',     value: `${city.developmentPoints}/${city.infrastructureLevel}`, color: '#4f9c8c' },
                { label: 'Fundación',          value: foundingDate,                                      color: '#c9a24c' },
              ].map(s => (
                <div key={s.label} className="bg-[#16212b] border border-[#2a3a47] rounded-xl px-3 py-2.5">
                  <p className="font-mono text-[9px] uppercase tracking-wider text-foreground/40 mb-1">{s.label}</p>
                  <p className="font-mono text-[18px] font-bold leading-none" style={{ color: s.color }}>{s.value}</p>
                </div>
              ))}
            </div>

            {/* ── Chart ── */}
            {history.length > 0 && (
              <div className="px-4 mt-5">
                <div className="flex items-center gap-2 mb-3">
                  <h3 className="font-serif text-[17px] text-[#ece7d9]">Historia</h3>
                  <span className="font-mono text-[9px] text-foreground/30">{history.length} eventos</span>
                </div>

                {/* Legend */}
                <div className="flex flex-wrap gap-x-4 gap-y-1.5 mb-3">
                  {[
                    { emoji: '🌟', label: 'Fundación' },
                    { emoji: '🪖', label: 'Gen. Militar' },
                    { emoji: '🏗️', label: 'Infra' },
                    { emoji: '🎖️', label: 'Ataque ✓' },
                    { emoji: '🤕', label: 'Ataque ✗' },
                    { emoji: '🛡️', label: 'Defensa ✓' },
                    { emoji: '💥', label: 'Defensa ✗' },
                  ].map(({ emoji, label }) => (
                    <div key={label} className="flex items-center gap-1">
                      <span style={{ fontSize: 11 }}>{emoji}</span>
                      <span className="font-mono text-[9px] text-foreground/40">{label}</span>
                    </div>
                  ))}
                </div>

                {/* Nation control badges */}
                {periods.length > 1 && (
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {periods.map((p, i) => {
                      const n = nations.find(x => x.id === p.nationId);
                      return (
                        <div key={i} className="flex items-center gap-1 px-2 py-1 rounded-lg border border-[#2a3a47]"
                          style={{ backgroundColor: `${n?.color ?? '#555'}15` }}>
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: n?.color ?? '#555' }} />
                          <span className="font-mono text-[9px]" style={{ color: n?.color ?? '#ece7d9' }}>{n?.name ?? '?'}</span>
                          <span className="font-mono text-[8px] text-foreground/30 ml-0.5">{new Date(p.startDate).toISOString().slice(5,10).replace('-','/')}</span>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Scrollable chart */}
                <div className="rounded-xl border border-[#2a3a47] overflow-hidden bg-[#16212b]">
                  <div style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
                    <div style={{ width: chartWidth, height: 230 }}>
                      <ComposedChart
                        width={chartWidth} height={230}
                        data={history}
                        margin={{ top: 24, right: 16, bottom: 32, left: 8 }}
                      >
                        <CartesianGrid strokeDasharray="2 4" stroke="#1c2a36" vertical={false} />

                        {/* Nation background reference areas — date-based, seamless */}
                        {periods.map((p, i) => {
                          const n = nations.find(x => x.id === p.nationId);
                          return (
                            <ReferenceArea
                              key={i}
                              x1={p.startDate}
                              x2={p.endDate}
                              fill={n?.color ?? '#555'}
                              fillOpacity={0.08}
                              stroke="none"
                            />
                          );
                        })}

                        <XAxis
                          dataKey="dateNum"
                          type="number"
                          scale="time"
                          domain={[minDate, maxDate]}
                          ticks={uniqueDateTicks}
                          tickFormatter={v => {
                            const d = new Date(v);
                            return `${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
                          }}
                          tick={{ fill: '#4a5c6a', fontSize: 9, fontFamily: 'IBM Plex Mono, monospace' }}
                          axisLine={{ stroke: '#2a3a47' }}
                          tickLine={false}
                          angle={-40}
                          dy={10}
                        />

                        <YAxis
                          domain={[0, yMax]}
                          tick={{ fill: '#4a5c6a', fontSize: 9, fontFamily: 'IBM Plex Mono, monospace' }}
                          axisLine={false} tickLine={false} width={24}
                        />

                        <Tooltip content={<CustomTooltip nations={nations} />} />

                        {/* Infra line — stepAfter + emoji dots */}
                        <Line
                          type="stepAfter"
                          dataKey="infraLevel"
                          stroke="#4f9c8c"
                          strokeWidth={2}
                          dot={(p: { cx?: number; cy?: number; payload?: HistoryPoint }) => <InfraDot {...p} />}
                          activeDot={{ r: 4, fill: '#4f9c8c' }}
                          isAnimationActive={false}
                        />

                        {/* PM line — stepAfter + emoji dots */}
                        <Line
                          type="stepAfter"
                          dataKey="militaryPower"
                          stroke="#b5524a"
                          strokeWidth={2}
                          dot={(p: { cx?: number; cy?: number; payload?: HistoryPoint }) => <PMDot {...p} />}
                          activeDot={{ r: 4, fill: '#b5524a' }}
                          isAnimationActive={false}
                        />
                      </ComposedChart>
                    </div>
                  </div>
                </div>

                {/* Battle log */}
                {battles.length > 0 && (
                  <div className="mt-3 flex flex-col gap-1.5">
                    <p className="font-mono text-[9px] uppercase tracking-wider text-foreground/30 mb-1">Batallas</p>
                    {[...battles].sort((a, b) => b.eventId - a.eventId).map(p => {
                      const isWin = (p.isActing && p.attackerWon) || (!p.isActing && !p.wasConquered);
                      const resultColor = isWin ? '#4f9c8c' : '#b5524a';
                      const label = p.isActing
                        ? (p.attackerWon ? 'Victoria' : 'Derrota')
                        : (p.wasConquered ? 'Conquistada' : 'Defendida');
                      const opponentNation = p.opponentNationId !== undefined
                        ? nations.find(n => n.id === p.opponentNationId) : undefined;
                      const hasPMs = p.attackerInitialPM !== undefined && p.defenderInitialPM !== undefined;
                      return (
                        <div key={p.eventId} className="flex flex-col gap-1 px-3 py-2 rounded-lg border border-[#2a3a47] bg-[#16212b]">
                          {/* Row 1: emoji + result + opponent */}
                          <div className="flex items-center gap-2 flex-wrap">
                            <span style={{ fontSize: 13 }}>{getEmoji(p)}</span>
                            <span className="font-mono text-[10px] font-semibold" style={{ color: resultColor }}>{label}</span>
                            {opponentNation && (
                              <span className="font-mono text-[10px] font-semibold" style={{ color: opponentNation.color }}>
                                {opponentNation.name}
                              </span>
                            )}
                            {p.opponentCityName && (
                              <span className="font-mono text-[9px] text-foreground/40">({p.opponentCityName})</span>
                            )}
                            <span className="font-mono text-[9px] text-foreground/40 ml-auto">{p.date}</span>
                          </div>
                          {/* Row 2: PM X vs Y */}
                          {hasPMs && (
                            <div className="font-mono text-[9px] text-foreground/50 pl-0">
                              PM{' '}
                              <span className="font-mono" style={{ fontWeight: p.isActing ? 700 : 400, color: '#b5524a' }}>
                                {p.attackerInitialPM}
                              </span>
                              <span className="text-foreground/30"> vs </span>
                              <span className="font-mono" style={{ fontWeight: p.isActing ? 400 : 700, color: '#4f9c8c' }}>
                                {p.defenderInitialPM}
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {history.length === 0 && (
              <p className="font-sans text-sm text-foreground/40 text-center px-6 mt-8">
                No hay eventos registrados para esta ciudad.
              </p>
            )}
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
};
