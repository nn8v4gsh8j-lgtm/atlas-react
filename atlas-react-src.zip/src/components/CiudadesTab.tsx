import React, { useState, useMemo } from 'react';
import { Nation, City } from '../types';
import { Trash2, ArrowUpDown, Filter, ChevronDown, ChevronRight } from 'lucide-react';

interface CiudadesTabProps {
  nations: Nation[];
  cities: City[];
  onEdit: (city: City) => void;
  onDelete: (id: number) => void;
  onAdd: () => void;
  onGoToNaciones: () => void;
}

const latStr = (v: number) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? 'N' : 'S'}`;
const lngStr = (v: number) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? 'E' : 'W'}`;

type SortKey = 'default' | 'alfabetico' | 'desarrollo' | 'militar';
const SORT_LABELS: Record<SortKey, string> = { default: 'Por país', alfabetico: 'A–Z', desarrollo: 'Desarrollo', militar: 'Poder militar' };
const SORT_ORDER: SortKey[] = ['default', 'alfabetico', 'desarrollo', 'militar'];

const CityCard: React.FC<{ city: City; nation: Nation | undefined; onEdit: (c: City) => void; onDelete: (id: number) => void }> = ({ city, nation, onEdit, onDelete }) => (
  <div onClick={() => onEdit(city)} className="bg-[#16212b] border border-[#2a3a47] rounded-xl p-4 active:bg-[#1c2a38] transition-colors cursor-pointer">
    <div className="flex items-start justify-between gap-2">
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-3 h-3 rounded-full shrink-0 border border-black/20 mt-1" style={{ backgroundColor: nation?.color ?? '#555' }} />
        <div className="min-w-0">
          <p className="font-serif text-[18px] text-[#ece7d9] leading-tight break-words">{city.name}</p>
          <span className="font-mono text-[9px] text-foreground/45 uppercase tracking-wider">
            {nation?.name ?? '?'} · {latStr(city.latitude)} {lngStr(city.longitude)}
          </span>
        </div>
      </div>
      <button onClick={e => { e.stopPropagation(); if (window.confirm(`¿Eliminar ${city.name}?`)) onDelete(city.id); }}
        className="p-1.5 -mr-1 -mt-1 text-foreground/25 active:text-[#b5524a] transition-colors shrink-0">
        <Trash2 size={16} />
      </button>
    </div>
    <div className="flex items-center gap-4 mt-3 ml-6 flex-wrap">
      <div className="flex items-center gap-1.5">
        <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold tracking-wider">Infra</span>
        <span className="font-mono text-[17px] text-[#4f9c8c] font-bold tabular-nums leading-none">{city.infrastructureLevel}</span>
        {city.developmentPoints > 0 && (
          <span className="font-mono text-[9px] text-foreground/35 tabular-nums">+{city.developmentPoints}</span>
        )}
      </div>
      <div className="flex items-center gap-1.5">
        <span className="font-mono text-[9px] text-[#b5524a] uppercase font-bold tracking-wider">Mil</span>
        <span className="font-mono text-[17px] text-[#b5524a] font-bold tabular-nums leading-none">{city.militaryPower}</span>
        <span className="font-mono text-[9px] text-foreground/30">pts</span>
      </div>
    </div>
  </div>
);

export const CiudadesTab: React.FC<CiudadesTabProps> = ({ nations, cities, onEdit, onDelete, onAdd, onGoToNaciones }) => {
  const [sortKey, setSortKey]       = useState<SortKey>('default');
  const [filterNationId, setFilter] = useState<number | ''>('');
  const [collapsed, setCollapsed]   = useState<Set<number>>(new Set());

  const toggleCollapse = (id: number) => setCollapsed(prev => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const cycleSort = () => setSortKey(k => SORT_ORDER[(SORT_ORDER.indexOf(k) + 1) % SORT_ORDER.length]);

  const filtered = useMemo(
    () => filterNationId !== '' ? cities.filter(c => c.nationId === filterNationId) : cities,
    [cities, filterNationId],
  );

  const sortFlat = (list: City[]): City[] => {
    const arr = [...list];
    switch (sortKey) {
      case 'desarrollo': return arr.sort((a, b) => b.infrastructureLevel - a.infrastructureLevel || a.id - b.id);
      case 'militar':    return arr.sort((a, b) => b.militaryPower - a.militaryPower || a.id - b.id);
      case 'alfabetico': return arr.sort((a, b) => a.name.localeCompare(b.name, 'es') || a.id - b.id);
      default:           return arr;
    }
  };

  // Grouped: nations sorted by lowest nationFounded event id (proxy for founding order)
  const groups = useMemo(() => {
    return nations
      .slice()
      .sort((a, b) => a.id - b.id)
      .map(n => ({ nation: n, list: filtered.filter(c => c.nationId === n.id).sort((a, b) => a.id - b.id) }))
      .filter(g => g.list.length > 0);
  }, [nations, filtered]);

  const flatList = useMemo(() => sortFlat([...filtered]), [filtered, sortKey]);
  const isGrouped = sortKey === 'default';

  if (nations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">Crea una nación primero para poder asentar ciudades.</p>
        <button onClick={onGoToNaciones} className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors">Ir a Naciones</button>
      </div>
    );
  }
  if (cities.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">Ninguna ciudad asentada aún.</p>
        <button onClick={onAdd} className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors">✦ Asentar Ciudad</button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 p-4 pb-32">
      {/* Controls */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#2a3a47] bg-[#16212b]">
          <Filter size={12} className="text-[#c9a24c] shrink-0" />
          <select value={String(filterNationId)} onChange={e => setFilter(e.target.value === '' ? '' : Number(e.target.value))}
            className="bg-transparent font-mono text-[10px] uppercase tracking-widest text-[#c9a24c] focus:outline-none">
            <option value="" className="bg-[#16212b] text-[#ece7d9]">Todos los países</option>
            {nations.map(n => <option key={n.id} value={n.id} className="bg-[#16212b] text-[#ece7d9]">{n.name}</option>)}
          </select>
        </div>
        <button type="button" onClick={cycleSort}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#2a3a47] bg-[#16212b] active:bg-[#1c2a38] transition-colors">
          <ArrowUpDown size={12} className="text-[#c9a24c]" />
          <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/50">Orden:</span>
          <span className="font-mono text-[10px] uppercase tracking-widest text-[#c9a24c]">{SORT_LABELS[sortKey]}</span>
        </button>
      </div>

      {/* Grouped mode */}
      {isGrouped && (
        <>
          {groups.length === 0 && <p className="text-foreground/40 font-sans text-sm text-center pt-10">Este país no tiene ciudades asentadas.</p>}
          {groups.map(({ nation, list }) => {
            const isCollapsed = collapsed.has(nation.id);
            return (
              <div key={nation.id} className="flex flex-col gap-2">
                <button type="button" onClick={() => toggleCollapse(nation.id)} className="flex items-center gap-2 mt-2 first:mt-0 w-full text-left group">
                  <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: nation.color }} />
                  <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/50">{nation.name}</span>
                  <span className="font-mono text-[10px] text-foreground/25">· {list.length}</span>
                  <div className="flex-1 h-px bg-[#2a3a47]" />
                  {isCollapsed ? <ChevronRight size={12} className="text-foreground/30 shrink-0" /> : <ChevronDown size={12} className="text-foreground/30 shrink-0" />}
                </button>
                {!isCollapsed && (
                  <div className="flex flex-col gap-3">
                    {list.map(city => <CityCard key={city.id} city={city} nation={nation} onEdit={onEdit} onDelete={onDelete} />)}
                  </div>
                )}
              </div>
            );
          })}
        </>
      )}

      {/* Flat mode */}
      {!isGrouped && (
        <>
          {flatList.length === 0 && <p className="text-foreground/40 font-sans text-sm text-center pt-10">Sin resultados.</p>}
          {flatList.map(city => <CityCard key={city.id} city={city} nation={nations.find(n => n.id === city.nationId)} onEdit={onEdit} onDelete={onDelete} />)}
        </>
      )}
    </div>
  );
};
