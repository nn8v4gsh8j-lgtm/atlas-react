import React, { useState, useMemo } from 'react';
import { Nation, City } from '../types';
import { TickBar } from './TickBar';
import { Trash2, ArrowUpDown, Filter, ChevronDown, ChevronRight } from 'lucide-react';

interface CiudadesTabProps {
  nations: Nation[];
  cities: City[];
  onEdit: (city: City) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
  onGoToNaciones: () => void;
}

const latStr = (v: number) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? 'N' : 'S'}`;
const lngStr = (v: number) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? 'E' : 'W'}`;

// 'default' = grouped by nation + collapsible
// other keys = flat list
type SortKey = 'default' | 'alfabetico' | 'desarrollo' | 'militar';
const SORT_LABELS: Record<SortKey, string> = {
  default:    'Por país',
  alfabetico: 'A–Z',
  desarrollo: 'Desarrollo',
  militar:    'Poder militar',
};
const SORT_ORDER: SortKey[] = ['default', 'alfabetico', 'desarrollo', 'militar'];

function CityCard({ city, nation, onEdit, onDelete }: { city: City; nation: Nation | undefined; onEdit: (c: City) => void; onDelete: (id: string) => void }) {
  return (
    <div
      data-testid={`card-city-${city.id}`}
      onClick={() => onEdit(city)}
      className="bg-[#16212b] border border-[#2a3a47] rounded-xl p-4 active:bg-[#1c2a38] transition-colors cursor-pointer"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-3 min-w-0">
          <div
            className="w-3 h-3 rounded-full shrink-0 border border-black/20 mt-1"
            style={{ backgroundColor: nation?.color ?? '#555' }}
          />
          <div className="min-w-0">
            <p className="font-serif text-[18px] text-[#ece7d9] leading-tight break-words">{city.name}</p>
            <span className="font-mono text-[9px] text-foreground/45 uppercase tracking-wider">
              {nation?.name ?? '?'} · {latStr(city.latitude)} {lngStr(city.longitude)}
            </span>
          </div>
        </div>
        <button
          data-testid={`button-delete-city-${city.id}`}
          onClick={e => {
            e.stopPropagation();
            if (window.confirm(`¿Eliminar la ciudad de ${city.name}?`)) onDelete(city.id);
          }}
          className="p-1.5 -mr-1 -mt-1 text-foreground/25 active:text-[#b5524a] transition-colors shrink-0"
        >
          <Trash2 size={16} />
        </button>
      </div>

      <div className="flex items-center gap-4 mt-3 ml-6 flex-wrap">
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold tracking-wider">Infra</span>
          <TickBar value={city.nivelInfraestructura} max={10} color="teal" />
          <span className="font-mono text-[11px] text-[#4f9c8c] font-semibold tabular-nums">{city.nivelInfraestructura}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-[9px] text-foreground/35 uppercase font-bold tracking-wider">Dev</span>
          <TickBar value={city.puntosDesarrollo} max={Math.max(1, city.nivelInfraestructura)} color="teal" />
          <span className="font-mono text-[9px] text-foreground/40 tabular-nums">{city.puntosDesarrollo}/{city.nivelInfraestructura}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-[9px] text-[#b5524a] uppercase font-bold tracking-wider">Mil</span>
          <span className="font-mono text-[15px] text-[#b5524a] font-semibold tabular-nums">{city.poderMilitar}</span>
          <span className="font-mono text-[9px] text-foreground/30">pts</span>
        </div>
      </div>
    </div>
  );
}

export const CiudadesTab: React.FC<CiudadesTabProps> = ({ nations, cities, onEdit, onDelete, onAdd, onGoToNaciones }) => {
  const [sortKey, setSortKey] = useState<SortKey>('default');
  const [filterNationId, setFilterNationId] = useState<string>('');
  // Set of collapsed nation IDs (default: all expanded)
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  const toggleCollapse = (nationId: string) => {
    setCollapsed(prev => {
      const next = new Set(prev);
      if (next.has(nationId)) next.delete(nationId);
      else next.add(nationId);
      return next;
    });
  };

  const cycleSort = () => {
    const i = SORT_ORDER.indexOf(sortKey);
    setSortKey(SORT_ORDER[(i + 1) % SORT_ORDER.length]);
  };

  const filteredCities = useMemo(
    () => filterNationId ? cities.filter(c => c.nationId === filterNationId) : cities,
    [cities, filterNationId],
  );

  // Sort helper with tiebreaker by joinedNationAt (city antiquity in current nation)
  const sortFlat = (list: City[]): City[] => {
    const arr = [...list];
    switch (sortKey) {
      case 'desarrollo':
        return arr.sort((a, b) => b.nivelInfraestructura - a.nivelInfraestructura || a.joinedNationAt.localeCompare(b.joinedNationAt));
      case 'militar':
        return arr.sort((a, b) => b.poderMilitar - a.poderMilitar || a.joinedNationAt.localeCompare(b.joinedNationAt));
      case 'alfabetico':
        return arr.sort((a, b) => a.name.localeCompare(b.name, 'es') || a.joinedNationAt.localeCompare(b.joinedNationAt));
      default:
        return arr;
    }
  };

  // Grouped mode: ordered by nation.createdAt, then city.joinedNationAt within each group
  const groups = useMemo(() => {
    return nations
      .slice()
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
      .map(nation => ({
        nation,
        list: filteredCities
          .filter(c => c.nationId === nation.id)
          .sort((a, b) => a.joinedNationAt.localeCompare(b.joinedNationAt)),
      }))
      .filter(g => g.list.length > 0);
  }, [nations, filteredCities]);

  // Flat mode: apply sortKey
  const flatList = useMemo(() => sortFlat([...filteredCities]), [filteredCities, sortKey]);

  const isGrouped = sortKey === 'default';

  if (nations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">Crea una nación primero para poder asentar ciudades.</p>
        <button onClick={onGoToNaciones} className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors">
          Ir a Naciones
        </button>
      </div>
    );
  }

  if (cities.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">Ninguna ciudad asentada aún.</p>
        <button onClick={onAdd} className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors">
          ✦ Asentar Ciudad
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 p-4 pb-32">
      {/* Controls */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#2a3a47] bg-[#16212b]">
          <Filter size={12} className="text-[#c9a24c] shrink-0" />
          <select
            value={filterNationId}
            onChange={e => setFilterNationId(e.target.value)}
            data-testid="select-filter-nation"
            className="bg-transparent font-mono text-[10px] uppercase tracking-widest text-[#c9a24c] focus:outline-none"
          >
            <option value="" className="bg-[#16212b] text-[#ece7d9]">Todos los países</option>
            {nations.map(n => (
              <option key={n.id} value={n.id} className="bg-[#16212b] text-[#ece7d9]">{n.name}</option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={cycleSort}
          data-testid="button-sort-cities"
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#2a3a47] bg-[#16212b] active:bg-[#1c2a38] transition-colors"
        >
          <ArrowUpDown size={12} className="text-[#c9a24c]" />
          <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/50">Orden:</span>
          <span className="font-mono text-[10px] uppercase tracking-widest text-[#c9a24c]">{SORT_LABELS[sortKey]}</span>
        </button>
      </div>

      {/* GROUPED mode */}
      {isGrouped && (
        <>
          {groups.length === 0 && (
            <p className="text-foreground/40 font-sans text-sm text-center pt-10">
              Este país no tiene ciudades asentadas.
            </p>
          )}
          {groups.map(({ nation, list }) => {
            const isCollapsed = collapsed.has(nation.id);
            return (
              <div key={nation.id} className="flex flex-col gap-2">
                {/* Collapsible nation header */}
                <button
                  type="button"
                  onClick={() => toggleCollapse(nation.id)}
                  className="flex items-center gap-2 mt-2 first:mt-0 w-full text-left group"
                >
                  <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: nation.color }} />
                  <span className="font-mono text-[10px] uppercase tracking-widest text-foreground/50 group-active:text-foreground/70">{nation.name}</span>
                  <span className="font-mono text-[10px] text-foreground/25">· {list.length}</span>
                  <div className="flex-1 h-px bg-[#2a3a47]" />
                  {isCollapsed
                    ? <ChevronRight size={12} className="text-foreground/30 shrink-0" />
                    : <ChevronDown size={12} className="text-foreground/30 shrink-0" />
                  }
                </button>

                {!isCollapsed && (
                  <div className="flex flex-col gap-3">
                    {list.map(city => (
                      <CityCard key={city.id} city={city} nation={nation} onEdit={onEdit} onDelete={onDelete} />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </>
      )}

      {/* FLAT mode */}
      {!isGrouped && (
        <>
          {flatList.length === 0 && (
            <p className="text-foreground/40 font-sans text-sm text-center pt-10">Sin resultados.</p>
          )}
          {flatList.map(city => {
            const nation = nations.find(n => n.id === city.nationId);
            return <CityCard key={city.id} city={city} nation={nation} onEdit={onEdit} onDelete={onDelete} />;
          })}
        </>
      )}
    </div>
  );
};
