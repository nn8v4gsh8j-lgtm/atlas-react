import React from 'react';
import { Nation, City } from '../types';
import { TickBar } from './TickBar';
import { Trash2 } from 'lucide-react';

interface CiudadesTabProps {
  nations: Nation[];
  cities: City[];
  onEdit: (city: City) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
  onGoToNaciones: () => void;
}

const latStr = (v: number) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? 'N' : 'S'}`;
const lngStr = (v: number) => `${Math.abs(v).toFixed(1)}°${v >= 0 ? 'E' : 'W'}`;

export const CiudadesTab: React.FC<CiudadesTabProps> = ({ nations, cities, onEdit, onDelete, onAdd, onGoToNaciones }) => {
  if (nations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">
          Crea una nación primero para poder asentar ciudades.
        </p>
        <button onClick={onGoToNaciones} className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors">
          Ir a Naciones
        </button>
      </div>
    );
  }

  if (cities.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-6 text-center pt-24">
        <p className="text-foreground/60 font-sans mb-5 leading-relaxed">Ninguna ciudad asentada aún.</p>
        <button onClick={onAdd} className="text-[#c9a24c] border border-[#c9a24c]/30 px-6 py-3 rounded-full font-serif font-medium tracking-wide active:bg-[#c9a24c]/10 transition-colors">
          ✦ Asentar Ciudad
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 p-4 pb-32">
      {cities.map(city => {
        const nation = nations.find(n => n.id === city.nationId);

        return (
          <div
            key={city.id}
            data-testid={`card-city-${city.id}`}
            onClick={() => onEdit(city)}
            className="bg-[#16212b] border border-[#2a3a47] rounded-xl p-4 active:bg-[#1c2a38] transition-colors cursor-pointer"
          >
            {/* Row 1 — name + delete */}
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-3 h-3 rounded-full shrink-0 border border-black/20 mt-1"
                  style={{ backgroundColor: nation?.color ?? '#555' }}
                />
                <div className="min-w-0">
                  <p className="font-serif text-[18px] text-[#ece7d9] leading-tight break-words">
                    {city.name}
                  </p>
                  <span className="font-mono text-[9px] text-foreground/45 uppercase tracking-wider">
                    {nation?.name ?? '?'} · {latStr(city.latitude)} {lngStr(city.longitude)}
                  </span>
                </div>
              </div>
              <button
                data-testid={`button-delete-city-${city.id}`}
                onClick={e => {
                  e.stopPropagation();
                  if (window.confirm(`¿Eliminar la ciudad de ${city.name}?`)) onDelete(city.id);
                }}
                className="p-1.5 -mr-1 -mt-1 text-foreground/25 active:text-[#b5524a] transition-colors shrink-0"
              >
                <Trash2 size={16} />
              </button>
            </div>

            {/* Row 2 — stats */}
            <div className="flex items-center gap-4 mt-3 ml-6 flex-wrap">
              {/* Infra level */}
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-[9px] text-[#4f9c8c] uppercase font-bold tracking-wider">Infra</span>
                <TickBar value={city.nivelInfraestructura} max={10} color="teal" />
                <span className="font-mono text-[11px] text-[#4f9c8c] font-semibold tabular-nums">{city.nivelInfraestructura}</span>
              </div>

              {/* Dev progress */}
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-[9px] text-foreground/35 uppercase font-bold tracking-wider">Dev</span>
                <TickBar value={city.puntosDesarrollo} max={Math.max(1, city.nivelInfraestructura)} color="teal" />
                <span className="font-mono text-[9px] text-foreground/40 tabular-nums">
                  {city.puntosDesarrollo}/{city.nivelInfraestructura}
                </span>
              </div>

              {/* Military */}
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-[9px] text-[#b5524a] uppercase font-bold tracking-wider">Mil</span>
                <span className="font-mono text-[15px] text-[#b5524a] font-semibold tabular-nums">{city.poderMilitar}</span>
                <span className="font-mono text-[9px] text-foreground/30">pts</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
