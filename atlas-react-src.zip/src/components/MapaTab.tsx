import React, { useEffect } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, useMapEvents, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Nation, City } from '../types';

interface MapaTabProps {
  nations: Nation[];
  cities: City[];
  isActive: boolean;
  isSelectingLocation: boolean;
  draftCityName?: string;
  onLocationSelect?: (lat: number, lng: number) => void;
  onCancelSelection?: () => void;
}

const LocationPicker = ({ onSelect }: { onSelect: (lat: number, lng: number) => void }) => {
  useMapEvents({ click(e) { onSelect(e.latlng.lat, e.latlng.lng); } });
  return null;
};

const MapResizer = ({ isActive }: { isActive: boolean }) => {
  const map = useMap();
  useEffect(() => { const t = setTimeout(() => map.invalidateSize(), 100); return () => clearTimeout(t); }, [map]);
  useEffect(() => { if (!isActive) return; const t = setTimeout(() => map.invalidateSize(), 50); return () => clearTimeout(t); }, [map, isActive]);
  return null;
};

export const MapaTab: React.FC<MapaTabProps> = ({ nations, cities, isActive, isSelectingLocation, draftCityName, onLocationSelect, onCancelSelection }) => (
  <div className="w-full h-full relative">
    {isSelectingLocation && (
      <div className="absolute top-4 left-4 right-4 z-[1000] bg-[#16212b]/95 backdrop-blur border border-[#c9a24c]/50 p-4 rounded-xl flex items-center justify-between shadow-xl">
        <span className="font-sans text-sm text-[#ece7d9]">
          Toca el mapa para fijar la ubicación de{' '}
          <strong className="font-serif text-[#c9a24c]">{draftCityName || 'la ciudad'}</strong>
        </span>
        <button onClick={onCancelSelection} className="text-xs font-mono uppercase text-[#b5524a] px-3 py-2 bg-[#b5524a]/10 rounded-md active:bg-[#b5524a]/20 ml-3 flex-shrink-0">
          Cancelar
        </button>
      </div>
    )}

    <MapContainer center={[20, 0]} zoom={2} className="w-full h-full bg-[#0e1720]" zoomControl={false} style={{ background: '#0e1720' }}>
      <MapResizer isActive={isActive} />
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
      />
      {isSelectingLocation && onLocationSelect && <LocationPicker onSelect={onLocationSelect} />}

      {cities.map(city => {
        const nation = nations.find(n => n.id === city.nationId);
        return (
          <CircleMarker key={city.id} center={[city.latitude, city.longitude]} radius={8}
            pathOptions={{ color: '#ece7d9', weight: 2, fillColor: nation?.color ?? '#888', fillOpacity: 0.85 }}>
            <Popup className="atlas-popup">
              <div style={{ background: '#16212b', border: '1px solid #2a3a47', borderRadius: 10, padding: '12px 14px', minWidth: 190 }}>
                <div style={{ fontFamily: 'Spectral, serif', fontSize: 17, color: '#ece7d9', lineHeight: 1.2, marginBottom: 2 }}>{city.name}</div>
                <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: '#c9a24c', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>
                  {nation?.name ?? 'Desconocida'}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: '#4f9c8c', fontWeight: 700, width: 28 }}>INFRA</span>
                    <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 16, color: '#4f9c8c', fontWeight: 700 }}>{city.infrastructureLevel}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: '#b5524a', fontWeight: 700, width: 28 }}>MIL</span>
                    <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 16, color: '#b5524a', fontWeight: 700 }}>{city.militaryPower}</span>
                    <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: '#ece7d9', opacity: 0.4 }}>pts</span>
                  </div>
                </div>
              </div>
            </Popup>
          </CircleMarker>
        );
      })}
    </MapContainer>

    <style dangerouslySetInnerHTML={{ __html: `
      .leaflet-popup-content-wrapper { background: transparent !important; box-shadow: none !important; padding: 0 !important; border-radius: 0 !important; }
      .leaflet-popup-tip-container { display: none !important; }
      .leaflet-popup-content { margin: 0 !important; }
      .leaflet-container { font-family: 'Inter', sans-serif; background: #0e1720; }
      .leaflet-control-attribution { background: rgba(14,23,32,0.7) !important; color: #ece7d9 !important; font-size: 9px !important; }
      .leaflet-control-attribution a { color: #c9a24c !important; }
    `}} />
  </div>
);
