import React from 'react';

interface TickBarProps {
  value: number;
  max?: number;
  color: 'teal' | 'red';
}

export const TickBar: React.FC<TickBarProps> = ({ value, max = 10, color }) => {
  const isTeal = color === 'teal';
  const filledColor = isTeal ? 'bg-[#4f9c8c] brightness-110' : 'bg-[#b5524a] brightness-110';
  const emptyColor = 'bg-[#1c2b38]';

  return (
    <div className="flex gap-[2px] items-center">
      {Array.from({ length: max }).map((_, i) => (
        <div
          key={i}
          className={`h-[6px] w-[16px] rounded-[2px] transition-colors ${
            i < value ? filledColor : emptyColor
          }`}
        />
      ))}
    </div>
  );
};